# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Train a registered policy with the Genesis-backed gslab environment."""

from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

import genesis as gs
import torch
import tyro

import gslab.tasks  # noqa: F401
from gslab.envs import GenesisManagerBasedRlEnv, ManagerBasedRlEnvCfg
from gslab.rl import RslRlVecEnvWrapper
from gslab.rl.config import RslRlBaseRunnerCfg
from gslab.rl.rsl_rl.runner import GslabOnPolicyRunner
from gslab.tasks.registry import load_env_cfg, load_rl_cfg
from gslab.utils.os import dump_yaml, get_checkpoint_path
from gslab.utils.seed import set_seed

DEFAULT_TASK_ID = "Unitree-G1-Flat"

TYRO_FLAGS = (
    # Don't let users switch between types in unions. This produces a simpler CLI
    # with flatter helptext, at the cost of some flexibility. Type changes can
    # just be done in code.
    tyro.conf.AvoidSubcommands,
    # Disable automatic flag conversion (e.g., use `--flag False` instead of
    # `--no-flag` for booleans).
    tyro.conf.FlagConversionOff,
    # Use Python syntax for collections: --tuple (1,2,3) instead of --tuple 1 2 3.
    # Helps with wandb sweep compatibility: https://brentyi.github.io/tyro/wandb_sweeps/
    tyro.conf.UsePythonSyntaxForLiteralCollections,
)

DEFAULT_GENESIS_KWARGS: dict[str, Any] = {"performance_mode": True}


@dataclass(frozen=True)
class TrainConfig:
    env: ManagerBasedRlEnvCfg
    agent: RslRlBaseRunnerCfg
    registry_name: str | None = None
    video: bool = False
    video_length: int = 200
    video_interval: int = 2000
    enable_nan_guard: bool = False
    deterministic: bool = False
    """Enable deterministic torch algorithms on top of seeding."""
    torchrunx_log_dir: str | None = None
    wandb_run_path: str | None = None
    wandb_checkpoint_name: str | None = None
    """Optional checkpoint name within the W&B run to load (e.g. 'model_4000.pt')."""
    gpu_ids: list[int] | Literal["all"] | None = field(default_factory=lambda: [0])

    @staticmethod
    def from_task(task_id: str) -> "TrainConfig":
        env_cfg = load_env_cfg(task_id)
        agent_cfg = load_rl_cfg(task_id)
        return TrainConfig(env=env_cfg, agent=agent_cfg)


def run_train(
    cfg: TrainConfig, log_dir: Path, gs_init_kwargs: dict[str, Any] | None = None
) -> None:
    if gs_init_kwargs is None:
        gs_init_kwargs: dict[str, Any] = DEFAULT_GENESIS_KWARGS.copy()
    else:
        user_kwargs = gs_init_kwargs.copy()
        gs_init_kwargs: dict[str, Any] = DEFAULT_GENESIS_KWARGS.copy()
        gs_init_kwargs.update(user_kwargs)

    # One seed drives everything: env RNGs, the Genesis kernel RNG, and (via
    # agent_cfg) rsl_rl. The env config wins if both are set; the effective
    # seed is stored back so the params/env.yaml dump records it.
    seed = cfg.env.seed if cfg.env.seed is not None else cfg.agent.seed
    cfg.env.seed = seed
    set_seed(seed, deterministic=cfg.deterministic)
    print(f"[INFO] Seed: {seed}")

    if torch.cuda.is_available():
        gs.init(backend=gs.gpu, seed=seed, **gs_init_kwargs)
        device = "cuda"
    else:
        gs.init(backend=gs.cpu, seed=seed, **gs_init_kwargs)
        device = "cpu"

    gs_env = GenesisManagerBasedRlEnv(
        cfg=cfg.env,
        show_viewer=cfg.video,
    )
    env = RslRlVecEnvWrapper(gs_env, clip_actions=cfg.agent.clip_actions)

    log_root_path = log_dir.parent
    resume_path: Path | None = None
    if cfg.agent.resume:
        resume_path = get_checkpoint_path(
            log_root_path, cfg.agent.load_run, cfg.agent.load_checkpoint
        )

    agent_cfg = asdict(cfg.agent)
    env_cfg = asdict(cfg.env)

    runner = GslabOnPolicyRunner(env, agent_cfg, str(log_dir), device)
    runner.add_git_repo_to_log(__file__)

    if resume_path is not None:
        print(f"[INFO] Loading checkpoint: {resume_path}")
        runner.load(str(resume_path))

    dump_yaml(log_dir / "params" / "env.yaml", env_cfg)
    dump_yaml(log_dir / "params" / "agent.yaml", agent_cfg)

    runner.learn(
        num_learning_iterations=cfg.agent.max_iterations,
        init_at_random_ep_len=True,
    )

    env.close()


def launch_training(cfg: TrainConfig) -> None:
    log_root_path = Path("logs") / "rsl_rl" / cfg.agent.experiment_name
    log_dir_name = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    if cfg.agent.run_name:
        log_dir_name += f"_{cfg.agent.run_name}"
    log_dir = log_root_path / log_dir_name
    run_train(cfg, log_dir)


def _launch_for_task(task_id: str, args: list[str] | None = None) -> None:
    """Parse CLI args against a task's defaults and launch training."""
    cfg = tyro.cli(
        TrainConfig,
        args=args,
        default=TrainConfig.from_task(task_id),
        config=TYRO_FLAGS,
    )
    launch_training(cfg)


def main() -> None:
    """Train the default humanoid task (``Unitree-G1-Flat``)."""
    _launch_for_task(DEFAULT_TASK_ID)


def main_task() -> None:
    """Robot-agnostic entrypoint: pick any registered task by id.

    Usage: ``train <Task-Id> [--env... --agent...]``. Mirrors ``scripts/play.py``.
    """
    from gslab.tasks.registry import list_tasks

    chosen_task, remaining_args = tyro.cli(
        tyro.extras.literal_type_from_choices(list_tasks()),
        add_help=False,
        return_unknown_args=True,
        config=TYRO_FLAGS,
    )
    _launch_for_task(chosen_task, args=remaining_args)


if __name__ == "__main__":
    main()
