# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Seeding helpers for reproducible training and evaluation."""

from __future__ import annotations

import os
import random

import numpy as np
import torch


def generate_seed() -> int:
    """Draw a fresh seed from OS entropy, independent of any seeded RNG."""
    return int.from_bytes(os.urandom(4), "little") % (2**31)


def set_seed(seed: int, deterministic: bool = False) -> int:
    """Seed all host-side RNGs: Python ``random``, NumPy, torch CPU and GPU.

    Genesis kernel-side randomness is seeded separately via
    ``gs.init(seed=...)``; pass the same seed there before building a scene
    for fully seeded simulation.

    Args:
      seed: Seed applied to every RNG.
      deterministic: Also enable deterministic torch algorithms.

    Returns:
      The seed, for convenience.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        torch.use_deterministic_algorithms(True, warn_only=True)
    return seed
