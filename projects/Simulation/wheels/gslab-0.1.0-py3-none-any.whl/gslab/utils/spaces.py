# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
"""Lightweight space definitions for environment observations and actions.

This module provides minimal space representations to replace gymnasium.spaces,
focusing only on what mjlab needs (shape and dtype information for batching).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal


@dataclass
class Space:
    """Base space class with shape and dtype information."""

    shape: tuple[int, ...] = ()
    dtype: Literal["float32", "int32", "int64", "uint8"] = "float32"


@dataclass
class Box(Space):
    """Continuous space with optional bounds."""

    low: float | tuple[float, ...] = -math.inf
    high: float | tuple[float, ...] = math.inf


@dataclass
class Dict(Space):
    """Dictionary space containing multiple named subspaces."""

    spaces: dict[str, Space] = field(default_factory=dict)
