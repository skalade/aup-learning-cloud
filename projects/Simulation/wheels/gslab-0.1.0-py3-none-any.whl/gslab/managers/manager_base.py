# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ManagerTermBaseCfg:
    """Base configuration for manager terms.

    This is the base config for terms in observation, reward, termination, curriculum,
    and event managers. It provides a common interface for specifying a callable
    and its parameters.

    The ``func`` field accepts either a function or a class:

    **Function-based terms** are simpler and suitable for stateless computations:

    .. code-block:: python

        RewardTermCfg(func=mdp.joint_torques_l2, weight=-0.01)

    **Class-based terms** are instantiated with ``(cfg, env)`` and useful when you need
    to:

    - Cache computed values at initialization (e.g., resolve regex patterns to indices)
    - Maintain state across calls
    - Perform expensive setup once rather than every call

    .. code-block:: python

        class posture:
          def __init__(self, cfg: RewardTermCfg, env: ManagerBasedRlEnv):
            # Resolve std dict to tensor once at init
            self.std = resolve_std_to_tensor(cfg.params["std"], env)

          def __call__(self, env, **kwargs) -> torch.Tensor:
            # Use cached self.std
            return compute_posture_reward(env, self.std)

        RewardTermCfg(func=posture, params={"std": {".*knee.*": 0.3}}, weight=1.0)

    Class-based terms can optionally implement ``reset(env_ids)`` for per-episode state.
    """

    func: Any
    """The callable that computes this term's value. Can be a function or a class.
    Classes are auto-instantiated with ``(cfg=term_cfg, env=env)``."""

    params: dict[str, Any] = field(default_factory=lambda: {})
    """Additional keyword arguments passed to func when called."""
