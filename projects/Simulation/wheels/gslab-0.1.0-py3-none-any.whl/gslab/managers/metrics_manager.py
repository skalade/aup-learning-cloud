# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING

import torch

from .manager_base import ManagerTermBaseCfg

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv


# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
@dataclass(kw_only=True)
class MetricsTermCfg(ManagerTermBaseCfg):
    """Configuration for a metrics term."""

    pass


class GenesisMetricsManager:
    """Track episodic metrics from configured term functions.

    Command-following diagnostics live on the command terms themselves; see
    ``CommandTerm.metrics`` and ``GenesisCommandManager.pop_episode_logs``.
    """

    def __init__(self, cfg: dict[str, MetricsTermCfg], env: GenesisManagerBasedRlEnv):
        self.cfg = deepcopy(cfg)
        self._env = env
        self.active_terms: tuple[str, ...] = tuple(self.cfg.keys())
        self._episode_sums = {
            name: torch.zeros(self._env.num_envs, device=self._env.device)
            for name in self.active_terms
        }
        self._episode_counts = torch.zeros(
            self._env.num_envs, device=self._env.device, dtype=torch.long
        )

    def reset(self, env_ids: torch.Tensor | None = None) -> None:
        if env_ids is None:
            for sums in self._episode_sums.values():
                sums.zero_()
            self._episode_counts.zero_()
            return

        for sums in self._episode_sums.values():
            sums[env_ids] = 0.0
        self._episode_counts[env_ids] = 0

    def compute(self) -> None:
        if not self.cfg:
            return
        env = self._env
        self._episode_counts += 1
        for name, term_cfg in self.cfg.items():
            value = term_cfg.func(env, **term_cfg.params)
            self._episode_sums[name] += torch.as_tensor(value, device=env.device)

    def pop_episode_logs(self, env_ids: torch.Tensor) -> dict[str, torch.Tensor]:
        if env_ids.numel() == 0:
            return {}

        logs: dict[str, torch.Tensor] = {}
        if self._episode_sums:
            counts = torch.clamp(self._episode_counts[env_ids].float(), min=1.0)
            for name, sums in self._episode_sums.items():
                logs[f"Episode_Metrics/{name}"] = torch.mean(sums[env_ids] / counts)

        self.reset(env_ids)
        return logs
