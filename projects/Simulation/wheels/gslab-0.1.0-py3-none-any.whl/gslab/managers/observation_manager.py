# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

import torch

from gslab.envs.mdp.observations import term_shape as infer_term_shape

from .manager_base import ManagerTermBaseCfg

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv


# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
@dataclass
class ObservationTermCfg(ManagerTermBaseCfg):
    """Configuration for an observation term.

    Processing pipeline: compute → noise → clip → scale → delay → history.
    Delay models sensor latency. History provides temporal context. Both are optional
    and can be combined.
    """

    clip: tuple[float, float] | None = None
    """Range (min, max) to clip the observation values."""

    scale: tuple[float, ...] | float | torch.Tensor | None = None
    """Scaling factor(s) to multiply the observation by."""

    delay_min_lag: int = 0
    """Minimum lag (in steps) for delayed observations. Lag sampled uniformly from
  [min_lag, max_lag]. Convert to ms: lag * (1000 / control_hz)."""

    delay_max_lag: int = 0
    """Maximum lag (in steps) for delayed observations. Use min=max for constant delay."""

    delay_per_env: bool = True
    """If True, each environment samples its own lag. If False, all environments share
  the same lag at each step."""

    delay_hold_prob: float = 0.0
    """Probability of reusing the previous lag instead of resampling. Useful for
  temporally correlated latency patterns."""

    delay_update_period: int = 0
    """Resample lag every N steps (models multi-rate sensors). If 0, update every step."""

    delay_per_env_phase: bool = True
    """If True and update_period > 0, stagger update timing across envs to avoid
  synchronized resampling."""

    history_length: int = 0
    """Number of past observations to keep in history. 0 = no history."""

    flatten_history_dim: bool = True
    """Whether to flatten the history dimension into observation.

  When True and concatenate_terms=True, uses term-major ordering:
  [A_t0, A_t1, ..., A_tH-1, B_t0, B_t1, ..., B_tH-1, ...]
  See docs/source/observation.rst for details on ordering."""


@dataclass
class ObservationGroupCfg:
    """Configuration for an observation group.

    An observation group bundles multiple observation terms together. Groups are
    typically used to separate observations for different purposes (e.g., "actor"
    for the actor, "critic" for the value function).
    """

    terms: dict[str, ObservationTermCfg]
    """Dictionary mapping term names to their configurations."""

    concatenate_terms: bool = True
    """Whether to concatenate all terms into a single tensor. If False, returns
  a dict mapping term names to their individual tensors."""

    concatenate_dim: int = -1
    """Dimension along which to concatenate terms. Default -1 (last dimension)."""

    enable_corruption: bool = False
    """Whether to apply noise corruption to observations. Set to True during
  training for domain randomization, False during evaluation."""

    history_length: int | None = None
    """Group-level history length override. If set, applies to all terms in
  this group. If None, each term uses its own ``history_length`` setting."""

    flatten_history_dim: bool = True
    """Whether to flatten history into the observation dimension. If True,
  observations have shape ``(num_envs, obs_dim * history_length)``. If False,
  shape is ``(num_envs, history_length, obs_dim)``."""

    nan_policy: Literal["disabled", "warn", "sanitize", "error"] = "disabled"
    """NaN/Inf handling policy for observations in this group.

  - 'disabled': No checks (default, fastest)
  - 'warn': Log warning with term name and env IDs, then sanitize (debugging)
  - 'sanitize': Silent sanitization to 0.0 like reward manager (safe for production)
  - 'error': Raise ValueError on NaN/Inf (strict development mode)
  """

    nan_check_per_term: bool = True
    """If True, check each observation term individually to identify NaN source.
  If False, check only the final concatenated output (faster but less informative).
  Only applies when nan_policy != 'disabled'."""


class GenesisObservationManager:
    """Compute configured observation groups for the Genesis environment."""

    def __init__(
        self, cfg: dict[str, ObservationGroupCfg], env: GenesisManagerBasedRlEnv
    ):
        self.cfg = deepcopy(cfg)
        self._env = env
        self.active_terms: dict[str, list[str]] = {
            group_name: list(group_cfg.terms.keys())
            for group_name, group_cfg in self.cfg.items()
        }
        self._history_buffers: dict[tuple[str, str], torch.Tensor] = {}

    def reset(self, env_ids: torch.Tensor | None = None) -> None:
        if not self._history_buffers:
            return
        if env_ids is None:
            for history in self._history_buffers.values():
                history.zero_()
            return
        for history in self._history_buffers.values():
            history[env_ids] = 0.0

    def compute(self) -> dict[str, torch.Tensor]:
        return {
            group_name: self._compute_group(group_name, group_cfg)
            for group_name, group_cfg in self.cfg.items()
        }

    def _compute_group(self, group_name: str, group_cfg: ObservationGroupCfg):
        terms = {
            term_name: self._compute_term(
                group_name=group_name,
                group_cfg=group_cfg,
                term_name=term_name,
                term_cfg=term_cfg,
            )
            for term_name, term_cfg in group_cfg.terms.items()
        }
        if not group_cfg.concatenate_terms:
            return terms
        return torch.cat(
            [value.reshape(self._env.num_envs, -1) for value in terms.values()],
            dim=group_cfg.concatenate_dim,
        )

    def _compute_term(
        self,
        group_name: str,
        group_cfg: ObservationGroupCfg,
        term_name: str,
        term_cfg: ObservationTermCfg,
    ) -> torch.Tensor:
        term_value = term_cfg.func(self._env, **term_cfg.params)
        term_value = torch.as_tensor(term_value, device=self._env.device)
        value = self._apply_post_processing(term_value, term_cfg)
        return self._apply_history(group_name, term_name, group_cfg, term_cfg, value)

    def _apply_post_processing(
        self, value: torch.Tensor, term_cfg: ObservationTermCfg
    ) -> torch.Tensor:
        scale = getattr(term_cfg, "scale", None)
        if scale is not None:
            if isinstance(scale, torch.Tensor):
                value = value * scale.to(device=value.device, dtype=value.dtype)
            elif isinstance(scale, (float, int)):
                value = value * float(scale)
            elif isinstance(scale, tuple | list):
                value = value * torch.as_tensor(
                    scale, device=value.device, dtype=value.dtype
                )

        clip = getattr(term_cfg, "clip", None)
        if clip is not None:
            value = torch.clamp(value, min=clip[0], max=clip[1])

        return value

    def _resolve_history(
        self, group_cfg: ObservationGroupCfg, term_cfg: ObservationTermCfg
    ) -> tuple[int, bool]:
        if group_cfg.history_length is not None:
            return group_cfg.history_length, group_cfg.flatten_history_dim
        return term_cfg.history_length, term_cfg.flatten_history_dim

    def _apply_history(
        self,
        group_name: str,
        term_name: str,
        group_cfg: ObservationGroupCfg,
        term_cfg: ObservationTermCfg,
        value: torch.Tensor,
    ) -> torch.Tensor:
        history_length, flatten_history_dim = self._resolve_history(group_cfg, term_cfg)
        if history_length <= 1:
            return value

        key = (group_name, term_name)
        expected_shape = (self._env.num_envs, history_length, *value.shape[1:])
        history = self._history_buffers.get(key)
        if history is None or tuple(history.shape) != expected_shape:
            history = torch.zeros(
                expected_shape, device=value.device, dtype=value.dtype
            )
            self._history_buffers[key] = history

        history[:, :-1] = history[:, 1:].clone()
        history[:, -1] = value
        if flatten_history_dim:
            return history.reshape(self._env.num_envs, -1)
        return history

    def term_shape(self, group_name: str, term_name: str, term_cfg: ObservationTermCfg):
        shape = infer_term_shape(self._env, term_cfg)

        group_cfg = self.cfg[group_name]
        history_length, flatten_history_dim = self._resolve_history(group_cfg, term_cfg)
        if history_length <= 1:
            return shape
        if flatten_history_dim:
            return (history_length * int(torch.tensor(shape).prod().item()),)
        return (history_length,) + shape
