# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

import torch

from .manager_base import ManagerTermBaseCfg

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv


EventMode = Literal["startup", "reset", "interval", "step"]


# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
@dataclass(kw_only=True)
class EventTermCfg(ManagerTermBaseCfg):
    """Configuration for an event term.

    Event terms trigger operations at specific simulation events. They are commonly
    used for domain randomization, state resets, and periodic perturbations.

    The modes determine when the event fires:

    - ``"startup"``: Once when the environment initializes. Use for parameters that
      should be randomized per-environment but stay constant for the whole run
      (e.g., foot friction domain randomization).
    - ``"reset"``: On every episode reset. Use for parameters that should vary
      between episodes (e.g., initial robot pose).
    - ``"interval"``: Periodically during simulation, controlled by
      ``interval_range_s`` (e.g., pushing the robot).
    - ``"step"``: Every environment step on all environments.
    """

    mode: EventMode
    """When the event triggers: ``"startup"``, ``"reset"``, ``"interval"`` or
  ``"step"``."""

    interval_range_s: tuple[float, float] | None = None
    """Time range in seconds for interval mode. The next trigger time is uniformly
  sampled from ``[min, max]``. Required when ``mode="interval"``."""

    is_global_time: bool = False
    """Whether all environments share the same interval timer. If True, all envs
  trigger simultaneously. If False (default), each env has an independent timer that
  resets on episode reset. Only applies to ``mode="interval"``."""


class GenesisEventManager:
    """Trigger event terms at startup, reset, interval, and step events.

    Each event term is bound to a single ``mode``. Terms are grouped by mode at
    construction time and dispatched through :meth:`apply`. Class-based terms that
    expose a ``reset(env_ids)`` method are reset alongside the environment.
    """

    def __init__(
        self, cfg: dict[str, EventTermCfg], env: GenesisManagerBasedRlEnv
    ) -> None:
        self.cfg = deepcopy(cfg)
        self._env = env
        self._mode_term_names: dict[EventMode, list[str]] = {}
        self._mode_term_cfgs: dict[EventMode, list[EventTermCfg]] = {}
        # Per-interval-term countdown timers, aligned with the interval term order.
        self._interval_time_left: list[torch.Tensor] = []
        self._prepare_terms()

    @property
    def active_terms(self) -> dict[EventMode, list[str]]:
        return self._mode_term_names

    @property
    def available_modes(self) -> list[EventMode]:
        return list(self._mode_term_names.keys())

    def _prepare_terms(self) -> None:
        env = self._env
        for term_name, term_cfg in self.cfg.items():
            if term_cfg is None:
                continue
            self._mode_term_names.setdefault(term_cfg.mode, []).append(term_name)
            self._mode_term_cfgs.setdefault(term_cfg.mode, []).append(term_cfg)

            if term_cfg.mode == "interval":
                if term_cfg.interval_range_s is None:
                    raise ValueError(
                        f"Event term '{term_name}' has mode 'interval' but "
                        "'interval_range_s' is not specified."
                    )
                lower, upper = term_cfg.interval_range_s
                count = 1 if term_cfg.is_global_time else env.num_envs
                self._interval_time_left.append(
                    torch.rand(count, device=env.device) * (upper - lower) + lower
                )

    def reset(self, env_ids: torch.Tensor | None = None) -> dict:
        """Reset class-based term state and per-env interval timers."""
        env = self._env
        for term_cfgs in self._mode_term_cfgs.values():
            for term_cfg in term_cfgs:
                func = term_cfg.func
                if hasattr(func, "reset") and callable(func.reset):
                    func.reset(env_ids=env_ids)

        num_envs = env.num_envs if env_ids is None else len(env_ids)
        for index, term_cfg in enumerate(self._mode_term_cfgs.get("interval", [])):
            if term_cfg.is_global_time:
                continue
            assert term_cfg.interval_range_s is not None
            lower, upper = term_cfg.interval_range_s
            sampled = torch.rand(num_envs, device=env.device) * (upper - lower) + lower
            if env_ids is None:
                self._interval_time_left[index][:] = sampled
            else:
                self._interval_time_left[index][env_ids] = sampled
        return {}

    def apply(
        self,
        mode: EventMode,
        env_ids: torch.Tensor | None = None,
        dt: float | None = None,
    ) -> None:
        """Apply all event terms registered for ``mode``.

        Args:
          mode: The event mode to dispatch.
          env_ids: Environments to apply ``"reset"`` events to. ``None`` means all.
          dt: Environment step duration, required for ``"interval"`` mode.
        """
        if mode not in self._mode_term_cfgs:
            return

        if mode == "interval":
            if dt is None:
                raise ValueError("Event mode 'interval' requires the environment dt.")
            self._apply_interval(dt)
            return

        for term_cfg in self._mode_term_cfgs[mode]:
            term_cfg.func(self._env, env_ids, **term_cfg.params)

    def _apply_interval(self, dt: float) -> None:
        env = self._env
        for index, term_cfg in enumerate(self._mode_term_cfgs["interval"]):
            time_left = self._interval_time_left[index]
            time_left -= dt
            assert term_cfg.interval_range_s is not None
            lower, upper = term_cfg.interval_range_s
            if term_cfg.is_global_time:
                if time_left[0] < 1e-6:
                    time_left[0] = (
                        torch.rand(1, device=env.device) * (upper - lower) + lower
                    )
                    term_cfg.func(env, None, **term_cfg.params)
            else:
                valid_env_ids = (time_left < 1e-6).nonzero().flatten()
                if len(valid_env_ids) > 0:
                    time_left[valid_env_ids] = (
                        torch.rand(len(valid_env_ids), device=env.device)
                        * (upper - lower)
                        + lower
                    )
                    term_cfg.func(env, valid_env_ids, **term_cfg.params)
