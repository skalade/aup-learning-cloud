# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING

import torch

from .manager_base import ManagerTermBaseCfg

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv


# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
@dataclass(kw_only=True)
class TerminationTermCfg(ManagerTermBaseCfg):
    """Configuration for a termination term."""

    time_out: bool = False
    """Whether the term contributes towards episodic timeouts."""


class GenesisTerminationManager:
    """Compute termination terms and keep per-term reset diagnostics."""

    def __init__(
        self, cfg: dict[str, TerminationTermCfg], env: GenesisManagerBasedRlEnv
    ) -> None:
        self.cfg = deepcopy(cfg)
        self._env = env
        self.active_terms: tuple[str, ...] = tuple(self.cfg.keys())
        self._terms = {
            name: torch.zeros(
                self._env.num_envs, device=self._env.device, dtype=torch.bool
            )
            for name in self.active_terms
        }

    def get_term_cfg(self, name: str):
        """Return the live term cfg used at compute time (mutable by curricula)."""
        if name not in self.cfg:
            raise ValueError(f"Term '{name}' not found in active terms.")
        return self.cfg[name]

    def reset(self, env_ids: torch.Tensor | None = None) -> None:
        if env_ids is None:
            for values in self._terms.values():
                values.zero_()
            return
        for values in self._terms.values():
            values[env_ids] = False

    def compute(self) -> tuple[torch.Tensor, torch.Tensor]:
        terminated = torch.zeros(
            self._env.num_envs, device=self._env.device, dtype=torch.bool
        )
        truncated = torch.zeros_like(terminated)

        for name, term_cfg in self.cfg.items():
            func = getattr(term_cfg, "func", None)
            if func is None:
                value = torch.zeros(
                    self._env.num_envs, device=self._env.device, dtype=torch.bool
                )
            else:
                value = torch.as_tensor(
                    func(self._env, **term_cfg.params),
                    device=self._env.device,
                    dtype=torch.bool,
                )
            self._terms[name][:] = value
            if getattr(term_cfg, "time_out", False):
                truncated |= value
            else:
                terminated |= value

        return terminated, truncated

    def pop_episode_logs(self, env_ids: torch.Tensor) -> dict[str, int]:
        if env_ids.numel() == 0:
            return {}
        logs: dict[str, int] = {}
        for name, values in self._terms.items():
            logs[f"Episode_Termination/{name}"] = torch.count_nonzero(
                values[env_ids]
            ).item()
            values[env_ids] = False
        return logs
