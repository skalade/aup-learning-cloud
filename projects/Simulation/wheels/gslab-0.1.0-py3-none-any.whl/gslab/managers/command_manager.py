# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.

from __future__ import annotations

import abc
from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING

import torch

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv


@dataclass(kw_only=True)
class CommandTermCfg(abc.ABC):
    """Configuration for a command generator term.

    Command terms generate goal commands for the agent (e.g., target velocity,
    target position). Commands are automatically resampled at configurable
    intervals. Concrete configs set ``class_type`` to their term class; the
    manager instantiates it with ``(cfg, env)``.
    """

    resampling_time_range: tuple[float, float]
    """Time range in seconds for command resampling. When the timer expires, a new
  command is sampled and the timer is reset to a value uniformly drawn from
  ``[min, max]``. Set both values equal for fixed-interval resampling."""

    debug_vis: bool = False
    """Whether to enable debug visualization for this command term. When True,
  the command term's ``_debug_vis_impl`` method is called each frame to render
  visual aids (e.g., velocity arrows, target markers)."""

    class_type: type | None = None
    """Term class instantiated by the manager as ``class_type(cfg, env)``."""


class CommandTerm(abc.ABC):
    """Base class for command terms.

    A command term owns a per-env command buffer and a resampling timer (in env
    steps). Subclasses implement ``_resample_command`` (draw new commands for the
    given env ids) and optionally ``_update_command`` (per-step post-processing,
    e.g. heading control or schedules).
    """

    def __init__(self, cfg: CommandTermCfg, env: GenesisManagerBasedRlEnv):
        self.cfg = cfg
        self._env = env
        self._time_left = torch.zeros(env.num_envs, device=env.device, dtype=torch.long)
        self.metrics: dict[str, torch.Tensor] = {}
        """Per-env metric accumulators (e.g. command-tracking error), summed each
      step by ``_update_metrics`` and logged/zeroed on episode reset."""

    @property
    @abc.abstractmethod
    def command(self) -> torch.Tensor:
        """The command tensor, shape ``(num_envs, dim)``."""
        raise NotImplementedError

    def reset(self, env_ids: torch.Tensor | None = None) -> None:
        if env_ids is None:
            self.command.zero_()
            self._time_left.zero_()
            for values in self.metrics.values():
                values.zero_()
            return
        self.command[env_ids] = 0.0
        self._time_left[env_ids] = 0
        for values in self.metrics.values():
            values[env_ids] = 0.0

    def resample(self, env_ids: torch.Tensor) -> None:
        """Draw new commands for ``env_ids`` and reset their timers."""
        if env_ids.numel() == 0:
            return
        self._resample_command(env_ids)
        min_time, max_time = self.cfg.resampling_time_range
        min_steps = max(1, int(min_time / self._env.step_dt))
        max_steps = max(min_steps + 1, int(max_time / self._env.step_dt) + 1)
        self._time_left[env_ids] = torch.randint(
            min_steps, max_steps, (env_ids.numel(),), device=self._env.device
        )

    def compute(self) -> None:
        """Advance timers one env step, resampling expired envs."""
        self._time_left -= 1
        env_ids = torch.nonzero(self._time_left <= 0, as_tuple=False).flatten()
        self.resample(env_ids)
        self._update_command()
        self._update_metrics()

    def hold(self) -> None:
        """Suspend automatic resampling (used by teleop/eval scripts)."""
        self._time_left[:] = 2**31 - 1

    @abc.abstractmethod
    def _resample_command(self, env_ids: torch.Tensor) -> None:
        raise NotImplementedError

    def _update_command(self) -> None:
        pass

    def _update_metrics(self) -> None:
        """Accumulate per-step values into ``self.metrics`` buffers."""
        pass


class GenesisCommandManager:
    """Manage command terms: buffers, periodic resampling, and lookup."""

    def __init__(self, cfg: dict[str, CommandTermCfg], env: GenesisManagerBasedRlEnv):
        self.cfg = deepcopy(cfg)
        self._env = env
        self._terms: dict[str, CommandTerm] = {}

    @property
    def active_terms(self) -> list[str]:
        return list(self._terms.keys())

    def initialize_buffers(self) -> None:
        for name, term_cfg in self.cfg.items():
            if term_cfg is None:
                continue
            if term_cfg.class_type is None:
                raise ValueError(
                    f"Command term '{name}' has no class_type; cannot build."
                )
            self._terms[name] = term_cfg.class_type(term_cfg, self._env)

    def get_command(self, name: str) -> torch.Tensor | None:
        """Return the command tensor of term ``name``, or None if absent."""
        term = self._terms.get(name)
        return term.command if term is not None else None

    def get_term(self, name: str) -> CommandTerm | None:
        """Return the command term ``name``, or None if absent."""
        return self._terms.get(name)

    def reset(self, env_ids: torch.Tensor | None = None) -> None:
        for term in self._terms.values():
            term.reset(env_ids)

    def resample(self, env_ids: torch.Tensor) -> None:
        for term in self._terms.values():
            term.resample(env_ids)

    def update(self) -> None:
        for term in self._terms.values():
            term.compute()

    def pop_episode_logs(self, env_ids: torch.Tensor) -> dict[str, torch.Tensor]:
        """Return per-term metric means for envs being reset.

        Accumulated per-step metric sums are normalized by the term's maximum
        resampling window (in env steps), mirroring Isaac Lab's command-term
        metric logging. Buffers are zeroed by ``reset`` during the subsequent
        env reset.
        """
        if env_ids.numel() == 0:
            return {}
        logs: dict[str, torch.Tensor] = {}
        for name, term in self._terms.items():
            if not term.metrics:
                continue
            max_command_time = term.cfg.resampling_time_range[1]
            max_command_step = max(max_command_time / self._env.step_dt, 1.0)
            for metric_name, values in term.metrics.items():
                logs[f"Metrics/{name}/{metric_name}"] = torch.mean(
                    values[env_ids] / max_command_step
                )
        return logs
