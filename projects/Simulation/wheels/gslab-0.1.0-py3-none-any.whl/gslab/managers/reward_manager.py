# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

from copy import deepcopy
from typing import TYPE_CHECKING

import torch

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv

from dataclasses import dataclass

from .manager_base import ManagerTermBaseCfg


# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
@dataclass(kw_only=True)
class RewardTermCfg(ManagerTermBaseCfg):
    """Configuration for a reward term."""

    weight: float
    """Weight multiplier for this reward term."""


class GenesisRewardManager:
    """Compute reward terms and keep per-episode aggregates."""

    def __init__(self, cfg: dict[str, RewardTermCfg], env: GenesisManagerBasedRlEnv):
        self.cfg = deepcopy(cfg)
        self._env = env
        self.active_terms: tuple[str, ...] = tuple(self.cfg.keys())
        self._episode_sums = {
            name: torch.zeros(self._env.num_envs, device=self._env.device)
            for name in self.active_terms
        }

    def get_term_cfg(self, name: str) -> RewardTermCfg:
        """Return the live term cfg used at compute time (mutable by curricula)."""
        if name not in self.cfg:
            raise ValueError(f"Term '{name}' not found in active terms.")
        return self.cfg[name]

    def reset(self, env_ids: torch.Tensor | None = None) -> None:
        if env_ids is None:
            for sums in self._episode_sums.values():
                sums.zero_()
            return
        for sums in self._episode_sums.values():
            sums[env_ids] = 0.0

    def compute(self) -> torch.Tensor:
        env = self._env
        rewards = torch.zeros(env.num_envs, device=env.device)

        scale = env.step_dt if env.cfg.scale_rewards_by_dt else 1.0
        for name, term_cfg in self.cfg.items():
            func = getattr(term_cfg, "func", None)
            if func is None:
                raw_value = torch.zeros(env.num_envs, device=env.device)
            else:
                raw_value = torch.as_tensor(
                    func(env, **term_cfg.params), device=env.device
                )
            weighted = term_cfg.weight * raw_value * scale
            weighted = torch.nan_to_num(weighted, nan=0.0, posinf=0.0, neginf=0.0)
            rewards += weighted
            self._episode_sums[name] += weighted

        return rewards

    def pop_episode_logs(self, env_ids: torch.Tensor) -> dict[str, torch.Tensor]:
        if env_ids.numel() == 0:
            return {}
        episode_length_s = max(self._env.max_episode_length_s, self._env.step_dt)
        logs = {
            f"Episode_Reward/{name}": torch.mean(sums[env_ids]) / episode_length_s
            for name, sums in self._episode_sums.items()
        }
        self.reset(env_ids)
        return logs
