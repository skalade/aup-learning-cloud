# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
"""Curriculum manager for updating environment quantities during training.

Mirrors the mjlab curriculum design, adapted to gslab's plain-class managers.
Each curriculum term is a function ``func(env, env_ids, **params)`` that may mutate
other managers' term configs (e.g. reward weights, command ranges) and returns a
snapshot of the values it changed for logging. Terms are (re)computed whenever
environments reset.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import torch

from .manager_base import ManagerTermBaseCfg

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv


@dataclass(kw_only=True)
class CurriculumTermCfg(ManagerTermBaseCfg):
    """Configuration for a curriculum term.

    Curriculum terms modify environment parameters during training to implement
    curriculum learning strategies (e.g. gradually widening command ranges or
    increasing task difficulty).
    """

    pass


class GenesisCurriculumManager:
    """Compute curriculum terms and expose their state for logging.

    ``compute`` is called with the ids of environments that just reset; each term
    updates its target (via the relevant manager's term cfg) and stores a state
    snapshot. ``pop_episode_logs`` turns those snapshots into ``Curriculum/<term>``
    scalars.
    """

    def __init__(
        self, cfg: dict[str, CurriculumTermCfg], env: GenesisManagerBasedRlEnv
    ):
        self.cfg = deepcopy(cfg)
        self._env = env
        self.active_terms: tuple[str, ...] = tuple(self.cfg.keys())
        self._state: dict[str, Any] = {name: None for name in self.active_terms}

    def compute(self, env_ids: torch.Tensor | None = None) -> None:
        for name, term_cfg in self.cfg.items():
            if term_cfg is None or getattr(term_cfg, "func", None) is None:
                continue
            self._state[name] = term_cfg.func(self._env, env_ids, **term_cfg.params)

    def pop_episode_logs(self) -> dict[str, float]:
        logs: dict[str, float] = {}
        for name, state in self._state.items():
            if state is None:
                continue
            if isinstance(state, dict):
                for key, value in state.items():
                    logs[f"Curriculum/{name}/{key}"] = _to_float(value)
            else:
                logs[f"Curriculum/{name}"] = _to_float(state)
        return logs


def _to_float(value: Any) -> float:
    if isinstance(value, torch.Tensor):
        return float(value.item())
    return float(value)
