# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
"""Configuration for scene entities used by manager terms."""

from dataclasses import dataclass


@dataclass
class SceneEntityCfg:
    """Configuration for a scene entity that is used by the manager's term.

    This configuration allows flexible specification of entity components either by name
    or by ID. During resolution, it ensures consistency between names and IDs, and can
    optimize to slice(None) when all components are selected.
    """

    name: str
    """The name of the entity in the scene."""

    body_names: str | tuple[str, ...] | None = None
    """Names of bodies to include. Can be a single string or tuple."""

    site_names: str | tuple[str, ...] | None = None
    """Names of sites to include. Can be a single string or tuple."""

    geom_names: str | tuple[str, ...] | None = None
    """Names of collision geoms to include. Can be a single string or tuple."""
