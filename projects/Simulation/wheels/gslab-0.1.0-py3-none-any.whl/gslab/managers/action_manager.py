# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

import re
from copy import deepcopy
from typing import TYPE_CHECKING

import torch

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv

import abc
from dataclasses import dataclass


# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
@dataclass(kw_only=True)
class ActionTermCfg(abc.ABC):
    """Configuration for an action term.

    Action terms process raw actions from the policy and apply them to entities
    in the scene (e.g., setting joint positions, velocities, or efforts).
    """

    entity_name: str
    """Name of the entity in the scene that this action term controls."""

    clip: dict[str, tuple] | None = None
    """Optional clipping bounds per transmission type. Maps transmission name
  (e.g., 'position', 'velocity') to (min, max) tuple."""


class GenesisActionManager:
    """Prepare and transform policy actions for the Genesis environment."""

    def __init__(self, cfg: dict[str, ActionTermCfg], env: GenesisManagerBasedRlEnv):
        self.cfg = deepcopy(cfg)
        self._env = env
        self._action_scale: torch.Tensor | None = None

    def configure_actuated_joints(self, joint_names: list[str]) -> None:
        self._action_scale = self._resolve_action_scale(joint_names)

    def target_dof_positions(
        self, actions: torch.Tensor, init_dof_pos: torch.Tensor
    ) -> torch.Tensor:
        if self._action_scale is None:
            raise RuntimeError("Action manager is not configured with actuated joints.")
        return init_dof_pos + actions * self._action_scale

    def _resolve_action_scale(self, joint_names: list[str]) -> torch.Tensor:
        scales = torch.ones(
            (self._env.num_envs, len(joint_names)), device=self._env.device
        )
        for action_cfg in self.cfg.values():
            action_cfg: ActionTermCfg
            scale = getattr(action_cfg, "scale", 1.0)
            actuator_names = getattr(action_cfg, "actuator_names", ())
            matched = {
                idx
                for pattern in actuator_names
                for idx, name in enumerate(joint_names)
                if re.fullmatch(pattern, name)
            }
            if isinstance(scale, (float, int)):
                for idx in matched:
                    scales[:, idx] = float(scale)
            elif isinstance(scale, dict):
                for pattern, value in scale.items():
                    for idx in matched:
                        if re.fullmatch(pattern, joint_names[idx]):
                            scales[:, idx] = float(value)
        return scales
