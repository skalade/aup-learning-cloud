# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Base actuator interface."""

from __future__ import annotations

from abc import ABC
from dataclasses import dataclass
from enum import Enum


class TransmissionType(str, Enum):
    """Transmission types for actuators."""

    JOINT = "joint"
    TENDON = "tendon"
    SITE = "site"


# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
@dataclass(kw_only=True)
class ActuatorCfg(ABC):
    target_names_expr: tuple[str, ...]
    """Targets that are part of this actuator group.

  Can be a tuple of names or tuple of regex expressions.
  """
