# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""MuJoCo built-in actuators.

This module provides actuators that use MuJoCo's native actuator implementations,
created programmatically via the MjSpec API.
"""

from __future__ import annotations

from dataclasses import dataclass

from .actuator import ActuatorCfg


# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
@dataclass(kw_only=True)
class BuiltinPositionActuatorCfg(ActuatorCfg):
    """Configuration for MuJoCo built-in position actuator.

    Under the hood, this creates a <position> actuator for each target and sets the
    stiffness, damping and effort limits accordingly.
    """

    stiffness: float
    """PD proportional gain."""
    damping: float
    """PD derivative gain."""
    effort_limit: float | None = None
    """Maximum actuator force/torque. If None, no limit is applied."""
