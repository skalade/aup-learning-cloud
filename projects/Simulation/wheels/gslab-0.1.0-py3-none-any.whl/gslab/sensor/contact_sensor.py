# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

import genesis as gs
import torch

from .sensor import SensorCfg

if TYPE_CHECKING:
    from genesis.engine.entities.rigid_entity import RigidEntity


@dataclass
class ContactMatch:
    """Specifies what to match on one side of a contact.

    Args:
      pattern: A regex (or tuple of regexes) matched against link names of the
        robot entity.
    """

    pattern: str | tuple[str, ...]


@dataclass
class ContactSensorCfg(SensorCfg):
    """Configuration for a contact sensor.

    A contact sensor watches contacts on a ``primary`` set of links. Patterns
    expand to multiple primaries (e.g. both feet on a humanoid); each primary
    becomes one column on the per-contact axis of the output tensors.

    Args:
      primary: Links to measure (e.g. the robot's feet). Typically a regex
        that resolves to multiple links.
      num_slots: Number of contacts to retain per primary. Almost always ``1``:
        most policies want one representative contact per primary, and pattern
        expansion already gives you many primaries.
      track_air_time: Whether to track per-primary air time (time since the
        link last left contact) and contact time. Exposed via
        ``ContactSensorData.current_air_time`` and friends.
      force_threshold: Contact-force norm above which a link counts as being
        in contact.
    """

    primary: ContactMatch
    num_slots: int = 1
    track_air_time: bool = False
    force_threshold: float = 1.0


@dataclass
class ContactSensorData:
    """Runtime data of a :class:`ContactSensor`, shaped ``(num_envs, num_primaries)``.

    ``current_air_time``/``last_air_time``/``current_contact_time`` are ``None``
    unless the sensor was configured with ``track_air_time=True``.
    """

    found: torch.Tensor
    """Boolean in-contact flag per primary link."""
    force: torch.Tensor
    """Net contact force per primary link in the link's local frame, shape
    ``(num_envs, num_primaries, 3)``."""
    current_air_time: torch.Tensor | None = None
    """Time since the link last left the ground (0 while in contact)."""
    last_air_time: torch.Tensor | None = None
    """Air time of the most recently completed flight, latched on touchdown."""
    current_contact_time: torch.Tensor | None = None
    """Time the link has been continuously in contact (0 while in the air)."""


class ContactSensor:
    """Contact sensor over a set of robot links, updated once per env step.

    A thin adapter over Genesis' built-in ``ContactForce`` sensors (one per
    matched link): derives an in-contact flag per primary link from the sensed
    force, and (optionally) integrates per-link air/contact time. Must be
    created before the scene is built.
    """

    def __init__(
        self,
        cfg: ContactSensorCfg,
        scene: gs.Scene,
        robot: RigidEntity,
        num_envs: int,
        device: torch.device | str,
    ):
        self.cfg = cfg
        self._num_envs = num_envs
        self._device = device

        patterns = cfg.primary.pattern
        if isinstance(patterns, str):
            patterns = (patterns,)
        self._links = [
            link
            for pattern in patterns
            for link in robot.links
            if re.fullmatch(pattern, link.name)
        ]
        if not self._links:
            raise ValueError(
                f"Contact sensor '{cfg.name}': pattern {cfg.primary.pattern!r} "
                f"matched no links. Available: {[link.name for link in robot.links]}"
            )
        self._gs_sensors = [
            scene.add_sensor(
                gs.sensors.ContactForce(
                    entity_idx=robot.idx,
                    link_idx_local=link.idx_local,
                )
            )
            for link in self._links
        ]

        num = len(self._links)
        self.data = ContactSensorData(
            found=torch.zeros(num_envs, num, dtype=torch.bool, device=device),
            force=torch.zeros(num_envs, num, 3, device=device),
        )
        if cfg.track_air_time:
            self.data.current_air_time = torch.zeros(num_envs, num, device=device)
            self.data.last_air_time = torch.zeros(num_envs, num, device=device)
            self.data.current_contact_time = torch.zeros(num_envs, num, device=device)

    @property
    def num_primaries(self) -> int:
        return len(self._links)

    @property
    def link_names(self) -> list[str]:
        return [link.name for link in self._links]

    def update(self, dt: float) -> None:
        force = torch.stack(
            [sensor.read_ground_truth() for sensor in self._gs_sensors], dim=-2
        )
        if force.dim() == 2:  # single-env layout (N, 3)
            force = force.unsqueeze(0)
        self.data.force = force
        found = torch.norm(force, dim=-1) > self.cfg.force_threshold

        if self.cfg.track_air_time:
            air = self.data.current_air_time
            contact = self.data.current_contact_time
            last_air = self.data.last_air_time
            assert air is not None and contact is not None and last_air is not None
            touchdown = found & ~self.data.found
            last_air[touchdown] = air[touchdown]
            self.data.current_air_time = torch.where(
                found, torch.zeros_like(air), air + dt
            )
            self.data.current_contact_time = torch.where(
                found, contact + dt, torch.zeros_like(contact)
            )

        self.data.found = found

    def reset(self, env_ids: torch.Tensor | None = None) -> None:
        ids = slice(None) if env_ids is None else env_ids
        self.data.found[ids] = False
        self.data.force[ids] = 0.0
        if self.cfg.track_air_time:
            assert self.data.current_air_time is not None
            assert self.data.last_air_time is not None
            assert self.data.current_contact_time is not None
            self.data.current_air_time[ids] = 0.0
            self.data.last_air_time[ids] = 0.0
            self.data.current_contact_time[ids] = 0.0
