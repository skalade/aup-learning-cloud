# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
#
# The grid pattern and the clipped `base_z - offset - ground` encoding follow
# Isaac Lab's `RayCasterCfg` / `height_scan`.
"""Terrain height scanning around the robot base.

The exteroceptive counterpart to the contact sensors: a grid of ground-height
samples ahead of and around the robot, so a policy can see a step before a foot
reaches it.

Isaac Lab ray-casts this pattern against the terrain mesh. gslab reads it
straight out of the heightfield the terrain was generated from
(``TerrainEntity.height_at``), which is exact for heightfield terrain, has no
per-ray cost, and needs no ray-casting backend. Like Isaac Lab's scanner, the
result is noise-free ground truth — realistic elevation-map error would have to
be added on top before this transfers to a real robot.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch

from .sensor import SensorCfg


@dataclass
class GridPatternCfg:
    """A rectangular grid of sample points in the sensor frame."""

    resolution: float = 0.1
    """Spacing between sample points, in meters."""
    size: tuple[float, float] = (1.6, 1.0)
    """Extent of the grid (length along x, width along y), in meters."""

    def offsets(self, device: torch.device | str) -> torch.Tensor:
        """Sample points as ``(num_points, 2)`` xy offsets in the sensor frame."""
        half_x, half_y = self.size[0] / 2.0, self.size[1] / 2.0
        xs = torch.arange(
            -half_x, half_x + 1e-6, self.resolution, device=device, dtype=torch.float32
        )
        ys = torch.arange(
            -half_y, half_y + 1e-6, self.resolution, device=device, dtype=torch.float32
        )
        grid_x, grid_y = torch.meshgrid(xs, ys, indexing="ij")
        return torch.stack((grid_x.reshape(-1), grid_y.reshape(-1)), dim=-1)

    @property
    def num_points(self) -> int:
        offsets = self.offsets("cpu")
        return int(offsets.shape[0])


@dataclass
class HeightScanCfg(SensorCfg):
    """Configuration for a terrain height scanner attached to the robot base."""

    pattern: GridPatternCfg = None  # type: ignore[assignment]
    """Grid of points to sample. Required."""
    offset: tuple[float, float] = (0.0, 0.0)
    """Centre of the grid relative to the base, in the base's yaw frame, in
  meters. Push it forward to look further ahead of the feet."""
    target_height: float = 0.5
    """Nominal base height above ground, in meters. Readings are offsets from
  this, so flat ground reads ~0 regardless of how tall the robot stands."""
    clip: tuple[float, float] = (-1.0, 1.0)
    """Range to clamp readings to, in meters. Bounds what a deep pit or a wall
  can contribute to the observation."""

    def __post_init__(self) -> None:
        if self.pattern is None:
            raise ValueError(f"HeightScanCfg '{self.name}' requires a pattern.")


def scan_heights(env, cfg: HeightScanCfg) -> torch.Tensor:
    """Sample terrain height around the base, shape ``(num_envs, num_points)``.

    Points are laid out in the base's **yaw** frame — roll and pitch are ignored
    so the pattern stays flat on the ground rather than swinging with the torso,
    which is what makes the reading interpretable while the robot pitches to
    climb.

    Returns ``target_height - (base_z - ground_z)`` clipped to ``cfg.clip``:
    positive where the ground rises toward the robot, negative over a drop.
    """
    base_pos = env.robot.get_pos()
    base_quat = env.robot.get_quat()

    # Yaw-only rotation, taken straight from the quaternion.
    w, x, y, z = base_quat.unbind(-1)
    yaw = torch.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))
    cos_yaw, sin_yaw = torch.cos(yaw), torch.sin(yaw)

    offsets = cfg.pattern.offsets(base_pos.device)
    grid_x = offsets[:, 0] + cfg.offset[0]
    grid_y = offsets[:, 1] + cfg.offset[1]

    # Rotate the pattern into the world frame, then translate onto the base.
    world_x = base_pos[:, 0:1] + cos_yaw[:, None] * grid_x - sin_yaw[:, None] * grid_y
    world_y = base_pos[:, 1:2] + sin_yaw[:, None] * grid_x + cos_yaw[:, None] * grid_y

    points = torch.stack((world_x, world_y), dim=-1)
    ground = env.terrain.height_at(points)
    reading = cfg.target_height - (base_pos[:, 2:3] - ground)
    return torch.clamp(reading, cfg.clip[0], cfg.clip[1])
