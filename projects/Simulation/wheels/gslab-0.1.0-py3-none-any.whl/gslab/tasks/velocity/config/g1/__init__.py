# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from gslab.rl import GslabOnPolicyRunner
from gslab.tasks.registry import register_gslab_task

from .env_cfgs import (
    unitree_g1_flat_env_cfg,
    unitree_g1_rough_env_cfg,
    unitree_g1_stairs_easy_env_cfg,
    unitree_g1_stairs_env_cfg,
    unitree_g1_stairs_history_env_cfg,
    unitree_g1_stairs_scan_env_cfg,
)
from .rl_cfg import unitree_g1_ppo_runner_cfg

register_gslab_task(
    task_id="Unitree-G1-Flat",
    env_cfg=unitree_g1_flat_env_cfg(),
    play_env_cfg=unitree_g1_flat_env_cfg(play=True),
    rl_cfg=unitree_g1_ppo_runner_cfg(),
    runner_cls=GslabOnPolicyRunner,
)

register_gslab_task(
    task_id="Unitree-G1-Rough",
    env_cfg=unitree_g1_rough_env_cfg(),
    play_env_cfg=unitree_g1_rough_env_cfg(play=True),
    rl_cfg=unitree_g1_ppo_runner_cfg(experiment_name="g1_velocity_rough"),
    runner_cls=GslabOnPolicyRunner,
)

register_gslab_task(
    task_id="Unitree-G1-Stairs",
    env_cfg=unitree_g1_stairs_env_cfg(),
    play_env_cfg=unitree_g1_stairs_env_cfg(play=True),
    rl_cfg=unitree_g1_ppo_runner_cfg(experiment_name="g1_velocity_stairs"),
    runner_cls=GslabOnPolicyRunner,
)

# Two ways to give the policy terrain information, registered side by side so
# they can be compared on identical terrain and rewards.

register_gslab_task(
    task_id="Unitree-G1-Stairs-History",
    env_cfg=unitree_g1_stairs_history_env_cfg(),
    play_env_cfg=unitree_g1_stairs_history_env_cfg(play=True),
    rl_cfg=unitree_g1_ppo_runner_cfg(experiment_name="g1_stairs_history"),
    runner_cls=GslabOnPolicyRunner,
)

register_gslab_task(
    task_id="Unitree-G1-Stairs-Scan",
    env_cfg=unitree_g1_stairs_scan_env_cfg(),
    play_env_cfg=unitree_g1_stairs_scan_env_cfg(play=True),
    rl_cfg=unitree_g1_ppo_runner_cfg(experiment_name="g1_stairs_scan"),
    runner_cls=GslabOnPolicyRunner,
)

register_gslab_task(
    task_id="Unitree-G1-Stairs-Easy",
    env_cfg=unitree_g1_stairs_easy_env_cfg(),
    play_env_cfg=unitree_g1_stairs_easy_env_cfg(play=True),
    rl_cfg=unitree_g1_ppo_runner_cfg(experiment_name="g1_stairs_easy"),
    runner_cls=GslabOnPolicyRunner,
)
