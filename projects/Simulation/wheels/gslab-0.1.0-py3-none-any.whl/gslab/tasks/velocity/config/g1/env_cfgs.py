# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Unitree G1 velocity environment configurations."""

from copy import deepcopy

from gslab.assets.robots import (
    G1_ACTION_SCALE,
    get_g1_robot_cfg,
)
from gslab.assets.robots.unitree_g1.g1_constants import G1_XML
from gslab.envs import ManagerBasedRlEnvCfg
from gslab.managers.curriculum_manager import CurriculumTermCfg
from gslab.managers.observation_manager import ObservationTermCfg
from gslab.sensor import (
    ContactMatch,
    ContactSensorCfg,
    GridPatternCfg,
    HeightScanCfg,
)
from gslab.tasks.velocity import mdp
from gslab.tasks.velocity.mdp import UniformVelocityCommandCfg
from gslab.tasks.velocity.velocity_env_cfg import make_velocity_env_cfg
from gslab.terrains.config import (
    EASY_STAIRS_TERRAINS_CFG,
    ROUGH_TERRAINS_CFG,
    STAIRS_TERRAINS_CFG,
)
from gslab.terrains.terrain_generator import TerrainGeneratorCfg


def unitree_g1_flat_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
    """Create Unitree G1 flat terrain velocity configuration."""
    cfg = make_velocity_env_cfg(G1_XML)

    # Curriculum is opt-in for G1; re-enable by restoring the base config terms.
    cfg.curriculum = {}

    cfg.sim.nconmax = 48

    cfg.scene.entities = {"robot": get_g1_robot_cfg()}

    cfg.scene.sensors = tuple()

    site_names = ("left_foot", "right_foot")

    feet_ground_cfg = ContactSensorCfg(
        name="feet_ground_contact",
        primary=ContactMatch(
            pattern=r"^(left_ankle_roll_link|right_ankle_roll_link)$",
        ),
        num_slots=1,
        track_air_time=True,
    )
    self_collision_cfg = ContactSensorCfg(
        name="self_collision",
        primary=ContactMatch(pattern="pelvis"),
        num_slots=1,
    )
    cfg.scene.sensors = (
        feet_ground_cfg,
        self_collision_cfg,
    )

    joint_pos_action = cfg.actions["joint_pos"]
    joint_pos_action.scale = G1_ACTION_SCALE

    cfg.viewer.body_name = "torso_link"
    cfg.viewer.azimuth = 180.0
    cfg.viewer.elevation = -20.0

    twist_cmd = cfg.commands["twist"]
    assert isinstance(twist_cmd, UniformVelocityCommandCfg)
    twist_cmd.viz.z_offset = 1.15

    cfg.observations["critic"].terms["foot_height"].params[
        "asset_cfg"
    ].site_names = site_names

    # The ankle-roll links carry exactly the foot collision capsules.
    cfg.events["foot_friction"].params["asset_cfg"].body_names = (
        "left_ankle_roll_link",
        "right_ankle_roll_link",
    )
    # cfg.events["base_com"].params["asset_cfg"].body_names = ("torso_link",)

    # Rationale for std values:
    # - Knees/hip_pitch get the loosest std to allow natural leg bending during stride.
    # - Hip roll/yaw stay tighter to prevent excessive lateral sway and keep gait stable.
    # - Ankle roll is very tight for balance; ankle pitch looser for foot clearance.
    # - Waist roll/pitch stay tight to keep the torso upright and stable.
    # - Shoulders/elbows get moderate freedom for natural arm swing during walking.
    # - Wrists are loose (0.3) since they don't affect balance much.
    # Running values are ~1.5-2x walking values to accommodate larger motion range.
    cfg.rewards["pose"].params["std_standing"] = {".*": 0.05}
    cfg.rewards["pose"].params["std_walking"] = {
        # Lower body.
        r".*hip_pitch.*": 0.5,
        r".*hip_roll.*": 0.15,
        r".*hip_yaw.*": 0.15,
        r".*knee.*": 0.5,
        r".*ankle_pitch.*": 0.15,
        r".*ankle_roll.*": 0.1,
        # Waist.
        r".*waist_yaw.*": 0.15,
        r".*waist_roll.*": 0.1,
        r".*waist_pitch.*": 0.1,
        # Arms.
        r".*shoulder_pitch.*": 0.15,
        r".*shoulder_roll.*": 0.1,
        r".*shoulder_yaw.*": 0.1,
        r".*elbow.*": 0.1,
        r".*wrist.*": 0.1,
    }
    cfg.rewards["pose"].params["std_running"] = {
        # Lower body.
        r".*hip_pitch.*": 0.5,
        r".*hip_roll.*": 0.25,
        r".*hip_yaw.*": 0.25,
        r".*knee.*": 0.5,
        r".*ankle_pitch.*": 0.25,
        r".*ankle_roll.*": 0.1,
        # Waist.
        r".*waist_yaw.*": 0.25,
        r".*waist_roll.*": 0.1,
        r".*waist_pitch.*": 0.1,
        # Arms.
        r".*shoulder_pitch.*": 0.25,
        r".*shoulder_roll.*": 0.1,
        r".*shoulder_yaw.*": 0.1,
        r".*elbow.*": 0.1,
        r".*wrist.*": 0.1,
    }

    cfg.rewards["body_orientation_l2"].params["asset_cfg"].body_names = ("torso_link",)
    cfg.rewards["body_ang_vel"].params["asset_cfg"].body_names = ("torso_link",)
    cfg.rewards["foot_clearance"].params["asset_cfg"].site_names = site_names
    cfg.rewards["foot_slip"].params["asset_cfg"].site_names = site_names
    # Apply play mode overrides.
    if play:
        # Effectively infinite episode length.
        cfg.episode_length_s = int(1e9)

        cfg.observations["actor"].enable_corruption = False
        # cfg.events.pop("push_robot", None)

    cfg.sim.nconmax = None

    # Switch to flat terrain.
    assert cfg.scene.terrain is not None
    cfg.scene.terrain.terrain_type = "plane"

    if play:
        twist_cmd = cfg.commands["twist"]
        assert isinstance(twist_cmd, UniformVelocityCommandCfg)
        twist_cmd.ranges.lin_vel_x = (-0.5, 1.0)
        twist_cmd.ranges.lin_vel_y = (-0.5, 0.5)
        twist_cmd.ranges.ang_vel_z = (-0.5, 0.5)

    return cfg


def unitree_g1_rough_env_cfg(
    play: bool = False,
    terrain_generator: TerrainGeneratorCfg | None = None,
    terrain_name: str = "g1_rough",
) -> ManagerBasedRlEnvCfg:
    """Create Unitree G1 rough terrain velocity configuration.

    Starts from the flat config and swaps in procedurally generated terrain, so
    the observation and action spaces are byte-identical to
    ``Unitree-G1-Flat``. That is deliberate: it is what lets a flat-ground
    checkpoint be fine-tuned here (see ``scripts/finetune_terrain.py``) instead
    of retraining from scratch.

    Args:
      play: Apply play-mode overrides (endless episodes, no observation noise).
      terrain_generator: Terrain to build. Defaults to ``ROUGH_TERRAINS_CFG``.
      terrain_name: Cache key for the generated heightfield. Must differ between
        terrain configs, or Genesis will reuse the wrong cached heightfield.
    """
    cfg = unitree_g1_flat_env_cfg(play=play)

    assert cfg.scene.terrain is not None
    cfg.scene.terrain.terrain_type = "generator"
    cfg.scene.terrain.terrain_generator = deepcopy(
        terrain_generator if terrain_generator is not None else ROUGH_TERRAINS_CFG
    )
    cfg.scene.terrain.name = terrain_name

    # Halve the physics timestep, doubling decimation to hold the control rate
    # at 50 Hz so the policy interface is unchanged.
    #
    # Solid step geometry drives the constraint solver to NaN at the flat task's
    # 5 ms timestep: training died reproducibly with "Invalid constraint forces
    # causing 'nan'", at iteration 35 on the gentle ladder. Halving the timestep
    # is what Genesis' own error message recommends, and it holds -- verified
    # over 115 iterations with no failures. It costs roughly 2x per iteration,
    # which is the price of having stairs the robot cannot tunnel through.
    cfg.sim.mujoco.timestep = 0.0025
    cfg.decimation = 8
    # Start on the two easiest difficulty levels; the curriculum promotes from
    # there. Starting anywhere on the ladder would drown the early batches in
    # terrain the flat policy cannot survive.
    cfg.scene.terrain.max_init_terrain_level = 1
    # Several environments share a patch, so scatter their spawn points a little
    # to keep the rollouts from being near-identical. Stays inside the 2.5 m
    # centre platform of the stairs sub-terrains.
    cfg.scene.terrain.spawn_jitter = 0.6

    # Terrain difficulty is now the curriculum axis. Command ranges stay fixed
    # and modest: pushing speed and terrain at the same time makes the fine-tune
    # much harder to land in a workshop-sized number of iterations.
    cfg.curriculum = {
        "terrain_levels": CurriculumTermCfg(
            func=mdp.terrain_levels_vel,
            params={"command_name": "twist"},
        ),
    }

    twist_cmd = cfg.commands["twist"]
    assert isinstance(twist_cmd, UniformVelocityCommandCfg)
    twist_cmd.ranges.lin_vel_x = (-0.6, 1.0)
    twist_cmd.ranges.lin_vel_y = (-0.4, 0.4)
    twist_cmd.ranges.ang_vel_z = (-0.6, 0.6)
    # Fewer standing environments: the terrain curriculum measures distance
    # walked, and a standing robot always reads as "failed to advance".
    twist_cmd.rel_standing_envs = 0.0

    # Feet have to clear a step, not just a bump. This has no effect yet —
    # mdp.foot_clearance is still a stub returning zeros — but it keeps the
    # terrain-appropriate target with the rest of the terrain config for when
    # the reward is implemented.
    cfg.rewards["foot_clearance"].params["target_height"] = 0.14

    # Uneven ground tilts the torso more than flat ground ever did; keeping the
    # flat penalty would fight the stair-climbing motion.
    cfg.rewards["body_orientation_l2"].weight = -0.5

    if play:
        # One patch per column at a fixed, showable difficulty reads better than
        # a curriculum mid-flight.
        cfg.scene.terrain.max_init_terrain_level = None
        cfg.scene.terrain.debug_vis = True

    return cfg


def unitree_g1_stairs_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
    """Create Unitree G1 stairs velocity configuration.

    The RosCon 2026 workshop task: a curriculum of pyramid stairs up and down,
    with flat and lightly rough columns alongside so the policy keeps its
    flat-ground behaviour while it learns to climb.
    """
    return unitree_g1_rough_env_cfg(
        play=play,
        terrain_generator=STAIRS_TERRAINS_CFG,
        terrain_name="g1_stairs_v3",
    )


def unitree_g1_stairs_history_env_cfg(
    play: bool = False, history_length: int = 10
) -> ManagerBasedRlEnvCfg:
    """G1 stairs with a proprioceptive observation history — the "blind" setup.

    Identical to ``Unitree-G1-Stairs`` except that the actor sees the last
    ``history_length`` frames instead of one. This is the difference between a
    policy that knows how tilted it is right now and one that can notice its
    feet have been contacting early for three steps running, which is the only
    signal a blind robot has that it is on a staircase.

    The observation width becomes ``history_length x`` the flat width, so a
    flat-ground checkpoint no longer loads directly; see
    ``scripts/expand_checkpoint.py``.
    """
    cfg = unitree_g1_stairs_env_cfg(play=play)
    cfg.observations["actor"].history_length = history_length
    # The critic already sees privileged state; giving it the same window keeps
    # the value function from being the weaker half of the pair.
    cfg.observations["critic"].history_length = history_length
    return cfg


def unitree_g1_stairs_scan_env_cfg(
    play: bool = False,
    resolution: float = 0.1,
    size: tuple[float, float] = (1.6, 1.0),
    forward_offset: float = 0.5,
) -> ManagerBasedRlEnvCfg:
    """G1 stairs with a terrain height scan — the "perceptive" setup.

    Adds a grid of ground-height samples in front of and under the robot to the
    actor's observations, so a step is visible before a foot reaches it. The
    grid is pushed forward by ``forward_offset`` because what matters is the
    ground the swing foot is heading for, not the ground already underneath.

    Defaults to a 17x11 grid (187 points) at 10 cm resolution, spanning 1.6 m
    ahead-to-behind and 1.0 m across.
    """
    cfg = unitree_g1_stairs_env_cfg(play=play)

    scan_cfg = HeightScanCfg(
        name="height_scan",
        pattern=GridPatternCfg(resolution=resolution, size=size),
        offset=(forward_offset, 0.0),
        # G1's pelvis rides at ~0.78 m, so this centres the reading on zero for
        # flat ground; a 16 cm step then reads +0.16 rather than as an offset
        # from somebody else's robot height.
        target_height=0.78,
    )
    cfg.scene.sensors = (*cfg.scene.sensors, scan_cfg)

    scan_term = ObservationTermCfg(
        func=mdp.height_scan,
        params={"sensor_name": "height_scan"},
    )
    # Appended last so the proprioceptive block keeps its offsets, which is what
    # lets a flat checkpoint's weights be transplanted unchanged.
    cfg.observations["actor"].terms["height_scan"] = scan_term
    cfg.observations["critic"].terms["height_scan"] = scan_term

    return cfg


def unitree_g1_stairs_easy_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
    """G1 on gentle stairs — the first step up from flat ground.

    Same rewards and curriculum as ``Unitree-G1-Stairs``, but every difficulty
    level is something a flat-ground policy can plausibly survive, and nearly
    half the terrain is flat. A policy that has only ever walked on a plane
    falls constantly on the full stairs terrain, gets demoted to the bottom of
    the ladder, and never encounters a step; here it keeps earning reward while
    it learns.
    """
    return unitree_g1_rough_env_cfg(
        play=play,
        terrain_generator=EASY_STAIRS_TERRAINS_CFG,
        terrain_name="g1_stairs_easy",
    )
