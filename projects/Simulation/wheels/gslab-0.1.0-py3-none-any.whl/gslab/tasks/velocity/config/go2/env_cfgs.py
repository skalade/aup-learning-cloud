# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Unitree Go2 velocity environment configurations."""

from gslab.assets.robots import (
    GO2_ACTION_SCALE,
    get_go2_robot_cfg,
)
from gslab.assets.robots.unitree_go2.go2_constants import GO2_XML
from gslab.envs import ManagerBasedRlEnvCfg
from gslab.sensor import ContactMatch, ContactSensorCfg
from gslab.tasks.velocity.mdp import UniformVelocityCommandCfg
from gslab.tasks.velocity.velocity_env_cfg import make_velocity_env_cfg

# Feet, in link order (matches the body order in the MJCF): FL, FR, RL, RR.
FOOT_SITES = ("FL_foot", "FR_foot", "RL_foot", "RR_foot")
# The foot collision spheres live on the calf links (alongside two collision
# cylinders, hence the sphere filter in the friction event below).
FOOT_LINKS = ("FL_calf", "FR_calf", "RL_calf", "RR_calf")


def unitree_go2_flat_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
    """Create Unitree Go2 flat terrain velocity configuration."""
    cfg = make_velocity_env_cfg(GO2_XML)

    cfg.scene.entities = {"robot": get_go2_robot_cfg()}

    # Foot-ground contact on the calf links (the foot geom is a child of the
    # calf body) and a base sensor to enable self-collision handling.
    feet_ground_cfg = ContactSensorCfg(
        name="feet_ground_contact",
        primary=ContactMatch(
            pattern=r"^(FL_calf|FR_calf|RL_calf|RR_calf)$",
        ),
        num_slots=1,
        track_air_time=True,
    )
    self_collision_cfg = ContactSensorCfg(
        name="self_collision",
        primary=ContactMatch(pattern="base"),
        num_slots=1,
    )
    cfg.scene.sensors = (
        feet_ground_cfg,
        self_collision_cfg,
    )

    joint_pos_action = cfg.actions["joint_pos"]
    joint_pos_action.scale = GO2_ACTION_SCALE

    cfg.viewer.body_name = "base"
    cfg.viewer.azimuth = 180.0
    cfg.viewer.elevation = -20.0

    twist_cmd = cfg.commands["twist"]
    assert isinstance(twist_cmd, UniformVelocityCommandCfg)
    twist_cmd.viz.z_offset = 0.4

    cfg.observations["critic"].terms["foot_height"].params[
        "asset_cfg"
    ].site_names = FOOT_SITES

    cfg.events["foot_friction"].params["asset_cfg"].body_names = FOOT_LINKS
    cfg.events["foot_friction"].params["geom_type"] = "sphere"

    cfg.rewards["body_orientation_l2"].params["asset_cfg"].body_names = ("base",)
    cfg.rewards["body_ang_vel"].params["asset_cfg"].body_names = ("base",)
    cfg.rewards["foot_clearance"].params["asset_cfg"].site_names = FOOT_SITES
    cfg.rewards["foot_slip"].params["asset_cfg"].site_names = FOOT_SITES

    # Trot gait: diagonal foot pairs move together. In FL, FR, RL, RR order the
    # pairs are (FL, RR) and (FR, RL), giving phase offsets [0.0, 0.5, 0.5, 0.0].
    cfg.rewards["foot_gait"].params["offset"] = [0.0, 0.5, 0.5, 0.0]

    # Reward rebalancing so forward locomotion actually emerges.
    #
    # With the gait-shaping rewards (foot_gait/clearance/slip) still stubbed to
    # zero, the only driver of translation is velocity tracking. Meanwhile the
    # default `pose` reward (weight 1.0) rewards holding the home crouch every
    # step, which -- together with the large fall penalty -- makes "stand and
    # spin in place" a strong local optimum (angular tracking is cheap and safe,
    # forward walking is costly and risky). We therefore make linear tracking the
    # dominant term and demote the posture regularizer to a light shaping term.
    cfg.rewards["track_linear_velocity"].weight = 2.5
    cfg.rewards["track_angular_velocity"].weight = 1.5
    cfg.rewards["pose"].weight = 0.2

    # The base velocity config's "command_vel" curriculum (gentle ranges first,
    # then full ranges) is inherited unchanged.

    # Apply play mode overrides.
    if play:
        # Effectively infinite episode length.
        cfg.episode_length_s = int(1e9)

        cfg.observations["actor"].enable_corruption = False
        cfg.curriculum = {}

        twist_cmd = cfg.commands["twist"]
        assert isinstance(twist_cmd, UniformVelocityCommandCfg)
        twist_cmd.ranges.lin_vel_x = (-0.5, 1.0)
        twist_cmd.ranges.lin_vel_y = (-0.5, 0.5)
        twist_cmd.ranges.ang_vel_z = (-0.5, 0.5)

    # Flat terrain.
    assert cfg.scene.terrain is not None
    cfg.scene.terrain.terrain_type = "plane"

    return cfg
