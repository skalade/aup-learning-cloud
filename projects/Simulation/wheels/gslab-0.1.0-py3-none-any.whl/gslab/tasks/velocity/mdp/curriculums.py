# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
"""Velocity-task curriculum terms."""

from __future__ import annotations

from typing import TYPE_CHECKING, TypedDict

import torch

from .velocity_command import UniformVelocityCommandCfg

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv


class VelocityStage(TypedDict):
    step: int
    lin_vel_x: tuple[float, float] | None
    lin_vel_y: tuple[float, float] | None
    ang_vel_z: tuple[float, float] | None


def commands_vel(
    env: GenesisManagerBasedRlEnv,
    env_ids: torch.Tensor | None,
    command_name: str,
    velocity_stages: list[VelocityStage],
) -> dict[str, torch.Tensor]:
    """Widen (or otherwise stage) the velocity command ranges over training.

    Mutates the command manager's live term cfg, so newly resampled commands use
    the updated ranges. Keyed on ``env.common_step_counter``; later reached
    stages take precedence.

    Example::

        CurriculumTermCfg(
            func=mdp.commands_vel,
            params={
                "command_name": "twist",
                "velocity_stages": [
                    {
                        "step": 0,
                        "lin_vel_x": (-0.5, 1.0),
                        "lin_vel_y": None,
                        "ang_vel_z": (-0.5, 0.5),
                    },
                    {
                        "step": 24_000,
                        "lin_vel_x": (-1.0, 2.0),
                        "lin_vel_y": None,
                        "ang_vel_z": (-1.0, 1.0),
                    },
                ],
            },
        )
    """
    del env_ids
    cfg = env.command_manager.cfg[command_name]
    assert isinstance(cfg, UniformVelocityCommandCfg)
    for stage in velocity_stages:
        if env.common_step_counter >= stage["step"]:
            if stage["lin_vel_x"] is not None:
                cfg.ranges.lin_vel_x = stage["lin_vel_x"]
            if stage["lin_vel_y"] is not None:
                cfg.ranges.lin_vel_y = stage["lin_vel_y"]
            if stage["ang_vel_z"] is not None:
                cfg.ranges.ang_vel_z = stage["ang_vel_z"]
    return {
        "lin_vel_x_min": torch.tensor(cfg.ranges.lin_vel_x[0]),
        "lin_vel_x_max": torch.tensor(cfg.ranges.lin_vel_x[1]),
        "lin_vel_y_min": torch.tensor(cfg.ranges.lin_vel_y[0]),
        "lin_vel_y_max": torch.tensor(cfg.ranges.lin_vel_y[1]),
        "ang_vel_z_min": torch.tensor(cfg.ranges.ang_vel_z[0]),
        "ang_vel_z_max": torch.tensor(cfg.ranges.ang_vel_z[1]),
    }


def terrain_levels_vel(
    env: GenesisManagerBasedRlEnv,
    env_ids: torch.Tensor | None,
    command_name: str = "twist",
) -> dict[str, torch.Tensor]:
    """Move environments up or down the terrain difficulty ladder.

    Follows Isaac Lab's ``terrain_levels_vel``: an environment is promoted when
    it walked past half its sub-terrain patch, and demoted when it covered less
    than half the distance its velocity command asked for over the episode.
    Environments that clear the hardest level are recycled to a random one, so
    easy terrain stays in the batch (see ``TerrainEntity.update_env_origins``).

    Runs on the environments that are about to reset, while the robot is still
    at its end-of-episode pose. Requires ``terrain_type="generator"``.

    Example::

        CurriculumTermCfg(
            func=mdp.terrain_levels_vel,
            params={"command_name": "twist"},
        )
    """
    terrain = env.terrain
    if terrain.terrain_origins is None:
        # Plane terrain has no difficulty axis; nothing to do.
        return {"terrain_level": torch.tensor(0.0)}
    assert terrain.terrain_levels is not None

    if env_ids is None:
        env_ids = torch.arange(env.num_envs, device=env.device)
    if env_ids.numel() > 0:
        origins = terrain.env_origins[env_ids]
        distance = torch.norm(env.robot.get_pos()[env_ids, :2] - origins[:, :2], dim=1)

        # Promote once the robot has left the middle of its patch: half the
        # shorter patch dimension, so the check is direction-agnostic.
        patch_size = min(terrain.cfg.terrain_generator.size)  # type: ignore[union-attr]
        move_up = distance > patch_size / 2

        command = env.command_manager.get_command(command_name)
        if command is None:
            raise ValueError(f"Command term '{command_name}' not found.")
        commanded = torch.norm(command[env_ids, :2], dim=1) * env.max_episode_length_s
        move_down = (distance < commanded * 0.5) & ~move_up

        terrain.update_env_origins(env_ids, move_up, move_down)
        # env_origins moved, so the spawn poses the reset will write must follow.
        env.refresh_terrain_spawn(env_ids)

    return {"terrain_level": terrain.terrain_levels.float().mean()}
