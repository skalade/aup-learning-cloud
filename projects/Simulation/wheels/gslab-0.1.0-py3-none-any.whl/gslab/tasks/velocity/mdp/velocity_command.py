# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import torch

from gslab.envs.mdp.observations import base_ang_vel, base_lin_vel
from gslab.managers.command_manager import CommandTerm, CommandTermCfg

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv


class UniformVelocityCommand(CommandTerm):
    """Uniformly sampled body-frame twist command ``(vx, vy, wz)``.

    A configurable fraction of environments (``rel_standing_envs``) receives a
    zero command so the policy also learns to stand still.
    """

    def __init__(self, cfg: UniformVelocityCommandCfg, env: GenesisManagerBasedRlEnv):
        super().__init__(cfg, env)
        self.cfg: UniformVelocityCommandCfg = cfg
        self.vel_command_b = torch.zeros(env.num_envs, 3, device=env.device)
        self.metrics = {
            "error_vel_xy": torch.zeros(env.num_envs, device=env.device),
            "error_vel_yaw": torch.zeros(env.num_envs, device=env.device),
        }

    @property
    def command(self) -> torch.Tensor:
        return self.vel_command_b

    def _update_metrics(self) -> None:
        env = self._env
        self.metrics["error_vel_xy"] += torch.norm(
            self.vel_command_b[:, :2] - base_lin_vel(env)[:, :2], dim=-1
        )
        self.metrics["error_vel_yaw"] += torch.abs(
            self.vel_command_b[:, 2] - base_ang_vel(env)[:, 2]
        )

    def _resample_command(self, env_ids: torch.Tensor) -> None:
        ranges = self.cfg.ranges
        n = env_ids.numel()
        device = self._env.device
        self.vel_command_b[env_ids, 0] = torch.empty(n, device=device).uniform_(
            *ranges.lin_vel_x
        )
        self.vel_command_b[env_ids, 1] = torch.empty(n, device=device).uniform_(
            *ranges.lin_vel_y
        )
        self.vel_command_b[env_ids, 2] = torch.empty(n, device=device).uniform_(
            *ranges.ang_vel_z
        )
        standing = torch.rand(n, device=device) < self.cfg.rel_standing_envs
        self.vel_command_b[env_ids[standing]] = 0.0


@dataclass(kw_only=True)
class UniformVelocityCommandCfg(CommandTermCfg):
    entity_name: str
    heading_command: bool = False
    heading_control_stiffness: float = 1.0
    rel_standing_envs: float = 0.0
    rel_heading_envs: float = 1.0
    init_velocity_prob: float = 0.0

    class_type: type = UniformVelocityCommand

    @dataclass
    class Ranges:
        lin_vel_x: tuple[float, float]
        lin_vel_y: tuple[float, float]
        ang_vel_z: tuple[float, float]
        heading: tuple[float, float] | None = None

    ranges: Ranges

    @dataclass
    class VizCfg:
        z_offset: float = 0.2
        scale: float = 0.5

    viz: VizCfg = field(default_factory=VizCfg)

    def __post_init__(self):
        if self.heading_command and self.ranges.heading is None:
            raise ValueError(
                "The velocity command has heading commands active (heading_command=True) but "
                "the `ranges.heading` parameter is set to None."
            )
