# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from gslab.envs.mdp.curriculums import reward_curriculum as reward_curriculum
from gslab.envs.mdp.curriculums import (
    termination_curriculum as termination_curriculum,
)
from gslab.envs.mdp.observations import actions as actions
from gslab.envs.mdp.observations import base_ang_vel as base_ang_vel
from gslab.envs.mdp.observations import base_lin_vel as base_lin_vel
from gslab.envs.mdp.observations import command as command
from gslab.envs.mdp.observations import foot_air_time as foot_air_time
from gslab.envs.mdp.observations import foot_contact as foot_contact
from gslab.envs.mdp.observations import foot_contact_forces as foot_contact_forces
from gslab.envs.mdp.observations import foot_height as foot_height
from gslab.envs.mdp.observations import height_scan as height_scan
from gslab.envs.mdp.observations import joint_pos as joint_pos
from gslab.envs.mdp.observations import joint_vel as joint_vel
from gslab.envs.mdp.observations import phase as phase
from gslab.envs.mdp.observations import projected_gravity as projected_gravity
from gslab.envs.mdp.rewards import action_rate_l2 as action_rate_l2
from gslab.envs.mdp.rewards import angular_momentum_penalty as angular_momentum_penalty
from gslab.envs.mdp.rewards import (
    body_ang_velocity_penalty as body_ang_velocity_penalty,
)
from gslab.envs.mdp.rewards import body_orientation_l2 as body_orientation_l2
from gslab.envs.mdp.rewards import foot_clearance as foot_clearance
from gslab.envs.mdp.rewards import foot_gait as foot_gait
from gslab.envs.mdp.rewards import foot_slip as foot_slip
from gslab.envs.mdp.rewards import is_terminated as is_terminated
from gslab.envs.mdp.rewards import joint_acc_l2 as joint_acc_l2
from gslab.envs.mdp.rewards import joint_pos_limits as joint_pos_limits
from gslab.envs.mdp.rewards import soft_landing as soft_landing
from gslab.envs.mdp.rewards import stand_still as stand_still
from gslab.envs.mdp.rewards import track_angular_velocity as track_angular_velocity
from gslab.envs.mdp.rewards import track_linear_velocity as track_linear_velocity
from gslab.envs.mdp.rewards import variable_posture as variable_posture
from gslab.envs.mdp.terminations import fell_over as fell_over
from gslab.envs.mdp.terminations import time_out as time_out
from gslab.envs.metrics import mean_action_acc as mean_action_acc

from .curriculums import commands_vel as commands_vel
from .curriculums import terrain_levels_vel as terrain_levels_vel
from .velocity_command import UniformVelocityCommandCfg as UniformVelocityCommandCfg
