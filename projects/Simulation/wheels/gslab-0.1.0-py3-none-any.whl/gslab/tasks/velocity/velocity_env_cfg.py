# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Velocity task configuration.

This module provides a factory function to create a base velocity task config.
Robot-specific configurations call the factory and customize as needed.
"""

import math
from pathlib import Path

from gslab.envs import ManagerBasedRlEnvCfg
from gslab.envs.mdp import dr
from gslab.envs.mdp.actions import JointPositionActionCfg
from gslab.managers.action_manager import ActionTermCfg
from gslab.managers.command_manager import CommandTermCfg
from gslab.managers.curriculum_manager import CurriculumTermCfg
from gslab.managers.event_manager import EventTermCfg
from gslab.managers.metrics_manager import MetricsTermCfg
from gslab.managers.observation_manager import (
    ObservationGroupCfg,
    ObservationTermCfg,
)
from gslab.managers.reward_manager import RewardTermCfg
from gslab.managers.scene_entity_config import SceneEntityCfg
from gslab.managers.termination_manager import TerminationTermCfg
from gslab.scene import SceneCfg
from gslab.sim.sim import MujocoCfg, SimulationCfg
from gslab.tasks.velocity import mdp
from gslab.terrains.terrain_entity import TerrainEntityCfg


def make_velocity_env_cfg(robot_mjcf: Path) -> ManagerBasedRlEnvCfg:
    """Create base velocity tracking task configuration."""

    ##
    # Sensors
    ##

    ##
    # Observations
    ##

    actor_terms = {
        "base_ang_vel": ObservationTermCfg(
            func=mdp.base_ang_vel,
            params={"sensor_name": "robot/imu_ang_vel"},
        ),
        "projected_gravity": ObservationTermCfg(func=mdp.projected_gravity),
        "command": ObservationTermCfg(
            func=mdp.command,
            params={"command_name": "twist"},
        ),
        "phase": ObservationTermCfg(
            func=mdp.phase,
            params={"period": 0.6, "command_name": "twist"},
        ),
        "joint_pos": ObservationTermCfg(func=mdp.joint_pos),
        "joint_vel": ObservationTermCfg(func=mdp.joint_vel),
        "actions": ObservationTermCfg(func=mdp.actions),
    }

    critic_terms = {
        **actor_terms,
        "base_lin_vel": ObservationTermCfg(
            func=mdp.base_lin_vel,
            params={"sensor_name": "robot/imu_lin_vel"},
        ),
        "foot_height": ObservationTermCfg(
            func=mdp.foot_height,
            params={
                "asset_cfg": SceneEntityCfg("robot", site_names=())
            },  # Set per-robot.
        ),
        "foot_air_time": ObservationTermCfg(
            func=mdp.foot_air_time,
            params={"sensor_name": "feet_ground_contact"},
        ),
        "foot_contact": ObservationTermCfg(
            func=mdp.foot_contact,
            params={"sensor_name": "feet_ground_contact"},
        ),
        "foot_contact_forces": ObservationTermCfg(
            func=mdp.foot_contact_forces,
            params={"sensor_name": "feet_ground_contact"},
        ),
    }

    observations = {
        "actor": ObservationGroupCfg(
            terms=actor_terms,
            concatenate_terms=True,
            enable_corruption=True,
            history_length=1,
        ),
        "critic": ObservationGroupCfg(
            terms=critic_terms,
            concatenate_terms=True,
            enable_corruption=False,
            history_length=1,
        ),
    }

    ##
    # Metrics
    ##

    metrics = {
        "mean_action_acc": MetricsTermCfg(func=mdp.mean_action_acc),
    }

    ##
    # Actions
    ##

    actions: dict[str, ActionTermCfg] = {
        "joint_pos": JointPositionActionCfg(
            entity_name="robot",
            actuator_names=(".*",),
            scale=0.25,  # Override per-robot.
            use_default_offset=True,
        )
    }

    ##
    # Commands
    ##

    commands: dict[str, CommandTermCfg] = {
        "twist": mdp.UniformVelocityCommandCfg(
            entity_name="robot",
            resampling_time_range=(3.0, 8.0),
            rel_standing_envs=0.05,
            heading_command=True,
            heading_control_stiffness=0.5,
            debug_vis=True,
            ranges=mdp.UniformVelocityCommandCfg.Ranges(
                lin_vel_x=(-1.0, 2.0),
                lin_vel_y=(-1.0, 1.0),
                ang_vel_z=(-1.0, 1.0),
                heading=(-math.pi, math.pi),
            ),
        )
    }

    ##
    # Events
    ##

    events: dict[str, EventTermCfg] = {
        "foot_friction": EventTermCfg(
            mode="startup",
            func=dr.geom_friction,
            params={
                "asset_cfg": SceneEntityCfg("robot", body_names=()),  # Set per-robot.
                "operation": "abs",
                "ranges": (0.3, 1.6),
                "shared_random": True,  # All foot geoms share the same friction.
            },
        ),
    }

    # events = {
    #     "reset_base": EventTermCfg(
    #         func=mdp.reset_root_state_uniform,
    #         mode="reset",
    #         params={
    #             "pose_range": {
    #                 "x": (-0.5, 0.5),
    #                 "y": (-0.5, 0.5),
    #                 "z": (0.0, 0.0),
    #                 "yaw": (-3.14, 3.14),
    #             },
    #             "velocity_range": {},
    #         },
    #     ),
    #     "reset_robot_joints": EventTermCfg(
    #         func=mdp.reset_joints_by_offset,
    #         mode="reset",
    #         params={
    #             "position_range": (-0.0, 0.0),
    #             "velocity_range": (-0.0, 0.0),
    #             "asset_cfg": SceneEntityCfg("robot", joint_names=(".*",)),
    #         },
    #     ),
    #     "push_robot": EventTermCfg(
    #         func=mdp.push_by_setting_velocity,
    #         mode="interval",
    #         interval_range_s=(5.0, 6.0),
    #         params={
    #             "velocity_range": {
    #                 "x": (-0.5, 0.5),
    #                 "y": (-0.5, 0.5),
    #                 "z": (-0.4, 0.4),
    #                 "roll": (-0.52, 0.52),
    #                 "pitch": (-0.52, 0.52),
    #                 "yaw": (-0.78, 0.78),
    #             },
    #         },
    #     ),
    #     "foot_friction": EventTermCfg(
    #         mode="startup",
    #         func=dr.geom_friction,
    #         params={
    #             "asset_cfg": SceneEntityCfg("robot", body_names=()),  # Set per-robot.
    #             "operation": "abs",
    #             "ranges": (0.3, 1.6),
    #             "shared_random": True,  # All foot geoms share the same friction.
    #         },
    #     ),
    #     "encoder_bias": EventTermCfg(
    #         mode="startup",
    #         func=dr.encoder_bias,
    #         params={
    #             "asset_cfg": SceneEntityCfg("robot"),
    #             "bias_range": (-0.015, 0.015),
    #         },
    #     ),
    #     "base_com": EventTermCfg(
    #         mode="startup",
    #         func=dr.body_com_offset,
    #         params={
    #             "asset_cfg": SceneEntityCfg("robot", body_names=()),  # Set per-robot.
    #             "operation": "add",
    #             "ranges": {
    #                 0: (-0.05, 0.05),
    #                 1: (-0.05, 0.05),
    #                 2: (-0.05, 0.05),
    #             },
    #         },
    #     ),
    # }

    ##
    # Rewards
    ##

    rewards = {
        "track_linear_velocity": RewardTermCfg(
            func=mdp.track_linear_velocity,
            weight=1.0,
            params={"command_name": "twist", "std": math.sqrt(0.25)},
        ),
        "track_angular_velocity": RewardTermCfg(
            func=mdp.track_angular_velocity,
            weight=1.0,
            params={"command_name": "twist", "std": math.sqrt(0.5)},
        ),
        "body_orientation_l2": RewardTermCfg(
            func=mdp.body_orientation_l2,
            weight=-1.0,
            params={
                "asset_cfg": SceneEntityCfg("robot", body_names=())
            },  # Set per-robot.
        ),
        "pose": RewardTermCfg(
            func=mdp.variable_posture,
            weight=1.0,
        ),
        "body_ang_vel": RewardTermCfg(
            func=mdp.body_ang_velocity_penalty,
            weight=-0.05,  # Override per-robot
            params={
                "asset_cfg": SceneEntityCfg("robot", body_names=())
            },  # Set per-robot.
        ),
        "angular_momentum": RewardTermCfg(
            func=mdp.angular_momentum_penalty,
            weight=-0.025,  # Override per-robot
            params={"sensor_name": "robot/root_angmom"},
        ),
        "is_terminated": RewardTermCfg(func=mdp.is_terminated, weight=-200.0),
        "joint_acc_l2": RewardTermCfg(func=mdp.joint_acc_l2, weight=-2.5e-7),
        "joint_pos_limits": RewardTermCfg(func=mdp.joint_pos_limits, weight=-10.0),
        "action_rate_l2": RewardTermCfg(func=mdp.action_rate_l2, weight=-0.05),
        "foot_gait": RewardTermCfg(
            func=mdp.foot_gait,
            weight=0.5,
            params={
                "period": 0.6,
                "offset": [0.0, 0.5],
                "threshold": 0.56,
                "command_threshold": 0.1,
                "command_name": "twist",
                "sensor_name": "feet_ground_contact",
            },
        ),
        "foot_clearance": RewardTermCfg(
            func=mdp.foot_clearance,
            weight=-1.0,
            params={
                "target_height": 0.10,
                "command_name": "twist",
                "command_threshold": 0.1,
                "sensor_name": "feet_ground_contact",
                "asset_cfg": SceneEntityCfg("robot", site_names=()),  # Set per-robot.
            },
        ),
        "foot_slip": RewardTermCfg(
            func=mdp.foot_slip,
            weight=-0.25,
            params={
                "sensor_name": "feet_ground_contact",
                "command_name": "twist",
                "command_threshold": 0.1,
                "asset_cfg": SceneEntityCfg("robot", site_names=()),  # Set per-robot.
            },
        ),
        "soft_landing": RewardTermCfg(
            func=mdp.soft_landing,
            weight=-1e-3,
            params={
                "sensor_name": "feet_ground_contact",
                "command_name": "twist",
                "command_threshold": 0.1,
            },
        ),
        "stand_still": RewardTermCfg(
            func=mdp.stand_still,
            weight=-1.0,
            params={
                "command_name": "twist",
                "command_threshold": 0.1,
            },
        ),
    }

    ##
    # Terminations
    ##

    terminations = {
        "time_out": TerminationTermCfg(func=mdp.time_out, time_out=True),
        "fell_over": TerminationTermCfg(
            func=mdp.fell_over,
            params={"limit_angle": math.radians(70.0)},
        ),
    }

    ##
    # Curriculum
    ##

    curriculum = {
        # Terrain is not supported, so mjlab's "terrain_levels" curriculum
        # term is omitted.
        "command_vel": CurriculumTermCfg(
            func=mdp.commands_vel,
            params={
                "command_name": "twist",
                "velocity_stages": [
                    {
                        "step": 0,
                        "lin_vel_x": (-0.5, 1.0),
                        "lin_vel_y": (-0.5, 0.5),
                        "ang_vel_z": (-1.0, 1.0),
                    },
                    {
                        "step": 5000 * 24,
                        "lin_vel_x": (-1.0, 2.0),
                        "lin_vel_y": (-1.0, 1.0),
                        "ang_vel_z": None,
                    },
                ],
            },
        ),
    }

    ##
    # Assemble and return
    ##

    return ManagerBasedRlEnvCfg(
        robot_mjcf=robot_mjcf,
        scene=SceneCfg(
            terrain=TerrainEntityCfg(
                terrain_type="plane",
            ),
            num_envs=1,
        ),
        observations=observations,
        actions=actions,
        commands=commands,
        events=events,
        rewards=rewards,
        terminations=terminations,
        curriculum=curriculum,
        metrics=metrics,
        sim=SimulationCfg(
            nconmax=35,
            mujoco=MujocoCfg(
                timestep=0.005,
                iterations=10,
                ls_iterations=20,
            ),
        ),
        decimation=4,
        episode_length_s=20.0,
    )
