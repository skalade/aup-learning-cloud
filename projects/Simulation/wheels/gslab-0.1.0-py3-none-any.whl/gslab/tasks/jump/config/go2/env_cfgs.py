# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Unitree Go2 jump environment configuration."""

from gslab.assets.robots import (
    GO2_ACTION_SCALE,
    get_go2_robot_cfg,
)
from gslab.assets.robots.unitree_go2.go2_constants import GO2_XML
from gslab.envs import ManagerBasedRlEnvCfg
from gslab.sensor import ContactMatch, ContactSensorCfg
from gslab.tasks.jump.jump_env_cfg import make_jump_env_cfg


def unitree_go2_jump_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
    """Create Unitree Go2 flat-terrain vertical-jump configuration."""
    # height_reference ~ the Go2's resting base height under these gains, so the
    # height reward activates as soon as the robot pushes up off the ground.
    cfg = make_jump_env_cfg(GO2_XML, height_reference=0.24)

    cfg.scene.entities = {"robot": get_go2_robot_cfg()}

    # Foot-ground contact on the calf links (the foot geom is a child of the
    # calf body); base sensor enables self-collision handling.
    feet_ground_cfg = ContactSensorCfg(
        name="feet_ground_contact",
        primary=ContactMatch(pattern=r"^(FL_calf|FR_calf|RL_calf|RR_calf)$"),
        num_slots=1,
    )
    self_collision_cfg = ContactSensorCfg(
        name="self_collision",
        primary=ContactMatch(pattern="base"),
        num_slots=1,
    )
    cfg.scene.sensors = (feet_ground_cfg, self_collision_cfg)

    joint_pos_action = cfg.actions["joint_pos"]
    joint_pos_action.scale = GO2_ACTION_SCALE

    cfg.viewer.body_name = "base"
    cfg.viewer.azimuth = 180.0
    cfg.viewer.elevation = -20.0

    if play:
        cfg.episode_length_s = int(1e9)
        cfg.observations["actor"].enable_corruption = False

    assert cfg.scene.terrain is not None
    cfg.scene.terrain.terrain_type = "plane"

    return cfg
