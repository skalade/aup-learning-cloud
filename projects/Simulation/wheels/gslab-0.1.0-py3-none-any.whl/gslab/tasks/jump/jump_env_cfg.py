# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Jump task configuration.

Provides a factory that builds a base in-place vertical-jump task. Robot-specific
configs call the factory and fill in the per-robot bits (foot contact sensor,
action scale, viewer body, height reference).

Deliberately minimal, in the spirit of the manager-based velocity task: pure PPO,
dense shaping rewards, no commands, no domain randomization, no scene objects.
The robot learns an explosive crouch-and-extend that lifts all four feet off the
ground and lands upright, in place.
"""

import math
from pathlib import Path

from gslab.envs import ManagerBasedRlEnvCfg
from gslab.envs.mdp.actions import JointPositionActionCfg
from gslab.managers.action_manager import ActionTermCfg
from gslab.managers.metrics_manager import MetricsTermCfg
from gslab.managers.observation_manager import (
    ObservationGroupCfg,
    ObservationTermCfg,
)
from gslab.managers.reward_manager import RewardTermCfg
from gslab.managers.termination_manager import TerminationTermCfg
from gslab.scene import SceneCfg
from gslab.sim.sim import MujocoCfg, SimulationCfg
from gslab.tasks.jump import mdp
from gslab.terrains.terrain_entity import TerrainEntityCfg


def make_jump_env_cfg(
    robot_mjcf: Path,
    *,
    jump_period: float = 0.7,
    height_reference: float = 0.24,
) -> ManagerBasedRlEnvCfg:
    """Create a base in-place vertical-jump task configuration.

    Args:
      robot_mjcf: Path to the robot MJCF.
      jump_period: Period (s) of the phase clock fed to the policy, giving it a
        timing signal for a rhythmic jump cycle.
      height_reference: Nominal standing base height (m); the height reward counts
        only above this.
    """

    ##
    # Observations
    ##

    # Actor sees proprioception only (base angular velocity, projected gravity,
    # joint states, last action) plus a phase clock to time the jump cycle.
    # Base height / linear velocity are privileged and go to the critic only.
    actor_terms = {
        "base_ang_vel": ObservationTermCfg(func=mdp.base_ang_vel),
        "projected_gravity": ObservationTermCfg(func=mdp.projected_gravity),
        "phase": ObservationTermCfg(func=mdp.phase, params={"period": jump_period}),
        "joint_pos": ObservationTermCfg(func=mdp.joint_pos),
        "joint_vel": ObservationTermCfg(func=mdp.joint_vel),
        "actions": ObservationTermCfg(func=mdp.actions),
    }

    critic_terms = {
        **actor_terms,
        "base_lin_vel": ObservationTermCfg(func=mdp.base_lin_vel),
        "base_height": ObservationTermCfg(func=mdp.base_height_obs),
        "foot_contact": ObservationTermCfg(
            func=mdp.foot_contact,
            params={"sensor_name": "feet_ground_contact"},
        ),
    }

    observations = {
        "actor": ObservationGroupCfg(
            terms=actor_terms,
            concatenate_terms=True,
            enable_corruption=True,
            history_length=1,
        ),
        "critic": ObservationGroupCfg(
            terms=critic_terms,
            concatenate_terms=True,
            enable_corruption=False,
            history_length=1,
        ),
    }

    ##
    # Metrics
    ##

    metrics = {
        "mean_action_acc": MetricsTermCfg(func=mdp.mean_action_acc),
    }

    ##
    # Actions
    ##

    actions: dict[str, ActionTermCfg] = {
        "joint_pos": JointPositionActionCfg(
            entity_name="robot",
            actuator_names=(".*",),
            scale=0.25,  # Override per-robot.
            use_default_offset=True,
        )
    }

    ##
    # Rewards
    ##

    rewards = {
        # Core jump drivers. `takeoff` (upward base velocity) is the dense
        # gradient out of standing; `flight` (all four feet off the ground) is
        # the terminal signal of a real jump; `base_height` rewards apex height
        # above the resting reference.
        "flight": RewardTermCfg(
            func=mdp.all_feet_airborne,
            weight=2.0,
            params={"sensor_name": "feet_ground_contact", "force_threshold": 1.0},
        ),
        "takeoff": RewardTermCfg(
            func=mdp.takeoff_vertical_velocity,
            weight=1.5,
            params={"max_velocity": 2.0},
        ),
        "base_height": RewardTermCfg(
            func=mdp.base_height,
            weight=3.0,
            params={"target_height": height_reference, "max_bonus_height": 0.20},
        ),
        # Hard ceiling: strongly penalize launching above a realistic apex so the
        # flight reward cannot be farmed by a ballistic launch.
        "height_overshoot": RewardTermCfg(
            func=mdp.height_overshoot,
            weight=-30.0,
            params={"ceiling": height_reference + 0.25},
        ),
        # Keep it upright, in place, and alive. `alive` is kept small so
        # standing is not a comfortable optimum.
        "upright": RewardTermCfg(func=mdp.body_orientation_l2, weight=-2.0),
        "horizontal_motion": RewardTermCfg(
            func=mdp.horizontal_velocity_l2, weight=-0.5
        ),
        "alive": RewardTermCfg(func=mdp.alive, weight=0.2),
        "is_terminated": RewardTermCfg(func=mdp.is_terminated, weight=-50.0),
        # Regularizers.
        "action_rate_l2": RewardTermCfg(func=mdp.action_rate_l2, weight=-0.01),
        "joint_acc_l2": RewardTermCfg(func=mdp.joint_acc_l2, weight=-2.5e-7),
    }

    ##
    # Terminations
    ##

    terminations = {
        "time_out": TerminationTermCfg(func=mdp.time_out, time_out=True),
        "fell_over": TerminationTermCfg(
            func=mdp.fell_over,
            params={"limit_angle": math.radians(70.0)},
        ),
    }

    ##
    # Assemble and return
    ##

    return ManagerBasedRlEnvCfg(
        robot_mjcf=robot_mjcf,
        scene=SceneCfg(
            terrain=TerrainEntityCfg(terrain_type="plane"),
            num_envs=1,
        ),
        observations=observations,
        actions=actions,
        rewards=rewards,
        terminations=terminations,
        metrics=metrics,
        sim=SimulationCfg(
            nconmax=None,
            mujoco=MujocoCfg(
                timestep=0.005,
                iterations=10,
                ls_iterations=20,
            ),
        ),
        decimation=4,
        episode_length_s=5.0,
    )
