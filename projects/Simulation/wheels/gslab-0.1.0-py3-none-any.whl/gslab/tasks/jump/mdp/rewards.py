# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Jump-specific reward terms.

These are dense shaping rewards that make an explosive, in-place vertical jump
emerge under PPO, without any trajectory-optimization reference.
"""

from __future__ import annotations

import torch

from gslab.envs.mdp.observations import foot_contact_forces


def all_feet_airborne(
    env,
    sensor_name: str = "feet_ground_contact",
    force_threshold: float = 1.0,
    **_kwargs,
) -> torch.Tensor:
    """1.0 when every foot is off the ground (true flight phase), else 0.0.

    This is the core signal that distinguishes a jump from standing tall.
    """
    forces = foot_contact_forces(env, sensor_name=sensor_name)
    if forces.numel() == 0:
        return torch.zeros(env.num_envs, device=env.device)
    forces = forces.reshape(env.num_envs, -1, 3)
    in_contact = torch.norm(forces, dim=-1) > force_threshold
    airborne = (~in_contact).all(dim=1)
    return airborne.float()


def takeoff_vertical_velocity(
    env, max_velocity: float = 2.0, **_kwargs
) -> torch.Tensor:
    """Reward upward (world-frame) base velocity, giving a dense push-off gradient.

    Clamped to ``max_velocity`` so the reward saturates at a realistic take-off
    speed; without the cap the policy exploits an unbounded reward by launching
    the robot ballistically. ``2.0 m/s`` corresponds to a ~0.2 m apex.
    """
    vz = env.robot.get_vel()[:, 2]
    return torch.clamp(vz, min=0.0, max=max_velocity)


def base_height(
    env, target_height: float = 0.24, max_bonus_height: float = 0.25, **_kwargs
) -> torch.Tensor:
    """Reward base height above a standing reference, capped at ``max_bonus_height``.

    The cap turns "jump as high as possible" (which a Go2 cannot physically do and
    which invites reward hacking) into "reach a realistic apex", so the learned
    optimum is repeated controlled hops rather than a single catapult launch.
    """
    z = env.robot.get_pos()[:, 2]
    return torch.clamp(z - target_height, min=0.0, max=max_bonus_height)


def height_overshoot(env, ceiling: float = 0.5, **_kwargs) -> torch.Tensor:
    """Penalize base height above a realistic ceiling (use with a negative weight).

    The ``flight`` reward pays per airborne step, so without an upper bound the
    policy launches ballistically to maximize air time. This term makes height
    above ``ceiling`` progressively costly, so the optimum becomes a controlled
    hop that peaks just above the ceiling instead of a catapult launch.
    """
    z = env.robot.get_pos()[:, 2]
    return torch.clamp(z - ceiling, min=0.0)


def horizontal_velocity_l2(env, **_kwargs) -> torch.Tensor:
    """Penalize horizontal base velocity so the jump stays roughly in place."""
    v_xy = env.robot.get_vel()[:, :2]
    return torch.sum(torch.square(v_xy), dim=1)


def alive(env, **_kwargs) -> torch.Tensor:
    """Constant per-step reward for not terminating (discourages reckless jumps)."""
    return torch.ones(env.num_envs, device=env.device)
