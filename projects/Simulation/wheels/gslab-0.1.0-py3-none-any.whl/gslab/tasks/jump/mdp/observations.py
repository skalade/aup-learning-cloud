# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Jump-specific observation terms."""

from __future__ import annotations

import torch


def base_height_obs(env, **_kwargs) -> torch.Tensor:
    """Base height above the ground plane, shape ``(num_envs, 1)`` (privileged)."""
    return env.robot.get_pos()[:, 2:3]
