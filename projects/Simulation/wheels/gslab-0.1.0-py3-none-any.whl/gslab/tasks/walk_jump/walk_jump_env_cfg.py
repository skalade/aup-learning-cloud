# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Walk-jump task configuration.

Layers a jump-on-command capability on top of an already-configured velocity
(walking) environment, driven by a four-stage curriculum:

    1. walk            (low speed, no jump)
    2. walk + jump     (low speed, jump on command)
    3. run             (high speed, no jump)  -- "run like a dog"
    4. run + leap      (high speed, jump on command)  -- a running leap

Velocity tracking is always active, so a commanded jump carries the current
forward velocity; the air-time reward makes the flight a single sustained leap,
and leap distance / air time are logged as metrics.
"""

from __future__ import annotations

from gslab.envs import ManagerBasedRlEnvCfg
from gslab.managers import CurriculumTermCfg
from gslab.managers.event_manager import EventTermCfg
from gslab.managers.metrics_manager import MetricsTermCfg
from gslab.managers.observation_manager import ObservationTermCfg
from gslab.managers.reward_manager import RewardTermCfg
from gslab.tasks.walk_jump import mdp

# One env step per step() call; a training iteration is `num_steps_per_env` steps.
# Four 400-iteration stages at 24 steps/iter.
_STEPS_PER_ITER = 24
WALK_JUMP_START = 400 * _STEPS_PER_ITER  # 9600
RUN_START = 800 * _STEPS_PER_ITER  # 19200
RUN_LEAP_START = 1200 * _STEPS_PER_ITER  # 28800

# Command ranges per phase.
WALK_RANGES = {
    "lin_vel_x": (-0.5, 1.0),
    "lin_vel_y": (-0.5, 0.5),
    "ang_vel_z": (-0.5, 0.5),
}
RUN_RANGES = {
    "lin_vel_x": (-1.0, 3.0),
    "lin_vel_y": (-1.0, 1.0),
    "ang_vel_z": (-1.0, 1.0),
}


def add_jump_capability(
    cfg: ManagerBasedRlEnvCfg,
    *,
    play: bool = False,
    jump_period_s: float = 2.0,
    jump_window_s: float = 0.4,
    height_reference: float = 0.24,
    ceiling: float = 0.55,
    max_air_time: float = 0.5,
) -> ManagerBasedRlEnvCfg:
    """Add jump-on-command obs/rewards/events/metrics and the 4-stage curriculum."""
    # Observe the jump trigger (actor + critic).
    cfg.observations["actor"].terms["jump_command"] = ObservationTermCfg(
        func=mdp.jump_command
    )
    cfg.observations["critic"].terms["jump_command"] = ObservationTermCfg(
        func=mdp.jump_command
    )

    # Jump rewards: the in-place jump task's shaping terms (see
    # ``gslab.tasks.jump.mdp.rewards``), gated by the jump command (zero unless
    # a jump is commanded). ``jump_overshoot`` is shared unchanged and always on.
    cfg.rewards["commanded_flight"] = RewardTermCfg(
        func=mdp.commanded_flight,
        weight=2.0,
        params={"sensor_name": "feet_ground_contact", "force_threshold": 1.0},
    )
    cfg.rewards["commanded_air_time"] = RewardTermCfg(
        func=mdp.commanded_air_time,
        weight=3.0,
        params={"max_air_time": max_air_time},
    )
    cfg.rewards["commanded_takeoff"] = RewardTermCfg(
        func=mdp.commanded_takeoff,
        weight=1.5,
        params={"max_velocity": 2.0},
    )
    cfg.rewards["commanded_jump_height"] = RewardTermCfg(
        func=mdp.commanded_jump_height,
        weight=3.0,
        params={"target_height": height_reference, "max_bonus_height": 0.25},
    )
    cfg.rewards["jump_overshoot"] = RewardTermCfg(
        func=mdp.height_overshoot,
        weight=-30.0,
        params={"ceiling": ceiling},
    )

    # Jump trigger as a proper command term: the schedule drives it during
    # training (once enabled by the curriculum); at play time it is disabled and
    # the keyboard writes the command instead.
    cfg.commands["jump"] = mdp.JumpCommandCfg(
        enabled=False,
        period_s=jump_period_s,
        window_s=jump_window_s,
    )

    # Track whole-body airborne time + leap distance every step (before
    # rewards/metrics), and clear the bookkeeping for environments that reset so
    # flight state does not leak across episodes. Per-foot air time itself lives
    # on the contact sensor (track_air_time, set in the velocity config).
    cfg.events["jump_stats"] = EventTermCfg(
        mode="step",
        func=mdp.update_jump_stats,
        params={"sensor_name": "feet_ground_contact"},
    )
    cfg.events["reset_jump_stats"] = EventTermCfg(
        mode="reset",
        func=mdp.reset_jump_stats,
        params={},
    )

    # Measurement metrics.
    cfg.metrics["leap_length"] = MetricsTermCfg(func=mdp.leap_length)
    cfg.metrics["air_time"] = MetricsTermCfg(func=mdp.air_time)

    # Four-stage curriculum: speed ramps up at the run phase; jumping toggles on
    # for the walk+jump and run+leap phases.
    cfg.curriculum = {
        "command_speed": CurriculumTermCfg(
            func=mdp.commands_vel,
            params={
                "command_name": "twist",
                "velocity_stages": [
                    {"step": 0, **WALK_RANGES},
                    {"step": RUN_START, **RUN_RANGES},
                ],
            },
        ),
        "jumping": CurriculumTermCfg(
            func=mdp.enable_jumping,
            params={
                "command_name": "jump",
                "stages": [
                    {"step": 0, "enabled": False},  # walk
                    {"step": WALK_JUMP_START, "enabled": True},  # walk + jump
                    {"step": RUN_START, "enabled": False},  # run
                    {"step": RUN_LEAP_START, "enabled": True},  # run + leap
                ],
            },
        ),
    }

    if play:
        # The jump command is driven by the keyboard at play time: keep the term
        # but disable its schedule, and drop the curriculum. jump_stats stays so
        # leap distance / air time can still be measured.
        cfg.commands["jump"].enabled = False
        cfg.curriculum = {}

    return cfg
