# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Walk-jump observation terms."""

from __future__ import annotations

import torch


def jump_command(env, command_name: str = "jump", **_kwargs) -> torch.Tensor:
    """The current jump trigger, shape ``(num_envs,)``.

    1.0 while a jump is being commanded, else 0.0. The policy can condition
    its jump on this; the walk-jump rewards use it as a gate.
    """
    cmd = env.command_manager.get_command(command_name)
    if cmd is None:
        raise ValueError(f"Command term '{command_name}' not found.")
    return cmd[:, 0]
