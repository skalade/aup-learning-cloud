# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Walk-jump measurement metrics (logged as episode averages)."""

from __future__ import annotations

import torch

from .events import _get_jump_stats


def leap_length(env, **_kwargs) -> torch.Tensor:
    """Horizontal base distance of the most recently completed leap (m)."""
    return _get_jump_stats(env).last_leap_length


def air_time(env, **_kwargs) -> torch.Tensor:
    """Flight duration of the most recently completed leap (s)."""
    return _get_jump_stats(env).last_air_time
