# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

import torch

from gslab.tasks.jump.mdp.rewards import (
    all_feet_airborne,
    base_height,
    takeoff_vertical_velocity,
)

from .events import _get_jump_stats
from .observations import jump_command


def commanded_flight(
    env,
    sensor_name: str = "feet_ground_contact",
    force_threshold: float = 1.0,
    command_name: str = "jump",
    **_kwargs,
) -> torch.Tensor:
    """Reward all four feet leaving the ground, but only while a jump is commanded."""
    airborne = all_feet_airborne(
        env, sensor_name=sensor_name, force_threshold=force_threshold
    )
    return airborne * jump_command(env, command_name)


def commanded_air_time(
    env,
    max_air_time: float = 0.5,
    command_name: str = "jump",
    **_kwargs,
) -> torch.Tensor:
    """Reward continuous flight time (capped) while a jump is commanded.

    Flight time is maintained by the ``update_jump_stats`` event. Rewarding it
    makes the policy prefer a single sustained flight over tiny hops, which -- at
    a commanded forward velocity -- turns into a long leap. Capped so it can't be
    farmed by launching ever higher (the height ceiling also bounds it).
    """
    air_time = _get_jump_stats(env).feet_air_time
    return torch.clamp(air_time, min=0.0, max=max_air_time) * jump_command(
        env, command_name
    )


def commanded_takeoff(
    env,
    max_velocity: float = 2.0,
    command_name: str = "jump",
    **_kwargs,
) -> torch.Tensor:
    """Reward upward take-off velocity (capped) while a jump is commanded."""
    vz = takeoff_vertical_velocity(env, max_velocity=max_velocity)
    return vz * jump_command(env, command_name)


def commanded_jump_height(
    env,
    target_height: float = 0.30,
    max_bonus_height: float = 0.25,
    command_name: str = "jump",
    **_kwargs,
) -> torch.Tensor:
    """Reward apex height above a reference (capped) while a jump is commanded."""
    bonus = base_height(
        env, target_height=target_height, max_bonus_height=max_bonus_height
    )
    return bonus * jump_command(env, command_name)
