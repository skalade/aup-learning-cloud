# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Jump trigger command term."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import torch

from gslab.managers.command_manager import CommandTerm, CommandTermCfg

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv


class JumpCommand(CommandTerm):
    """Binary jump trigger, shape ``(num_envs, 1)``.

    While ``cfg.enabled`` (training, flipped by the curriculum), the term drives
    the trigger itself: each environment is commanded to jump for ``window_s``
    every ``period_s``, staggered by a per-env phase offset. While disabled the
    buffer is left untouched so an external writer (e.g. keyboard teleop) can
    drive it; per-env resets still zero it.
    """

    def __init__(self, cfg: JumpCommandCfg, env: GenesisManagerBasedRlEnv):
        super().__init__(cfg, env)
        self.cfg: JumpCommandCfg = cfg
        self.jump_command = torch.zeros(env.num_envs, 1, device=env.device)
        self._offset = (
            torch.arange(env.num_envs, device=env.device)
            / max(env.num_envs, 1)
            * cfg.period_s
        )

    @property
    def command(self) -> torch.Tensor:
        return self.jump_command

    def _resample_command(self, env_ids: torch.Tensor) -> None:
        # Schedule-driven (see _update_command); nothing to sample.
        pass

    def _update_command(self) -> None:
        if not self.cfg.enabled:
            return
        t = self._env.episode_length_buf.float() * self._env.step_dt
        phase = torch.remainder(t + self._offset, self.cfg.period_s)
        self.jump_command[:, 0] = (phase < self.cfg.window_s).float()


@dataclass(kw_only=True)
class JumpCommandCfg(CommandTermCfg):
    enabled: bool = False
    """Whether the term drives the trigger on its own schedule. Off at play time,
  where the keyboard writes the command instead."""
    period_s: float = 2.0
    """Seconds between commanded jumps (per environment)."""
    window_s: float = 0.4
    """Duration of each commanded jump window."""

    resampling_time_range: tuple[float, float] = (1e9, 1e9)
    class_type: type = JumpCommand
