# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Walk-jump curriculum terms."""

from __future__ import annotations

import torch


def enable_jumping(
    env,
    env_ids: torch.Tensor | None,
    command_name: str = "jump",
    stages: list[dict] | None = None,
    **_kwargs,
) -> dict[str, float]:
    """Staged on/off schedule for the jump command, keyed on env steps.

    ``stages`` is a list of ``{"step": int, "enabled": bool}`` applied in order
    (later reached stages win), so jumping can be turned on for the walk+jump and
    run+leap phases and off for the pure walk and pure run phases. Example::

        stages=[
            {"step": 0,     "enabled": False},  # walk
            {"step": 9600,  "enabled": True},   # walk + jump
            {"step": 19200, "enabled": False},  # run
            {"step": 28800, "enabled": True},   # run + leap
        ]
    """
    del env_ids
    stages = stages or [{"step": 0, "enabled": False}]
    for i in range(1, len(stages)):
        if stages[i]["step"] < stages[i - 1]["step"]:
            raise ValueError(
                f"Curriculum stages must be in nondecreasing step order, but stage"
                f" {i} has step {stages[i]['step']} < {stages[i - 1]['step']}."
            )
    enabled = False
    for stage in stages:
        if env.common_step_counter >= stage["step"]:
            enabled = bool(stage["enabled"])

    term = env.command_manager.get_term(command_name)
    if term is None:
        raise ValueError(f"Command term '{command_name}' not found.")
    if term.cfg.enabled and not enabled:
        # Turning the schedule off: clear any in-flight jump windows so stale
        # triggers don't linger until the next per-env reset.
        term.command.zero_()
    term.cfg.enabled = enabled
    return {"jumping_enabled": 1.0 if enabled else 0.0}
