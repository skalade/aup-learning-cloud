# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Walk-jump events: whole-body flight and leap bookkeeping.

Per-foot contact state and air time live on the contact sensor
(``ContactSensorCfg(track_air_time=True)``). These events maintain the
*whole-body* quantities on top of it: continuous all-feet flight time and the
horizontal displacement of each completed leap.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass
class JumpStats:
    """Per-env whole-body flight bookkeeping maintained by ``update_jump_stats``.

    ``feet_air_time`` is how long all four feet have been continuously off the
    ground (0 while any foot is in contact). ``last_air_time`` and
    ``last_leap_length`` describe the most recently completed leap (flight
    duration and horizontal base displacement).
    """

    feet_air_time: torch.Tensor
    prev_airborne: torch.Tensor
    takeoff_xy: torch.Tensor
    last_air_time: torch.Tensor
    last_leap_length: torch.Tensor

    def reset(self, env_ids: torch.Tensor | None = None) -> None:
        if env_ids is None:
            env_ids = slice(None)
        self.feet_air_time[env_ids] = 0.0
        self.prev_airborne[env_ids] = False
        self.takeoff_xy[env_ids] = 0.0
        self.last_air_time[env_ids] = 0.0
        self.last_leap_length[env_ids] = 0.0


def _get_jump_stats(env) -> JumpStats:
    stats = getattr(env, "_jump_stats", None)
    if stats is None or stats.feet_air_time.shape[0] != env.num_envs:
        n = env.num_envs
        stats = JumpStats(
            feet_air_time=torch.zeros(n, device=env.device),
            prev_airborne=torch.zeros(n, dtype=torch.bool, device=env.device),
            takeoff_xy=torch.zeros(n, 2, device=env.device),
            last_air_time=torch.zeros(n, device=env.device),
            last_leap_length=torch.zeros(n, device=env.device),
        )
        env._jump_stats = stats
    return stats


def update_jump_stats(
    env,
    env_ids=None,
    sensor_name: str = "feet_ground_contact",
    **_kwargs,
) -> None:
    """Track continuous flight time and completed leap distance (step-mode event).

    Derives whole-body airborne state from the contact sensor and maintains the
    per-env :class:`JumpStats`, read by the air-time reward and the leap metrics.
    Runs every step, before rewards/metrics are computed. Pair with
    ``reset_jump_stats`` (reset mode) so state does not leak across episodes.
    """
    del env_ids
    stats = _get_jump_stats(env)
    sensor = env.sensors[sensor_name]
    airborne = ~sensor.data.found.any(dim=1)
    xy = env.robot.get_pos()[:, :2]

    takeoff = airborne & ~stats.prev_airborne
    stats.takeoff_xy[takeoff] = xy[takeoff]

    landing = ~airborne & stats.prev_airborne
    stats.last_air_time[landing] = stats.feet_air_time[landing]
    stats.last_leap_length[landing] = torch.norm(
        xy[landing] - stats.takeoff_xy[landing], dim=-1
    )

    stats.feet_air_time = torch.where(
        airborne,
        stats.feet_air_time + env.step_dt,
        torch.zeros_like(stats.feet_air_time),
    )
    stats.prev_airborne = airborne


def reset_jump_stats(env, env_ids=None, **_kwargs) -> None:
    """Clear flight bookkeeping for resetting environments (reset-mode event)."""
    _get_jump_stats(env).reset(env_ids)
