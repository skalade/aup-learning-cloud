# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Unitree Go2 walk-jump environment configuration."""

from gslab.envs import ManagerBasedRlEnvCfg
from gslab.tasks.velocity.config.go2.env_cfgs import unitree_go2_flat_env_cfg
from gslab.tasks.walk_jump.walk_jump_env_cfg import add_jump_capability


def unitree_go2_walkjump_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
    """Go2 that walks (velocity tracking) and jumps forward on command.

    Built by layering the jump-on-command capability onto the Go2 velocity
    (walking) environment, with a two-phase curriculum (walk, then walk + jump).
    """
    cfg = unitree_go2_flat_env_cfg(play=play)
    cfg = add_jump_capability(cfg, play=play)
    return cfg
