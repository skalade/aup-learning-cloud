# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from gslab.rl import GslabOnPolicyRunner
from gslab.tasks.registry import register_gslab_task

from .env_cfgs import (
    unitree_go2_walkjump_env_cfg,
)
from .rl_cfg import unitree_go2_walkjump_ppo_runner_cfg

register_gslab_task(
    task_id="Unitree-Go2-WalkJump",
    env_cfg=unitree_go2_walkjump_env_cfg(),
    play_env_cfg=unitree_go2_walkjump_env_cfg(play=True),
    rl_cfg=unitree_go2_walkjump_ppo_runner_cfg(),
    runner_cls=GslabOnPolicyRunner,
)
