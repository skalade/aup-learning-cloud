# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Task registry system for managing environment registration and creation."""

from copy import deepcopy
from dataclasses import dataclass

from gslab.envs import ManagerBasedRlEnvCfg
from gslab.rl.config import RslRlBaseRunnerCfg


@dataclass
class _TaskCfg:
    env_cfg: ManagerBasedRlEnvCfg
    play_env_cfg: ManagerBasedRlEnvCfg
    rl_cfg: RslRlBaseRunnerCfg
    runner_cls: type | None


# Private module-level registry: task_id -> task config.
_REGISTRY: dict[str, _TaskCfg] = {}


def register_gslab_task(
    task_id: str,
    env_cfg: ManagerBasedRlEnvCfg,
    play_env_cfg: ManagerBasedRlEnvCfg,
    rl_cfg: RslRlBaseRunnerCfg,
    runner_cls: type | None = None,
) -> None:
    """Register an environment task.

    Args:
      task_id: Unique task identifier (e.g., "Gslab-Velocity-Rough-Unitree-Go1").
      env_cfg: Environment configuration used for training.
      play_env_cfg: Environment configuration in "play" mode.
      rl_cfg: RL runner configuration.
      runner_cls: Optional custom runner class. If None, uses OnPolicyRunner.
    """
    if task_id in _REGISTRY:
        raise ValueError(f"Task '{task_id}' is already registered")
    _REGISTRY[task_id] = _TaskCfg(env_cfg, play_env_cfg, rl_cfg, runner_cls)


def list_tasks() -> list[str]:
    """List all registered task IDs."""
    return sorted(_REGISTRY.keys())


def load_env_cfg(task_name: str, play: bool = False) -> ManagerBasedRlEnvCfg:
    """Load environment configuration for a task.

    Returns a deep copy to prevent mutation of the registered config.
    """
    return deepcopy(
        _REGISTRY[task_name].env_cfg if not play else _REGISTRY[task_name].play_env_cfg
    )


def load_rl_cfg(task_name: str) -> RslRlBaseRunnerCfg:
    """Load RL configuration for a task.

    Returns a deep copy to prevent mutation of the registered config.
    """
    return deepcopy(_REGISTRY[task_name].rl_cfg)


def load_runner_cls(task_name: str) -> type | None:
    """Load the runner class for a task.

    If None, the default OnPolicyRunner will be used.
    """
    return _REGISTRY[task_name].runner_cls
