# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Definition of *what* gets tuned: the search space and how it maps onto a config.

Kept separate from the Ray/Optuna orchestration in ``tuner.py`` so adding or editing
tunable parameters does not touch the run logic.
"""

from __future__ import annotations

from gslab.envs import ManagerBasedRlEnvCfg
from gslab.envs.mdp.actions import JointPositionActionCfg

# Search dimensions: display name -> (low, high, distribution).
# The two ``*_mag`` keys are sampled as positive magnitudes on a log scale and then
# negated, since the underlying reward weights are negative.
# ``action_scale_mult`` multiplies the task's default action scale instead of
# replacing it: the default is a *per-joint* dict (G1_ACTION_SCALE, derived from each
# actuator's effort/stiffness), and overwriting it with a single scalar would change
# the action parameterization into one the default training setup never uses.
SEARCH_SPACE: dict[str, tuple[float, float, str]] = {
    "track_lin_std": (0.25, 1.0, "uniform"),
    "track_ang_std": (0.3, 1.2, "uniform"),
    "action_rate_l2_mag": (5e-3, 0.2, "loguniform"),
    "joint_acc_l2_mag": (5e-8, 1e-6, "loguniform"),
    "action_scale_mult": (0.5, 2.0, "loguniform"),
}


def default_search_params(env_cfg: ManagerBasedRlEnvCfg) -> dict[str, float]:
    """Read the training-default value of each search dimension off an env config.

    The inverse of ``apply_search_params``. Enqueued as the study's first trial so
    the baseline config is measured with the same objective as every candidate: the
    study then answers "does anything beat the default?" instead of only ranking
    samples against each other.
    """
    return {
        "track_lin_std": env_cfg.rewards["track_linear_velocity"].params["std"],
        "track_ang_std": env_cfg.rewards["track_angular_velocity"].params["std"],
        "action_rate_l2_mag": -env_cfg.rewards["action_rate_l2"].weight,
        "joint_acc_l2_mag": -env_cfg.rewards["joint_acc_l2"].weight,
        "action_scale_mult": 1.0,
    }


def apply_search_params(
    env_cfg: ManagerBasedRlEnvCfg, config: dict[str, float]
) -> None:
    """Write sampled search parameters onto an env config in place."""
    env_cfg.rewards["track_linear_velocity"].params["std"] = config["track_lin_std"]
    env_cfg.rewards["track_angular_velocity"].params["std"] = config["track_ang_std"]
    env_cfg.rewards["action_rate_l2"].weight = -config["action_rate_l2_mag"]
    env_cfg.rewards["joint_acc_l2"].weight = -config["joint_acc_l2_mag"]

    mult = config["action_scale_mult"]
    joint_pos = env_cfg.actions["joint_pos"]
    assert isinstance(joint_pos, JointPositionActionCfg)
    if isinstance(joint_pos.scale, dict):
        joint_pos.scale = {k: v * mult for k, v in joint_pos.scale.items()}
    else:
        joint_pos.scale = joint_pos.scale * mult


def train_cli_command(env_cfg: ManagerBasedRlEnvCfg, num_envs: int) -> str:
    """Render a tuned env config as a ready-to-paste ``train_g1`` command.

    The action scale is emitted as the resolved per-joint dict (tyro's
    ``STR FLOAT [STR FLOAT ...]`` syntax), so the command reproduces exactly what
    the winning trial trained with.
    """
    joint_pos = env_cfg.actions["joint_pos"]
    assert isinstance(joint_pos, JointPositionActionCfg)
    if isinstance(joint_pos.scale, dict):
        scale_arg = " ".join(f"'{k}' {v}" for k, v in joint_pos.scale.items())
    else:
        scale_arg = str(joint_pos.scale)

    lin_std = env_cfg.rewards["track_linear_velocity"].params["std"]
    ang_std = env_cfg.rewards["track_angular_velocity"].params["std"]
    flags = [
        f"--env.scene.num-envs {num_envs}",
        f"--env.rewards.track-linear-velocity.params.std {lin_std}",
        f"--env.rewards.track-angular-velocity.params.std {ang_std}",
        f"--env.rewards.action-rate-l2.weight {env_cfg.rewards['action_rate_l2'].weight}",
        f"--env.rewards.joint-acc-l2.weight {env_cfg.rewards['joint_acc_l2'].weight}",
        f"--env.actions.joint-pos.scale {scale_arg}",
    ]
    return " \\\n    ".join(["uv run train_g1"] + flags)
