# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Lightweight progress/results summary for a Ray Tune study.

Reads each trial's ``params.json`` and ``result.json`` straight from the study
directory on disk, so it needs no Ray import (or running cluster) and can be used
while a study is still training. One row per trial, sorted by objective.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field

import tyro

_TRIAL_PREFIX = "train_eval_trial_"
_METRIC_COLS = (
    ("iter", "{:d}"),
    ("objective", "{:.4f}"),
    ("error_vel_xy", "{:.3f}"),
    ("error_vel_yaw", "{:.3f}"),
    ("action_rate", "{:.3f}"),
    ("fall_rate", "{:.3f}"),
)


@dataclass
class ResultsConfig:
    """CLI configuration for summarizing a tuning study."""

    study_name: str = "g1_tuning"
    storage_path: str = field(default_factory=lambda: os.path.abspath("ray_results"))
    """Where the study lives: ``<storage_path>/<study_name>``."""
    history: bool = False
    """Print every report of every trial (to watch a trial's objective over time)
    instead of only the latest report per trial."""


def _load_trials(exp_path: str) -> list[dict]:
    """Collect params and reported metrics for every trial directory."""
    trials = []
    for name in sorted(os.listdir(exp_path)):
        trial_dir = os.path.join(exp_path, name)
        if not name.startswith(_TRIAL_PREFIX) or not os.path.isdir(trial_dir):
            continue
        trial_id = name[len(_TRIAL_PREFIX) :].split("_")[0]

        params: dict = {}
        try:
            with open(os.path.join(trial_dir, "params.json")) as f:
                params = json.load(f)
        except (OSError, json.JSONDecodeError):
            pass

        reports = []
        try:
            with open(os.path.join(trial_dir, "result.json")) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        reports.append(json.loads(line))
        except (OSError, json.JSONDecodeError):
            pass

        trials.append({"id": trial_id, "params": params, "reports": reports})
    return trials


def _fmt_metrics(report: dict | None) -> list[str]:
    out = []
    for key, fmt in _METRIC_COLS:
        value = report.get(key) if report else None
        out.append(fmt.format(value) if value is not None else "-")
    return out


def _print_table(header: list[str], rows: list[list[str]]) -> None:
    widths = [max(len(h), *(len(r[i]) for r in rows)) for i, h in enumerate(header)]
    print("  ".join(h.ljust(w) for h, w in zip(header, widths)))
    for row in rows:
        print("  ".join(c.ljust(w) for c, w in zip(row, widths)))


def summarize(cfg: ResultsConfig) -> None:
    exp_path = os.path.join(cfg.storage_path, cfg.study_name)
    if not os.path.isdir(exp_path):
        raise FileNotFoundError(f"No study directory at {exp_path!r}.")

    trials = _load_trials(exp_path)
    if not trials:
        print(f"No trials found in {exp_path!r}.")
        return

    param_keys = sorted({k for t in trials for k in t["params"]})
    header = ["trial", *(k for k, _ in _METRIC_COLS), *param_keys]

    rows = []
    for t in trials:
        reports = t["reports"] if cfg.history else t["reports"][-1:]
        param_cells = [
            f"{t['params'][k]:.4g}" if k in t["params"] else "-" for k in param_keys
        ]
        if not reports:
            rows.append(([t["id"]], None, *_fmt_metrics(None), *param_cells))
            continue
        for report in reports:
            rows.append(
                ([t["id"]], report.get("objective"), *_fmt_metrics(report))
                + tuple(param_cells)
            )

    # Latest view: best objective first, unreported trials last. History view keeps
    # per-trial chronological order instead.
    if not cfg.history:
        rows.sort(key=lambda r: (r[1] is None, r[1]))
    table = [[r[0][0], *r[2:]] for r in rows]
    _print_table(header, table)

    print(
        f"\n{len(trials)} trials in {exp_path}"
        "\nobjective = error_vel_xy + 0.5*error_vel_yaw + 0.5*action_rate + fall_rate"
        " (lower is better); 100 = survival gate (fall rate > 0.5)."
        "\nerror_vel_xy ~ 1.0 = commands ignored (stand-and-turn regime; normal"
        " before ~10k iterations, walking settles by ~13k)."
    )


def main() -> None:
    summarize(tyro.cli(ResultsConfig))


if __name__ == "__main__":
    main()
