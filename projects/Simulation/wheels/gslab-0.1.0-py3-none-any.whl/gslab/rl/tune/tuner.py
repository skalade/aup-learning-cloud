# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Ray Tune + Optuna hyperparameter tuning for the G1 velocity task.

This is additive: it reuses the registered task configs and the shared env factory
without modifying ``train.py`` or any config. Each Ray trial runs in its own worker
process (so Genesis' one-shot ``gs.init`` is called once per trial), trains the policy
in chunks, evaluates after every chunk, and reports the objective. Optuna (TPE)
proposes the samples.

Fidelity matters for this task: in reference full-length runs, xy velocity tracking
(actual walking) only emerges around ~9-10k PPO iterations and walks well by ~13k --
before emergence every config sits in a "stand and turn" regime where
``error_vel_xy`` is flat at the command baseline and the objective differences are
noise. Trials therefore default to running past the transition (13k iterations) with
the training-default ``num_envs``, so the objective is measured on settled walking
behavior. Rank-based early stopping (ASHA) is *disabled* by default: any
pre-emergence rung would prune on noise (and would systematically favor configs that
merely start walking earlier, not those that end up tracking best). Hopeless trials
are still cut early by the survival gate (see ``gate_patience``).
"""

from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass, field

os.environ.setdefault("RAY_ENABLE_UV_RUN_RUNTIME_ENV", "0")

import tyro

import gslab.tasks  # noqa: F401  (imported for its task-registration side effect)
from gslab.rl.factory import init_genesis, make_env, make_runner
from gslab.rl.tune.config import (
    SEARCH_SPACE,
    apply_search_params,
    default_search_params,
    train_cli_command,
)
from gslab.rl.tune.objective import compute_objective, evaluate_policy
from gslab.tasks.registry import load_env_cfg, load_rl_cfg

# ``ray`` and ``optuna`` are imported lazily inside the functions below: they are an
# optional dependency (the ``tune`` extra), so importing them at module scope would
# break ``import gslab.rl.tune`` for a base install that does not have the extra.

# Filename of the policy checkpoint inside each Ray Tune checkpoint directory.
_CHECKPOINT_FILE = "model.pt"


@dataclass
class TuneConfig:
    """CLI configuration for a tuning study."""

    task_id: str = "Unitree-G1-Flat"
    num_samples: int = 16
    """Number of hyperparameter configurations Optuna will try. Trials run at full
    training length (see ``iterations``), so each one costs roughly a full training
    run of GPU time; budget accordingly."""
    num_envs: int = 4096
    """Parallel envs per trial. Matches the training default: PPO batch size is
    ``num_envs * num_steps_per_env``, so tuning at a different value changes the
    learning dynamics and the found hyperparameters do not transfer."""
    iterations: int = 13000
    """Total PPO iterations per trial. Must run well past the walking-emergence
    transition (~9-10k iterations on this task; walking is settled by ~13k) so the
    objective measures walking quality, not where in the transition a trial happens
    to be. Shorter trials never leave the stand-and-turn regime and rank noise."""
    iters_per_report: int = 500
    """Iterations between objective reports (also the checkpoint cadence)."""
    eval_steps: int = 1000
    """Env steps used to estimate the objective after each chunk."""
    seed: int = 42
    """Fixed seed so the optimizer sees hparam effect, not seed variance."""
    # Objective shaping (see objective.compute_objective).
    lambda_yaw: float = 0.5
    beta_survival: float = 1.0
    w_action_rate: float = 0.5
    """Weight of the action-smoothness term in the objective. Keeps the optimizer
    from zeroing out the smoothness reward penalties it is tuning."""
    fall_rate_gate: float = 0.5
    gate_penalty: float = 100.0
    gate_patience: int = 3
    """Stop a trial early after this many *consecutive* gated reports (fall rate
    above ``fall_rate_gate``). This is the only early stopping enabled by default."""
    # Resources / scheduling. Tuning always runs on GPU (one or more per trial).
    gpus_per_trial: float = 1.0
    max_failures: int = 3
    """Times a crashed trial is retried"""
    max_concurrent: int = 0
    """Max trials running at once. 0 lets Ray fill all available GPUs."""
    grace_period: int = 0
    """ASHA: min iterations before a trial can be rank-pruned. 0 (default) disables
    rank-based pruning: there is no informative intermediate signal before walking
    emerges, so early rungs would prune on noise. Set to >= ~12000 to re-enable."""
    reduction_factor: int = 3
    """ASHA: keep the top 1/reduction_factor of trials at each rung."""
    study_name: str = "g1_tuning"
    storage_path: str = field(default_factory=lambda: os.path.abspath("ray_results"))
    """Where Ray writes results. Defaults to ``<cwd>/ray_results``."""
    resume: bool = False
    """Resume an interrupted study at ``<storage_path>/<study_name>`` instead of
    starting fresh. Reloads trial state, checkpoints, and the Optuna searcher."""
    resume_errored: bool = True
    """When resuming, retry trials that errored out (e.g. the worker crashes we hit)."""


def _report(metrics: dict[str, float], checkpoint=None) -> None:
    """Report metrics (and an optional checkpoint) to Ray Tune.

    Tolerant of the API's relocations across versions; the ``checkpoint`` kwarg has
    the same name and meaning in all three.
    """
    try:
        from ray.tune import report  # Ray >= 2.34

        report(metrics, checkpoint=checkpoint)
        return
    except ImportError:
        pass
    try:
        from ray import train  # Ray 2.7 - 2.33

        train.report(metrics, checkpoint=checkpoint)
        return
    except ImportError:
        pass
    from ray.air import session  # Ray 2.0 - 2.6

    session.report(metrics, checkpoint=checkpoint)


def _get_checkpoint():
    """Return the trial's restore checkpoint (set by Ray on resume), or None."""
    try:
        from ray.tune import get_checkpoint  # Ray >= 2.34

        return get_checkpoint()
    except ImportError:
        pass
    try:
        from ray.train import get_checkpoint  # Ray 2.7 - 2.33

        return get_checkpoint()
    except ImportError:
        pass
    from ray.air import session  # Ray 2.0 - 2.6

    return session.get_checkpoint()


def _checkpoint_from_directory(path: str):
    """Wrap a local directory as a Ray Tune Checkpoint."""
    try:
        from ray.tune import Checkpoint  # Ray >= 2.34
    except ImportError:
        from ray.train import Checkpoint  # Ray 2.7 - 2.33

    return Checkpoint.from_directory(path)


def _trial_log_dir() -> str:
    """A unique, writable log dir for the trial's runner (required by the logger)."""
    try:
        from ray import tune

        return tune.get_context().get_trial_dir()
    except Exception:
        import tempfile

        return tempfile.mkdtemp(prefix="gslab_tune_")


def train_eval_trial(search_params: dict[str, float], cfg: TuneConfig) -> None:
    """One Ray trial: train in chunks, evaluate, and report the objective.

    Runs in a dedicated Ray worker process, so ``gs.init`` is safe to call here.
    """
    device = init_genesis(gpu=True, performance_mode=True)

    env_cfg = load_env_cfg(cfg.task_id)
    agent_cfg = load_rl_cfg(cfg.task_id)
    env_cfg.scene.num_envs = cfg.num_envs
    apply_search_params(env_cfg, search_params)

    # Tuning-time logging: local tensorboard only, no checkpoint uploads, fixed seed.
    agent_cfg.logger = "tensorboard"
    agent_cfg.upload_model = False
    agent_cfg.seed = cfg.seed

    env = make_env(env_cfg, clip_actions=agent_cfg.clip_actions)
    runner = make_runner(env, agent_cfg, log_dir=_trial_log_dir(), device=device)

    # On resume Ray hands back the last checkpoint this trial reported; load it so we
    # continue mid-training instead of restarting at iteration 0. runner.load()
    # restores the policy, optimizer, iteration count, and env step counter.
    completed = 0
    checkpoint = _get_checkpoint()
    if checkpoint is not None:
        with checkpoint.as_directory() as ckpt_dir:
            runner.load(os.path.join(ckpt_dir, _CHECKPOINT_FILE))
        completed = runner.current_learning_iteration

    # Only randomize episode lengths when starting a trial from scratch.
    first_chunk = completed == 0
    gated_reports = 0
    while completed < cfg.iterations:
        n = min(cfg.iters_per_report, cfg.iterations - completed)
        # learn() re-fetches observations at the start of every call, so chunked
        # training with eval in between is equivalent to one continuous run.
        runner.learn(num_learning_iterations=n, init_at_random_ep_len=first_chunk)
        first_chunk = False
        completed += n

        policy = runner.get_inference_policy(device=device)
        metrics = evaluate_policy(env, policy, device, cfg.eval_steps)
        objective = compute_objective(
            metrics,
            lambda_yaw=cfg.lambda_yaw,
            beta_survival=cfg.beta_survival,
            w_action_rate=cfg.w_action_rate,
            fall_rate_gate=cfg.fall_rate_gate,
            gate_penalty=cfg.gate_penalty,
        )
        gated_reports = gated_reports + 1 if objective >= cfg.gate_penalty else 0
        # Checkpoint after every chunk so an interrupted study can resume here.
        # report() copies the dir to persistent storage before the context exits.
        with tempfile.TemporaryDirectory() as ckpt_dir:
            runner.save(os.path.join(ckpt_dir, _CHECKPOINT_FILE))
            _report(
                {"objective": objective, "iter": completed, **metrics},
                checkpoint=_checkpoint_from_directory(ckpt_dir),
            )
        if cfg.gate_patience and gated_reports >= cfg.gate_patience:
            print(
                f"[INFO] Stopping trial early: fall rate above {cfg.fall_rate_gate} "
                f"for {gated_reports} consecutive reports."
            )
            break

    env.close()


def _build_param_space() -> dict:
    """Translate SEARCH_SPACE into Ray Tune search distributions."""
    from ray import tune

    samplers = {"uniform": tune.uniform, "loguniform": tune.loguniform}
    return {
        name: samplers[kind](low, high)
        for name, (low, high, kind) in SEARCH_SPACE.items()
    }


def run_tuning(cfg: TuneConfig):
    """Build and run the Ray Tune + Optuna study; return the ResultGrid."""
    from ray import tune
    from ray.tune.schedulers import ASHAScheduler
    from ray.tune.search.optuna import OptunaSearch

    try:
        from ray.tune import FailureConfig, RunConfig  # Ray >= 2.34
    except ImportError:  # pragma: no cover - older Ray
        from ray.air import FailureConfig, RunConfig

    trainable = tune.with_parameters(train_eval_trial, cfg=cfg)
    trainable = tune.with_resources(trainable, {"gpu": cfg.gpus_per_trial})

    exp_path = os.path.join(cfg.storage_path, cfg.study_name)

    if cfg.resume:
        if not tune.Tuner.can_restore(exp_path):
            raise FileNotFoundError(
                f"--resume given but no restorable study at {exp_path!r}. "
                "Run without --resume to start a new study."
            )
        # restore() rehydrates trials, checkpoints, and the Optuna searcher from
        # disk; the trainable must be passed again since it isn't serialized.
        tuner = tune.Tuner.restore(
            exp_path,
            trainable=trainable,
            resume_unfinished=True,
            resume_errored=cfg.resume_errored,
        )
    else:
        # ASHA prunes trials whose objective lags at each rung; Optuna (TPE) proposes
        # the configs. metric/mode live on TuneConfig so we don't double-specify them.
        # grace_period=0 sets the first rung at max_t, i.e. no rank-based pruning
        # (pre-emergence rungs would prune on noise -- see module docstring).
        scheduler = ASHAScheduler(
            time_attr="iter",
            max_t=cfg.iterations,
            grace_period=cfg.grace_period or cfg.iterations,
            reduction_factor=cfg.reduction_factor,
        )

        # The first trial evaluates the training-default config, so the study
        # measures the baseline it has to beat (and TPE starts from a known-good
        # point instead of a random one).
        search_alg = OptunaSearch(
            points_to_evaluate=[default_search_params(load_env_cfg(cfg.task_id))]
        )

        tuner = tune.Tuner(
            trainable,
            param_space=_build_param_space(),
            tune_config=tune.TuneConfig(
                metric="objective",
                mode="min",
                search_alg=search_alg,
                scheduler=scheduler,
                num_samples=cfg.num_samples,
                max_concurrent_trials=cfg.max_concurrent or None,
                reuse_actors=False,
            ),
            run_config=RunConfig(
                name=cfg.study_name,
                storage_path=cfg.storage_path,
                failure_config=FailureConfig(max_failures=cfg.max_failures),
            ),
        )

    results = tuner.fit()
    best = results.get_best_result(metric="objective", mode="min")
    print("\n[INFO] Best trial:")
    print(f"  objective = {best.metrics.get('objective')}")
    print(f"  config    = {best.config}")
    if best.config:
        env_cfg = load_env_cfg(cfg.task_id)
        apply_search_params(env_cfg, best.config)
        print("\n[INFO] Train with the winning hyperparameters:")
        print(train_cli_command(env_cfg, cfg.num_envs))
    return results


def main() -> None:
    cfg = tyro.cli(TuneConfig)
    run_tuning(cfg)


if __name__ == "__main__":
    main()
