# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Tuning objective: evaluate a trained policy and reduce it to a scalar.

The objective deliberately does *not* use the shaped reward sum (that is the very
thing being tuned, so it is not comparable across trials). Instead it uses the raw
command-tracking errors -- the same quantities the command manager logs as
``Metrics/twist/error_vel_{xy,yaw}`` -- computed directly each step so the estimate
is independent of episode boundaries.
"""

from __future__ import annotations

import torch

from gslab.envs.mdp.observations import base_ang_vel, base_lin_vel
from gslab.rl import RslRlVecEnvWrapper


def evaluate_policy(
    env: RslRlVecEnvWrapper,
    policy,
    device: str,
    num_steps: int,
) -> dict[str, float]:
    """Roll out ``policy`` and measure velocity-tracking error and stability.

    Commands are resampled across the full command range during the rollout (the
    command manager does this on its own interval), so the mean error is taken over
    the command distribution. ``fall_rate`` is the fraction of completed episodes
    that ended in a non-timeout termination (i.e. the robot fell).
    """
    gs_env = env.unwrapped

    err_xy_sum = 0.0
    err_yaw_sum = 0.0
    act_rate_sum = 0.0
    act_rate_steps = 0
    falls = 0
    episodes = 0

    prev_actions: torch.Tensor | None = None
    prev_done: torch.Tensor | None = None

    obs = env.get_observations().to(device)
    with torch.inference_mode():
        for _ in range(num_steps):
            actions = policy(obs)
            # Mean per-joint action change, skipping envs that were just reset (their
            # jump from the previous action is an episode boundary, not jerkiness).
            if prev_actions is not None:
                diff = torch.abs(actions - prev_actions).mean(dim=-1)
                if prev_done is not None:
                    diff = diff[~prev_done]
                if diff.numel():
                    act_rate_sum += float(diff.mean())
                    act_rate_steps += 1
            prev_actions = actions.clone()
            obs, _, dones, extras = env.step(actions.to(env.device))
            obs = obs.to(device)
            prev_done = dones.bool().to(actions.device)

            cmd = gs_env.commands
            err_xy_sum += float(
                torch.norm(cmd[:, :2] - base_lin_vel(gs_env)[:, :2], dim=-1).mean()
            )
            err_yaw_sum += float(
                torch.abs(cmd[:, 2] - base_ang_vel(gs_env)[:, 2]).mean()
            )

            done_mask = dones.bool()
            num_done = int(done_mask.sum())
            if num_done:
                episodes += num_done
                time_outs = extras.get("time_outs")
                if time_outs is not None:
                    fell = done_mask & ~time_outs.to(done_mask.device).bool()
                    falls += int(fell.sum())

    return {
        "error_vel_xy": err_xy_sum / num_steps,
        "error_vel_yaw": err_yaw_sum / num_steps,
        "action_rate": act_rate_sum / act_rate_steps if act_rate_steps else 0.0,
        "fall_rate": (falls / episodes) if episodes else 0.0,
        "n_episodes": float(episodes),
    }


def compute_objective(
    metrics: dict[str, float],
    *,
    lambda_yaw: float = 0.5,
    beta_survival: float = 1.0,
    w_action_rate: float = 0.5,
    fall_rate_gate: float = 0.5,
    gate_penalty: float = 100.0,
) -> float:
    """Collapse eval metrics into a single scalar to *minimize*.

    ``objective = error_vel_xy + lambda_yaw * error_vel_yaw
    + w_action_rate * action_rate + beta_survival * fall_rate``

    The action-rate term matters because the smoothness penalty weights
    (``action_rate_l2``, ``joint_acc_l2``) are themselves search dimensions: with a
    tracking-only objective the optimizer's best move is to zero them out, which
    yields jerky policies that score well in sim but are not usable.

    A hard survival gate returns ``gate_penalty`` when the policy falls too often, so
    the optimizer cannot trade stability for a cheap tracking number.
    """
    fall_rate = metrics["fall_rate"]
    if fall_rate > fall_rate_gate:
        return gate_penalty
    return (
        metrics["error_vel_xy"]
        + lambda_yaw * metrics["error_vel_yaw"]
        + w_action_rate * metrics.get("action_rate", 0.0)
        + beta_survival * fall_rate
    )
