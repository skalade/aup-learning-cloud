# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Shared utilities for ONNX policy export across RL tasks."""

import onnx
import torch

from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv


def list_to_csv_str(arr, *, decimals: int = 3, delimiter: str = ",") -> str:
    """Convert list to CSV string with specified decimal precision."""
    fmt = f"{{:.{decimals}f}}"
    return delimiter.join(
        fmt.format(x)
        if isinstance(x, (int, float))
        else str(x)  # numbers → format, strings → as-is
        for x in arr
    )


def get_base_metadata(
    env: GenesisManagerBasedRlEnv, run_path: str
) -> dict[str, list | str | float]:
    """Get base metadata common to all RL policy exports.

    Args:
      env: The RL environment.
      run_path: W&B run path or other identifier.

    Returns:
      Dictionary of metadata fields that are common across all tasks.
    """
    robot = env.scene["robot"]
    joint_action = env.action_manager.get_term("joint_pos")
    # Build mapping from joint name to actuator ID for natural joint order.
    # Each spec actuator controls exactly one joint (via its target field).
    joint_name_to_ctrl_id = {}
    for actuator in robot.spec.actuators:
        joint_name = actuator.target.split("/")[-1]
        joint_name_to_ctrl_id[joint_name] = actuator.id
    # Get actuator IDs in natural joint order (same order as robot.joint_names).
    ctrl_ids_natural = [
        joint_name_to_ctrl_id[jname]
        for jname in robot.joint_names  # global joint order
        if jname in joint_name_to_ctrl_id  # skip non-actuated joints
    ]
    joint_stiffness = env.sim.mj_model.actuator_gainprm[ctrl_ids_natural, 0]
    joint_damping = -env.sim.mj_model.actuator_biasprm[ctrl_ids_natural, 2]
    return {
        "run_path": run_path,
        "joint_names": list(robot.joint_names),
        "joint_stiffness": joint_stiffness.tolist(),
        "joint_damping": joint_damping.tolist(),
        "default_joint_pos": robot.data.default_joint_pos[0].cpu().tolist(),
        "command_names": list(env.command_manager.active_terms),
        "observation_names": env.observation_manager.active_terms["actor"],
        "action_scale": joint_action._scale[0].cpu().tolist()
        if isinstance(joint_action._scale, torch.Tensor)
        else joint_action._scale,
    }


def attach_metadata_to_onnx(
    onnx_path: str, metadata: dict[str, list | str | float]
) -> None:
    """Attach metadata to an ONNX model file.

    Args:
      onnx_path: Path to the ONNX model file.
      metadata: Dictionary of metadata key-value pairs to attach.
    """
    model = onnx.load(onnx_path)

    for k, v in metadata.items():
        entry = onnx.StringStringEntryProto()
        entry.key = k
        entry.value = list_to_csv_str(v) if isinstance(v, list) else str(v)
        model.metadata_props.append(entry)

    onnx.save(model, onnx_path)
