# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Single source of truth for building the RL runtime.

Genesis initialization, the env wrapper, and the runner are constructed here so that
training (``train.py``), tuning (``rl/tune``), and the eval scripts (``scripts/``) all
build the environment exactly one way instead of each rolling their own.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import asdict

import genesis as gs
import torch

from gslab.envs import GenesisManagerBasedRlEnv, ManagerBasedRlEnvCfg
from gslab.rl import RslRlVecEnvWrapper
from gslab.rl.config import RslRlBaseRunnerCfg
from gslab.rl.rsl_rl.runner import GslabOnPolicyRunner


def init_genesis(*, gpu: bool | None = None, **gs_init_kwargs) -> str:
    """Initialize Genesis and return the matching torch device string.

    ``gpu=None`` auto-selects the GPU backend when it is available, otherwise CPU.
    Pass ``gpu=True`` to require the GPU backend (Genesis raises if none is present).
    """
    use_gpu = torch.cuda.is_available() if gpu is None else gpu
    gs.init(backend=gs.gpu if use_gpu else gs.cpu, **gs_init_kwargs)
    return "cuda" if use_gpu else "cpu"


def make_env(
    env_cfg: ManagerBasedRlEnvCfg,
    *,
    clip_actions: float | None = None,
    show_viewer: bool = False,
    enable_gui: bool = False,
    pre_build_hooks: list[Callable] | None = None,
) -> RslRlVecEnvWrapper:
    """Build the Genesis environment and wrap it for RSL-RL."""
    gs_env = GenesisManagerBasedRlEnv(
        cfg=env_cfg,
        show_viewer=show_viewer,
        enable_gui=enable_gui,
        pre_build_hooks=pre_build_hooks,
    )
    return RslRlVecEnvWrapper(gs_env, clip_actions=clip_actions)


def make_runner(
    env: RslRlVecEnvWrapper,
    agent_cfg: RslRlBaseRunnerCfg,
    *,
    log_dir: str | None = None,
    device: str = "cuda",
) -> GslabOnPolicyRunner:
    """Construct the on-policy runner from an agent-config dataclass."""
    return GslabOnPolicyRunner(env, asdict(agent_cfg), log_dir=log_dir, device=device)
