# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Procedural terrain generation.

The public API mirrors mjlab's ``mjlab.terrains`` and Isaac Lab's
``isaaclab.terrains``: a ``TerrainGeneratorCfg`` holding named
``SubTerrainCfg`` entries, wrapped by a ``TerrainEntityCfg`` that the scene
config points at. Sub-terrains are heightfield-based (``Hf*`` prefix, as in
Isaac Lab) and are tiled into a single Genesis ``Terrain`` morph.

``gslab.terrains.config`` holds ready-made presets, including
``STAIRS_TERRAINS_CFG`` used by the G1 stairs task.
"""

from gslab.terrains.height_field import BoxStairsTerrainCfg as BoxStairsTerrainCfg
from gslab.terrains.height_field import (
    HfDiscreteObstaclesTerrainCfg as HfDiscreteObstaclesTerrainCfg,
)
from gslab.terrains.height_field import HfFlatTerrainCfg as HfFlatTerrainCfg
from gslab.terrains.height_field import (
    HfInvertedPyramidSlopedTerrainCfg as HfInvertedPyramidSlopedTerrainCfg,
)
from gslab.terrains.height_field import (
    HfInvertedPyramidStairsTerrainCfg as HfInvertedPyramidStairsTerrainCfg,
)
from gslab.terrains.height_field import (
    HfPyramidSlopedTerrainCfg as HfPyramidSlopedTerrainCfg,
)
from gslab.terrains.height_field import (
    HfPyramidStairsTerrainCfg as HfPyramidStairsTerrainCfg,
)
from gslab.terrains.height_field import (
    HfRandomUniformTerrainCfg as HfRandomUniformTerrainCfg,
)
from gslab.terrains.height_field import HfStairsTerrainCfg as HfStairsTerrainCfg
from gslab.terrains.height_field import (
    HfSteppingStonesTerrainCfg as HfSteppingStonesTerrainCfg,
)
from gslab.terrains.height_field import HfTerrainBaseCfg as HfTerrainBaseCfg
from gslab.terrains.height_field import HfWaveTerrainCfg as HfWaveTerrainCfg
from gslab.terrains.terrain_entity import TerrainEntity as TerrainEntity
from gslab.terrains.terrain_entity import TerrainEntityCfg as TerrainEntityCfg
from gslab.terrains.terrain_generator import BoxSpec as BoxSpec
from gslab.terrains.terrain_generator import SubTerrainCfg as SubTerrainCfg
from gslab.terrains.terrain_generator import TerrainGenerator as TerrainGenerator
from gslab.terrains.terrain_generator import TerrainGeneratorCfg as TerrainGeneratorCfg
from gslab.terrains.terrain_generator import TerrainOutput as TerrainOutput
