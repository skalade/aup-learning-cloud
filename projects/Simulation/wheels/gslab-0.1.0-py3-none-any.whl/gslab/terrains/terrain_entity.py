# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Literal

import genesis as gs
import numpy as np
import torch

from gslab.entity import EntityCfg
from gslab.terrains.terrain_generator import TerrainGenerator, TerrainGeneratorCfg


def _proportional_counts(num_envs: int, proportions: np.ndarray) -> np.ndarray:
    """Distribute ``num_envs`` across buckets proportionally.

    Every bucket gets at least one when ``num_envs >= len(proportions)``.
    Remaining slots are allocated via the Largest Remainder Method.
    """
    n = len(proportions)
    if num_envs >= n:
        counts = np.ones(n, dtype=int)
        remaining = num_envs - n
    else:
        counts = np.zeros(n, dtype=int)
        remaining = num_envs
    if remaining > 0:
        ideal = proportions * remaining
        floor = np.floor(ideal).astype(int)
        counts += floor
        leftover = remaining - floor.sum()
        if leftover > 0:
            order = np.argsort(-(ideal - floor))
            counts[order[:leftover]] += 1
    return counts


@dataclass
class TerrainEntityCfg(EntityCfg):
    """Configuration for terrain as an entity."""

    terrain_type: Literal["generator", "plane"] = "plane"
    """Type of terrain to generate. "generator" uses procedural terrain with
  sub-terrain grid, "plane" creates a flat ground plane."""
    terrain_generator: TerrainGeneratorCfg | None = None
    """Configuration for procedural terrain generation. Required when
  terrain_type is "generator"."""
    env_spacing: float | None = 2.0
    """Distance between environment origins when using grid layout. Required for
  "plane" terrain or when no sub-terrain origins exist."""
    max_init_terrain_level: int | None = None
    """Maximum initial difficulty level (row index) for environment placement in
  curriculum mode. None uses all available rows."""
    num_envs: int = 1
    """Number of parallel environments to create. Overridden by the scene
  configuration."""
    name: str | None = None
    """Cache name for the generated terrain, or None to disable caching.

  Genesis caches the collision mesh and SDF it builds for a named morph, which
  is the expensive part of a cold start. A digest of the heightfield is appended
  to this name (see ``TerrainEntity._cache_key``), so the cache can never go
  stale and the name only needs to be human-readable."""
    spawn_jitter: float = 0.0
    """Radius of a fixed per-environment offset applied to spawn positions
  within a sub-terrain patch, in meters.

  gslab-specific: several environments usually share a patch, and without any
  offset they would start from an identical pose and produce near-identical
  rollouts. mjlab and Isaac Lab instead randomize the root pose every reset via
  an event term; gslab has no root-reset event yet, so the offset is drawn once
  at construction and stays fixed for the environment's lifetime."""
    debug_vis: bool = False
    """Draw debug spheres at the environment and sub-terrain origins. Requires a
  viewer or camera to be visible."""


class TerrainEntity:
    """Terrain as a Genesis entity, plus the spawn bookkeeping around it.

    For ``terrain_type="generator"`` a :class:`TerrainGenerator` tiles the
    sub-terrain grid into one heightfield and Genesis turns it into a single
    collision mesh. Environments are then distributed over the grid: columns
    (terrain types) by ``proportion``, rows (difficulty levels) at random up to
    ``max_init_terrain_level``. Several environments may share a patch, which is
    fine because Genesis' parallel environments are physically coincident — they
    share the terrain mesh and only differ in where their robot stands on it.

    For ``terrain_type="plane"`` the entity is a Genesis plane and environment
    origins fall back to a square grid with ``env_spacing``, matching mjlab.
    """

    cfg: TerrainEntityCfg

    def __init__(self, cfg: TerrainEntityCfg, device: torch.device | str) -> None:
        self.cfg = cfg
        self._device = device
        self.terrain_generator: TerrainGenerator | None = None
        self.terrain_origins: torch.Tensor | None = None
        self.terrain_levels: torch.Tensor | None = None
        self.terrain_types: torch.Tensor | None = None
        self.max_terrain_level: int = 0
        # Device-resident heightfield for height_at; None for plane terrain.
        self._height_field: torch.Tensor | None = None

        if cfg.terrain_type == "generator":
            if cfg.terrain_generator is None:
                raise ValueError(
                    "terrain_generator must be specified for terrain_type 'generator'"
                )
            self.terrain_generator = TerrainGenerator(cfg.terrain_generator)
            self._cache_height_field()
            self._configure_env_origins(
                self.terrain_generator.terrain_origins,
                self.terrain_generator.proportions,
            )
        elif cfg.terrain_type == "plane":
            self._configure_env_origins()
        else:
            raise ValueError(f"Unknown terrain type: {cfg.terrain_type}")

        self._apply_spawn_jitter()

    # Morph construction.

    def morph(self) -> gs.options.morphs.Morph:
        """Build the Genesis morph for this terrain."""
        if self.terrain_generator is None:
            return gs.morphs.Plane(
                pos=self.cfg.init_state.pos,
                quat=self.cfg.init_state.rot,
                collision=True,
                visualization=True,
            )

        generator = self.terrain_generator
        offset = np.array(generator.origin_offset) + np.array(self.cfg.init_state.pos)
        return gs.morphs.Terrain(
            height_field=generator.height_field,
            horizontal_scale=generator.cfg.horizontal_scale,
            vertical_scale=generator.cfg.vertical_scale,
            pos=tuple(offset.tolist()),
            name=self._cache_key(),
            collision=True,
            visualization=True,
        )

    def box_morphs(self) -> list[gs.options.morphs.Morph]:
        """Solid step boxes to add alongside the heightfield.

        Empty unless a sub-terrain emitted boxes. These carry the vertical
        faces a heightfield cannot express; Genesis handles them as analytic
        primitives, so a flight of stairs costs a handful of entities.
        """
        if self.terrain_generator is None:
            return []
        base = np.array(self.cfg.init_state.pos)
        return [
            gs.morphs.Box(
                pos=tuple((np.array(box.pos) + base).tolist()),
                size=box.size,
                fixed=True,
                collision=True,
                visualization=True,
            )
            for box in self.terrain_generator.boxes
        ]

    def _cache_key(self) -> str | None:
        """Genesis asset-cache key for the generated terrain.

        Genesis keys its cached collision mesh and SDF on the morph name, so a
        name alone would serve a stale mesh whenever the heightfield changes —
        including when an unseeded generator produces different terrain on the
        next run. Appending a digest of the heightfield makes a stale hit
        impossible while still reusing the (expensive) mesh and SDF whenever the
        terrain really is identical.
        """
        if self.cfg.name is None or self.terrain_generator is None:
            return None
        digest = hashlib.sha1(
            np.ascontiguousarray(self.terrain_generator.height_field, dtype=np.float32)
        ).hexdigest()[:12]
        return f"{self.cfg.name}_{digest}"

    def draw_debug_vis(self, scene: gs.Scene) -> None:
        """Draw spawn markers. Call after ``scene.build``."""
        if not self.cfg.debug_vis:
            return
        scene.draw_debug_spheres(
            self.env_origins.cpu().numpy(), radius=0.12, color=(0.2, 0.8, 0.2, 0.6)
        )
        if self.terrain_origins is not None:
            scene.draw_debug_spheres(
                self.terrain_origins.reshape(-1, 3).cpu().numpy(),
                radius=0.25,
                color=(0.2, 0.2, 0.9, 0.4),
            )

    # Terrain queries.

    def height_at(self, positions: torch.Tensor) -> torch.Tensor:
        """Terrain height, in meters, under world ``(x, y)`` points.

        Nearest-cell lookup, no interpolation. Points outside the heightfield
        clamp to the nearest edge cell. Returns zeros for plane terrain.

        Runs entirely on ``positions``' device, so this is safe to call from
        observation and reward terms every step.

        Args:
          positions: ``(..., 2)`` or ``(..., 3)`` world coordinates; only the
            first two components are read.

        Returns:
          Heights with ``positions``' leading shape.
        """
        if self._height_field is None:
            return torch.zeros(positions.shape[:-1], device=positions.device)
        field = self._height_field.to(positions.device)
        row = torch.clamp(
            torch.round(
                (positions[..., 0] - self._offset_x) / self._horizontal_scale
            ).long(),
            0,
            field.shape[0] - 1,
        )
        col = torch.clamp(
            torch.round(
                (positions[..., 1] - self._offset_y) / self._horizontal_scale
            ).long(),
            0,
            field.shape[1] - 1,
        )
        return field[row, col] * self._vertical_scale

    # Terrain-level curriculum.

    def update_env_origins(
        self,
        env_ids: torch.Tensor,
        move_up: torch.Tensor,
        move_down: torch.Tensor,
    ) -> None:
        """Promote or demote environments along the difficulty axis."""
        if self.terrain_origins is None:
            return
        assert self.terrain_levels is not None and self.terrain_types is not None
        self.terrain_levels[env_ids] += 1 * move_up - 1 * move_down
        # Environments that clear the hardest level are recycled to a random
        # level rather than being clamped there, which keeps easy terrain in the
        # batch and stops the curriculum from collapsing onto one difficulty.
        self.terrain_levels[env_ids] = torch.where(
            self.terrain_levels[env_ids] >= self.max_terrain_level,
            torch.randint_like(self.terrain_levels[env_ids], self.max_terrain_level),
            torch.clip(self.terrain_levels[env_ids], 0),
        )
        self.env_origins[env_ids] = self._origins_for(env_ids)

    def randomize_env_origins(self, env_ids: torch.Tensor) -> None:
        """Move environments to randomly chosen sub-terrains."""
        if self.terrain_origins is None:
            return
        assert self.terrain_levels is not None and self.terrain_types is not None
        num_rows, num_cols = self.terrain_origins.shape[:2]
        num_envs = len(env_ids)
        self.terrain_levels[env_ids] = torch.randint(
            0, num_rows, (num_envs,), device=self._device
        )
        self.terrain_types[env_ids] = torch.randint(
            0, num_cols, (num_envs,), device=self._device
        )
        self.env_origins[env_ids] = self._origins_for(env_ids)

    # Private methods.

    def _cache_height_field(self) -> None:
        """Move the heightfield and its frame onto the device for ``height_at``.

        ``height_at`` runs from observation and reward terms, so the lookup has
        to stay on the GPU; a numpy round-trip per step would dominate.
        """
        assert self.terrain_generator is not None
        generator = self.terrain_generator
        # The *query* field, which has box tops stamped in — the mesh field is
        # flat under a box staircase and would report open floor there.
        self._height_field = torch.from_numpy(
            np.ascontiguousarray(generator.query_field, dtype=np.float32)
        ).to(self._device)
        self._offset_x, self._offset_y, _ = generator.origin_offset
        self._offset_x += self.cfg.init_state.pos[0]
        self._offset_y += self.cfg.init_state.pos[1]
        self._horizontal_scale = generator.cfg.horizontal_scale
        self._vertical_scale = generator.cfg.vertical_scale

    def _origins_for(self, env_ids: torch.Tensor) -> torch.Tensor:
        """Spawn positions for ``env_ids`` from their current (level, type).

        The jittered ``(x, y)`` may land on a different step than the patch
        centre, so ``z`` is re-queried from the heightfield rather than carried
        over from the patch origin.
        """
        assert self.terrain_origins is not None
        assert self.terrain_levels is not None and self.terrain_types is not None
        origins = (
            self.terrain_origins[
                self.terrain_levels[env_ids], self.terrain_types[env_ids]
            ]
            + self._spawn_jitter[env_ids]
        )
        origins[:, 2] = self.height_at(origins)
        return origins

    def _configure_env_origins(
        self,
        origins: np.ndarray | None = None,
        proportions: np.ndarray | None = None,
    ) -> None:
        if origins is not None:
            self.terrain_origins = torch.from_numpy(np.asarray(origins)).to(
                self._device, dtype=torch.float32
            )
            self.env_origins = self._compute_env_origins_curriculum(
                self.cfg.num_envs, self.terrain_origins, proportions
            )
        else:
            self.terrain_origins = None
            if self.cfg.env_spacing is None:
                raise ValueError(
                    "env_spacing must be specified for configuring grid-like origins."
                )
            self.env_origins = self._compute_env_origins_grid(
                self.cfg.num_envs, self.cfg.env_spacing
            )

    def _compute_env_origins_curriculum(
        self,
        num_envs: int,
        origins: torch.Tensor,
        proportions: np.ndarray | None = None,
    ) -> torch.Tensor:
        """Place environments on sub-terrain patches.

        Args:
          num_envs: Number of environments to place.
          origins: Sub-terrain origins, shape ``[num_rows, num_cols, 3]``.
          proportions: Normalized per-column weights. When provided, robots are
            distributed proportionally (every column gets at least one when
            ``num_envs >= num_cols``). ``None`` gives an even distribution.
        """
        num_rows, num_cols = origins.shape[:2]
        if self.cfg.max_init_terrain_level is None:
            max_init_level = num_rows - 1
        else:
            max_init_level = min(self.cfg.max_init_terrain_level, num_rows - 1)
        self.max_terrain_level = num_rows
        self.terrain_levels = torch.randint(
            0, max_init_level + 1, (num_envs,), device=self._device
        )

        if proportions is not None and len(proportions) == num_cols:
            counts = _proportional_counts(num_envs, proportions)
            self.terrain_types = torch.repeat_interleave(
                torch.arange(num_cols, device=self._device),
                torch.from_numpy(counts).to(self._device),
            )
        else:
            self.terrain_types = torch.div(
                torch.arange(num_envs, device=self._device),
                (num_envs / num_cols),
                rounding_mode="floor",
            ).to(torch.long)

        env_origins = torch.zeros(num_envs, 3, device=self._device)
        env_origins[:] = origins[self.terrain_levels, self.terrain_types]
        return env_origins

    def _compute_env_origins_grid(
        self, num_envs: int, env_spacing: float
    ) -> torch.Tensor:
        env_origins = torch.zeros(num_envs, 3, device=self._device)
        num_rows = np.ceil(num_envs / int(np.sqrt(num_envs)))
        num_cols = np.ceil(num_envs / num_rows)
        ii, jj = torch.meshgrid(
            torch.arange(num_rows, device=self._device),
            torch.arange(num_cols, device=self._device),
            indexing="ij",
        )
        env_origins[:, 0] = (
            -(ii.flatten()[:num_envs] - (num_rows - 1) / 2) * env_spacing
        )
        env_origins[:, 1] = (jj.flatten()[:num_envs] - (num_cols - 1) / 2) * env_spacing
        env_origins[:, 2] = 0.0
        return env_origins

    def _apply_spawn_jitter(self) -> None:
        """Draw the fixed per-environment spawn offset (see cfg.spawn_jitter)."""
        self._spawn_jitter = torch.zeros(self.cfg.num_envs, 3, device=self._device)
        if self.cfg.spawn_jitter <= 0.0 or self.terrain_origins is None:
            return
        self._spawn_jitter[:, :2].uniform_(
            -self.cfg.spawn_jitter, self.cfg.spawn_jitter
        )
        env_ids = torch.arange(self.cfg.num_envs, device=self._device)
        self.env_origins[:] = self._origins_for(env_ids)
