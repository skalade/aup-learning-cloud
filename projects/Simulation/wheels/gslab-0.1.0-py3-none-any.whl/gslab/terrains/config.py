# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
"""Terrain configuration presets and named terrain sets.

Each terrain type has a preset function with sensible defaults; override any
parameter at the call site. Named configs (``STAIRS``, ``ROUGH``, ``ALL``)
compose presets.

To add a new terrain, define a function decorated with ``@terrain_preset``::

    @terrain_preset
    def my_new_terrain(**overrides: Any) -> terrain_gen.HfSomeTerrainCfg:
        defaults: dict[str, Any] = dict(...)
        defaults.update(overrides)
        return terrain_gen.HfSomeTerrainCfg(**defaults)

It is then auto-included in ``ALL_TERRAIN_PRESETS`` and ``ALL_TERRAINS_CFG``.

Grid size is the main cost knob: the heightfield is one mesh, so vertex count
grows with ``num_rows * num_cols * size / horizontal_scale**2`` and drives scene
build time. The presets here stay modest so a cold start is seconds.
"""

from collections.abc import Callable
from typing import Any, TypeVar

import gslab.terrains as terrain_gen
from gslab.terrains.terrain_generator import SubTerrainCfg, TerrainGeneratorCfg

# Preset registry.

ALL_TERRAIN_PRESETS: dict[str, Callable[..., SubTerrainCfg]] = {}

_F = TypeVar("_F", bound=Callable[..., SubTerrainCfg])


def terrain_preset(fn: _F) -> _F:
    """Register a terrain preset into ``ALL_TERRAIN_PRESETS``."""
    ALL_TERRAIN_PRESETS[fn.__name__] = fn
    return fn


# Terrain presets.


@terrain_preset
def flat(**overrides: Any) -> terrain_gen.HfFlatTerrainCfg:
    return terrain_gen.HfFlatTerrainCfg(**overrides)


@terrain_preset
def pyramid_stairs(**overrides: Any) -> terrain_gen.HfPyramidStairsTerrainCfg:
    defaults: dict[str, Any] = dict(
        step_height_range=(0.05, 0.18),
        step_width=0.32,
        platform_width=2.5,
        border_width=0.5,
    )
    defaults.update(overrides)
    return terrain_gen.HfPyramidStairsTerrainCfg(**defaults)


@terrain_preset
def pyramid_stairs_inv(
    **overrides: Any,
) -> terrain_gen.HfInvertedPyramidStairsTerrainCfg:
    defaults: dict[str, Any] = dict(
        step_height_range=(0.05, 0.18),
        step_width=0.32,
        platform_width=2.5,
        border_width=0.5,
    )
    defaults.update(overrides)
    return terrain_gen.HfInvertedPyramidStairsTerrainCfg(**defaults)


@terrain_preset
def straight_stairs(**overrides: Any) -> terrain_gen.HfStairsTerrainCfg:
    defaults: dict[str, Any] = dict(
        step_height_range=(0.05, 0.16),
        step_width=0.32,
        border_width=0.5,
    )
    defaults.update(overrides)
    return terrain_gen.HfStairsTerrainCfg(**defaults)


@terrain_preset
def real_stairs(**overrides: Any) -> terrain_gen.BoxStairsTerrainCfg:
    """A building-code staircase with true vertical risers.

    The heightfield presets above cannot make a vertical face — a riser ramps
    across one cell — so this one is built from solid boxes instead.
    """
    defaults: dict[str, Any] = dict(
        step_height_range=(0.10, 0.18),
        step_width=0.28,
        num_steps=8,
        approach_length=2.5,
    )
    defaults.update(overrides)
    return terrain_gen.BoxStairsTerrainCfg(**defaults)


@terrain_preset
def random_rough(**overrides: Any) -> terrain_gen.HfRandomUniformTerrainCfg:
    defaults: dict[str, Any] = dict(
        noise_range=(0.02, 0.10),
        noise_step=0.02,
        border_width=0.25,
    )
    defaults.update(overrides)
    return terrain_gen.HfRandomUniformTerrainCfg(**defaults)


@terrain_preset
def hf_pyramid_slope(**overrides: Any) -> terrain_gen.HfPyramidSlopedTerrainCfg:
    defaults: dict[str, Any] = dict(
        slope_range=(0.0, 0.4),
        platform_width=2.0,
        border_width=0.25,
    )
    defaults.update(overrides)
    return terrain_gen.HfPyramidSlopedTerrainCfg(**defaults)


@terrain_preset
def hf_pyramid_slope_inv(
    **overrides: Any,
) -> terrain_gen.HfInvertedPyramidSlopedTerrainCfg:
    defaults: dict[str, Any] = dict(
        slope_range=(0.0, 0.4),
        platform_width=2.0,
        border_width=0.25,
    )
    defaults.update(overrides)
    return terrain_gen.HfInvertedPyramidSlopedTerrainCfg(**defaults)


@terrain_preset
def wave_terrain(**overrides: Any) -> terrain_gen.HfWaveTerrainCfg:
    defaults: dict[str, Any] = dict(
        amplitude_range=(0.0, 0.2),
        num_waves=4,
        border_width=0.25,
    )
    defaults.update(overrides)
    return terrain_gen.HfWaveTerrainCfg(**defaults)


@terrain_preset
def discrete_obstacles(**overrides: Any) -> terrain_gen.HfDiscreteObstaclesTerrainCfg:
    defaults: dict[str, Any] = dict(
        obstacle_height_range=(0.05, 0.20),
        obstacle_width_range=(0.3, 1.0),
        num_obstacles=30,
        platform_width=2.0,
        border_width=0.25,
    )
    defaults.update(overrides)
    return terrain_gen.HfDiscreteObstaclesTerrainCfg(**defaults)


@terrain_preset
def stepping_stones(**overrides: Any) -> terrain_gen.HfSteppingStonesTerrainCfg:
    defaults: dict[str, Any] = dict(
        stone_size=0.8,
        stone_distance_range=(0.02, 0.20),
        stone_height_variation=0.05,
        platform_width=2.0,
        border_width=0.25,
    )
    defaults.update(overrides)
    return terrain_gen.HfSteppingStonesTerrainCfg(**defaults)


# Named terrain sets.

STAIRS_TERRAINS_CFG = TerrainGeneratorCfg(
    # Fixed so every run and every worker builds the same terrain.
    seed=0,
    size=(8.0, 8.0),
    num_rows=6,
    num_cols=4,
    curriculum=True,
    # The top of the ladder stops at 0.6 difficulty rather than 1.0.
    #
    # The curriculum concentrates training on whatever levels the policy is
    # currently failing at, so the top of a full-range ladder gets almost no
    # gradient: measured over a run, levels 4 and 5 together saw under 1% of
    # training steps while a uniform evaluation gave them a third of the score.
    # Fine-tuning then reads as a regression, because the policy improves where
    # it trains and drifts where it does not.
    #
    # Compressing the range puts the whole ladder inside reach of a short
    # session: the hardest row is ~11 cm rather than ~16 cm, every level gets
    # real experience, and progress shows up across the board instead of in one
    # row. Raise it back toward 1.0 for a long run that can afford the tail.
    difficulty_range=(0.0, 0.6),
    border_width=4.0,
    horizontal_scale=0.1,
    vertical_scale=0.005,
    sub_terrains={
        # A flat column keeps the flat-ground behaviour the pre-trained policy
        # already has in the batch, so fine-tuning doesn't forget it.
        "flat": flat(proportion=0.25),
        "pyramid_stairs": pyramid_stairs(
            proportion=0.3, step_height_range=(0.04, 0.16)
        ),
        "pyramid_stairs_inv": pyramid_stairs_inv(
            proportion=0.3, step_height_range=(0.04, 0.16)
        ),
        "random_rough": random_rough(proportion=0.15, noise_range=(0.01, 0.06)),
        # Real vertical risers, which none of the heightfield columns can
        # produce. This is the column that looks like a staircase.
        "real_stairs": real_stairs(proportion=0.2),
    },
)
"""Stairs curriculum for the G1 fine-tuning demo.

Six difficulty levels, one column each for flat ground, stairs up, stairs down,
mild rough ground, and a box-built staircase with true 90-degree risers. The
difficulty range is capped so the whole ladder is learnable in a short session;
see the comment on ``difficulty_range``."""

EASY_STAIRS_TERRAINS_CFG = TerrainGeneratorCfg(
    # Fixed so every run and every worker builds the same terrain.
    seed=0,
    size=(8.0, 8.0),
    num_rows=6,
    num_cols=4,
    curriculum=True,
    border_width=4.0,
    horizontal_scale=0.1,
    vertical_scale=0.005,
    sub_terrains={
        # Nearly half the terrain is walkable without any new skill, so a
        # flat-ground policy keeps earning reward while it learns the rest.
        # Without that anchor it falls constantly at the start, gets demoted to
        # the bottom of the ladder, and never sees a step at all.
        "flat": flat(proportion=0.3),
        "pyramid_stairs": pyramid_stairs(
            proportion=0.25,
            step_height_range=(0.02, 0.09),
            step_width=0.36,
            platform_width=3.0,
        ),
        "random_rough": random_rough(proportion=0.15, noise_range=(0.01, 0.04)),
        # Real vertical risers, but a domestic-stair tread and a low rise, so
        # this is the gentlest thing that is still unambiguously a staircase.
        "real_stairs": real_stairs(
            proportion=0.3,
            step_height_range=(0.04, 0.10),
            step_width=0.32,
            num_steps=6,
        ),
    },
)
"""Gentle stairs, for teaching a flat-ground policy its first steps.

Every level is within reach of a policy that can only walk on the flat, so the
curriculum climbs instead of stalling at the bottom. The top of the ladder is a
10 cm riser -- a low step rather than a staircase -- which is the point: the
exercise is acquiring the skill, not mastering it. Graduate to
``STAIRS_TERRAINS_CFG`` once it holds."""

ROUGH_TERRAINS_CFG = TerrainGeneratorCfg(
    # Fixed so every run and every worker builds the same terrain.
    seed=0,
    size=(8.0, 8.0),
    num_rows=6,
    num_cols=6,
    curriculum=True,
    border_width=4.0,
    horizontal_scale=0.1,
    vertical_scale=0.005,
    sub_terrains={
        "flat": flat(proportion=0.2),
        "random_rough": random_rough(proportion=0.2),
        "pyramid_stairs": pyramid_stairs(proportion=0.15),
        "pyramid_stairs_inv": pyramid_stairs_inv(proportion=0.15),
        "hf_pyramid_slope": hf_pyramid_slope(proportion=0.15),
        "wave_terrain": wave_terrain(proportion=0.15),
    },
)
"""Mixed rough terrain: flat, noise, stairs both ways, slopes and waves."""

ALL_TERRAINS_CFG = TerrainGeneratorCfg(
    # Fixed so every run and every worker builds the same terrain.
    seed=0,
    size=(8.0, 8.0),
    num_rows=5,
    num_cols=len(ALL_TERRAIN_PRESETS),
    curriculum=True,
    border_width=4.0,
    horizontal_scale=0.1,
    vertical_scale=0.005,
    sub_terrains={name: fn(proportion=1.0) for name, fn in ALL_TERRAIN_PRESETS.items()},
)
"""Every registered preset, one column each. Useful for eyeballing the whole
catalogue in ``scripts/visualize_terrain.py``."""
