# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
#
# The sub-terrain parameter sets and their difficulty interpolation follow
# Isaac Lab's `isaaclab.terrains.height_field`. The geometry itself comes from
# the Isaac Gym terrain primitives that Genesis vendors at
# `genesis.ext.isaacgym.terrain_utils`.
"""Heightfield sub-terrains.

Every sub-terrain maps ``difficulty`` in ``[0, 1]`` onto its own parameters and
returns a raw heightfield patch. Class and field names follow Isaac Lab's
``height_field`` sub-package so configs read the same across frameworks.

The Isaac Gym primitives draw from the global ``numpy.random`` state. To keep
generation reproducible from ``TerrainGeneratorCfg.seed`` alone, each patch
seeds that state from the generator's own RNG for the duration of the call (see
``_isaacgym_rng``).
"""

from __future__ import annotations

import contextlib
from dataclasses import dataclass

import numpy as np

from gslab.terrains.terrain_generator import BoxSpec, SubTerrainCfg, TerrainOutput
from gslab.terrains.utils import cells_per_patch, lerp, make_sub_terrain


@contextlib.contextmanager
def _isaacgym_rng(rng: np.random.Generator):
    """Drive ``numpy.random`` from ``rng`` for the duration of the block.

    The Isaac Gym terrain helpers call ``np.random`` directly, so this is what
    makes a generator seed reproduce the same terrain.
    """
    state = np.random.get_state()
    np.random.seed(int(rng.integers(0, 2**31 - 1)))
    try:
        yield
    finally:
        np.random.set_state(state)


@dataclass
class HfTerrainBaseCfg(SubTerrainCfg):
    """Base config for heightfield sub-terrains."""

    border_width: float = 0.0
    """Width of a flat border kept at height zero around this patch, in meters.

  Keeps neighbouring patches from meeting at a wall of the full terrain height."""

    def _new_patch(self):
        """Allocate an Isaac Gym scratch ``SubTerrain`` sized for this patch."""
        return make_sub_terrain(
            cells_per_patch(self.size[0], self.horizontal_scale),
            cells_per_patch(self.size[1], self.horizontal_scale),
            self.horizontal_scale,
            self.vertical_scale,
        )

    def _finalize(self, height_field_raw: np.ndarray) -> TerrainOutput:
        """Apply ``border_width`` and wrap the patch as a ``TerrainOutput``."""
        border_cells = int(round(self.border_width / self.horizontal_scale))
        if border_cells > 0:
            height_field_raw = height_field_raw.copy()
            height_field_raw[:border_cells, :] = 0.0
            height_field_raw[-border_cells:, :] = 0.0
            height_field_raw[:, :border_cells] = 0.0
            height_field_raw[:, -border_cells:] = 0.0
        return TerrainOutput(height_field_raw=height_field_raw)


@dataclass
class HfFlatTerrainCfg(HfTerrainBaseCfg):
    """Flat ground. Difficulty has no effect."""

    def function(self, difficulty: float, rng: np.random.Generator) -> TerrainOutput:
        del difficulty, rng
        return self._finalize(self._new_patch().height_field_raw)


@dataclass
class HfPyramidStairsTerrainCfg(HfTerrainBaseCfg):
    """Stairs descending from the patch border to a platform at the centre.

    The spawn origin sits on the centre platform, so a robot starts at the
    bottom of the pyramid and climbs outwards in every direction. This is the
    terrain the RosCon stairs demo trains on.
    """

    step_height_range: tuple[float, float] = (0.05, 0.20)
    """Step height at difficulty 0 and 1, in meters."""
    step_width: float = 0.3
    """Depth of each step (tread), in meters."""
    platform_width: float = 2.0
    """Width of the flat platform at the centre, in meters."""
    inverted: bool = False
    """When True, the centre platform is the highest point instead of the
  lowest, so the robot walks down and back up."""

    def function(self, difficulty: float, rng: np.random.Generator) -> TerrainOutput:
        from genesis.ext.isaacgym import terrain_utils

        step_height = lerp(self.step_height_range, difficulty)
        patch = self._new_patch()
        with _isaacgym_rng(rng):
            terrain_utils.pyramid_stairs_terrain(
                patch,
                step_width=self.step_width,
                # Isaac Gym's sign convention: a negative step_height raises the
                # terrain away from the centre platform (a pit), positive builds
                # a hill with the platform on top.
                step_height=step_height if self.inverted else -step_height,
                platform_size=self.platform_width,
            )
        return self._finalize(patch.height_field_raw)


@dataclass
class HfInvertedPyramidStairsTerrainCfg(HfPyramidStairsTerrainCfg):
    """Pyramid stairs with the centre platform on top."""

    inverted: bool = True


@dataclass
class HfStairsTerrainCfg(HfTerrainBaseCfg):
    """A straight flight of stairs climbing along +x."""

    step_height_range: tuple[float, float] = (0.05, 0.20)
    """Step height at difficulty 0 and 1, in meters."""
    step_width: float = 0.3
    """Depth of each step (tread), in meters."""

    def function(self, difficulty: float, rng: np.random.Generator) -> TerrainOutput:
        from genesis.ext.isaacgym import terrain_utils

        step_height = lerp(self.step_height_range, difficulty)
        patch = self._new_patch()
        with _isaacgym_rng(rng):
            terrain_utils.stairs_terrain(
                patch, step_width=self.step_width, step_height=step_height
            )
        # A straight flight has no flat centre; spawn at the bottom of the run,
        # a quarter into the patch, so the robot has stairs ahead of it.
        raw = patch.height_field_raw
        rows, cols = raw.shape
        origin_row, origin_col = rows // 4, cols // 2
        output = self._finalize(raw)
        output.origin = np.array(
            [
                origin_row * self.horizontal_scale,
                origin_col * self.horizontal_scale,
                output.height_field_raw[origin_row, origin_col] * self.vertical_scale,
            ]
        )
        return output


@dataclass
class HfRandomUniformTerrainCfg(HfTerrainBaseCfg):
    """Uniform random noise — the classic "rough ground" terrain."""

    noise_range: tuple[float, float] = (0.02, 0.10)
    """Noise amplitude at difficulty 0 and 1, in meters."""
    noise_step: float = 0.02
    """Quantisation of the sampled heights, in meters."""
    downsampled_scale: float = 0.5
    """Resolution the noise is sampled at before being upsampled, in meters.
  Larger values give broader, smoother bumps."""

    def function(self, difficulty: float, rng: np.random.Generator) -> TerrainOutput:
        from genesis.ext.isaacgym import terrain_utils

        amplitude = lerp(self.noise_range, difficulty)
        patch = self._new_patch()
        with _isaacgym_rng(rng):
            terrain_utils.random_uniform_terrain(
                patch,
                min_height=-amplitude,
                max_height=amplitude,
                step=self.noise_step,
                downsampled_scale=self.downsampled_scale,
            )
        return self._finalize(patch.height_field_raw)


@dataclass
class HfPyramidSlopedTerrainCfg(HfTerrainBaseCfg):
    """A sloped pyramid with a flat platform at the centre."""

    slope_range: tuple[float, float] = (0.0, 0.4)
    """Slope (rise over run) at difficulty 0 and 1."""
    platform_width: float = 2.0
    """Width of the flat platform at the centre, in meters."""
    inverted: bool = False
    """When True, the centre platform is the highest point."""

    def function(self, difficulty: float, rng: np.random.Generator) -> TerrainOutput:
        from genesis.ext.isaacgym import terrain_utils

        slope = lerp(self.slope_range, difficulty)
        patch = self._new_patch()
        with _isaacgym_rng(rng):
            terrain_utils.pyramid_sloped_terrain(
                patch,
                slope=slope if self.inverted else -slope,
                platform_size=self.platform_width,
            )
        return self._finalize(patch.height_field_raw)


@dataclass
class HfInvertedPyramidSlopedTerrainCfg(HfPyramidSlopedTerrainCfg):
    """Sloped pyramid with the centre platform on top."""

    inverted: bool = True


@dataclass
class HfWaveTerrainCfg(HfTerrainBaseCfg):
    """Sinusoidal waves in both x and y."""

    amplitude_range: tuple[float, float] = (0.0, 0.2)
    """Wave amplitude at difficulty 0 and 1, in meters."""
    num_waves: int = 4
    """Number of wave periods across the patch."""

    def function(self, difficulty: float, rng: np.random.Generator) -> TerrainOutput:
        from genesis.ext.isaacgym import terrain_utils

        amplitude = lerp(self.amplitude_range, difficulty)
        patch = self._new_patch()
        with _isaacgym_rng(rng):
            terrain_utils.wave_terrain(
                patch, num_waves=self.num_waves, amplitude=amplitude
            )
        return self._finalize(patch.height_field_raw)


@dataclass
class HfDiscreteObstaclesTerrainCfg(HfTerrainBaseCfg):
    """Randomly placed rectangular boxes, with a clear platform at the centre."""

    obstacle_height_range: tuple[float, float] = (0.05, 0.30)
    """Maximum obstacle height at difficulty 0 and 1, in meters."""
    obstacle_width_range: tuple[float, float] = (0.3, 1.0)
    """Minimum and maximum obstacle footprint, in meters."""
    num_obstacles: int = 40
    """How many obstacles to place."""
    platform_width: float = 2.0
    """Width of the clear platform at the centre, in meters."""

    def function(self, difficulty: float, rng: np.random.Generator) -> TerrainOutput:
        from genesis.ext.isaacgym import terrain_utils

        max_height = lerp(self.obstacle_height_range, difficulty)
        patch = self._new_patch()
        with _isaacgym_rng(rng):
            terrain_utils.discrete_obstacles_terrain(
                patch,
                max_height=max_height,
                min_size=self.obstacle_width_range[0],
                max_size=self.obstacle_width_range[1],
                num_rects=self.num_obstacles,
                platform_size=self.platform_width,
            )
        return self._finalize(patch.height_field_raw)


@dataclass
class HfSteppingStonesTerrainCfg(HfTerrainBaseCfg):
    """Stepping stones separated by gaps, with a platform at the centre."""

    stone_distance_range: tuple[float, float] = (0.05, 0.30)
    """Gap between stones at difficulty 0 and 1, in meters."""
    stone_size: float = 0.8
    """Horizontal size of each stone, in meters."""
    stone_height_variation: float = 0.05
    """Height jitter applied to the stones, in meters."""
    platform_width: float = 2.0
    """Width of the solid platform at the centre, in meters."""
    holes_depth: float = 1.0
    """Depth of the gaps between stones, in meters."""

    def function(self, difficulty: float, rng: np.random.Generator) -> TerrainOutput:
        from genesis.ext.isaacgym import terrain_utils

        stone_distance = lerp(self.stone_distance_range, difficulty)
        patch = self._new_patch()
        with _isaacgym_rng(rng):
            terrain_utils.stepping_stones_terrain(
                patch,
                stone_size=self.stone_size,
                stone_distance=stone_distance,
                max_height=self.stone_height_variation,
                platform_size=self.platform_width,
                depth=-abs(self.holes_depth),
            )
        return self._finalize(patch.height_field_raw)


@dataclass
class BoxStairsTerrainCfg(HfTerrainBaseCfg):
    """A straight flight of stairs with true vertical risers.

    Every other sub-terrain here is a heightfield, and a heightfield cannot
    represent a vertical face: neighbouring cells at different heights meet as a
    ramp one cell wide, so at 10 cm resolution a 16 cm step renders as a
    58-degree slope. That is fine for rough ground and pyramids-as-obstacles,
    but it is not a staircase, and a policy trained only on it never meets a
    real riser.

    This emits solid boxes instead — Genesis treats them as analytic
    primitives, so a flight costs a handful of entities and no mesh. The patch
    is: a flat run-up, ``num_steps`` steps climbing along +x, then a landing
    that fills the remainder.

    The robot spawns on the run-up facing the stairs, so a forward velocity
    command walks it into them.
    """

    step_height_range: tuple[float, float] = (0.08, 0.18)
    """Riser height at difficulty 0 and 1, in meters. Building-code stairs are
  around 0.17-0.19 m, so difficulty 1 is roughly a domestic staircase."""
    step_width: float = 0.30
    """Tread depth, in meters. Building-code stairs are around 0.25-0.30 m."""
    num_steps: int = 8
    """Number of risers before the landing."""
    approach_length: float = 2.5
    """Flat run-up before the first riser, in meters. The spawn point sits in
  the middle of it."""
    overlap: float = 0.02
    """How far each step reaches back into the one below, in meters.

  Butt-jointing the steps makes their side faces exactly coincident, which
  gives the contact solver degenerate normals: training NaN'd out
  reproducibly (`Invalid constraint forces causing 'nan'`) a few hundred
  iterations in. A small interpenetration removes the shared plane. Only the
  hidden faces move, so the exposed staircase is unchanged."""
    embed_depth: float = 0.05
    """How far the steps sink below ground level, in meters. Same reason: a box
  resting exactly on the terrain mesh shares a face with it."""

    def function(self, difficulty: float, rng: np.random.Generator) -> TerrainOutput:
        del rng
        step_height = lerp(self.step_height_range, difficulty)
        size_x, size_y = self.size

        def solid(start_x: float, length: float, top: float) -> BoxSpec:
            """A step or landing, reaching back and down to avoid shared faces."""
            back = start_x - self.overlap
            span = length + self.overlap
            height = top + self.embed_depth
            return BoxSpec(
                # Boxes run from below ground up to their tread, so every riser
                # is a real vertical face rather than a lip.
                pos=(back + span / 2, size_y / 2, top - height / 2),
                size=(span, size_y, height),
            )

        boxes: list[BoxSpec] = []
        for index in range(self.num_steps):
            start_x = self.approach_length + index * self.step_width
            if start_x + self.step_width > size_x:
                break
            boxes.append(solid(start_x, self.step_width, (index + 1) * step_height))

        # Landing: fill whatever is left of the patch at the top height.
        if boxes:
            top = len(boxes) * step_height
            landing_start = self.approach_length + len(boxes) * self.step_width
            landing_length = size_x - landing_start
            if landing_length > 0:
                boxes.append(solid(landing_start, landing_length, top))

        output = self._finalize(self._new_patch().height_field_raw)
        output.boxes = boxes
        output.origin = np.array([self.approach_length / 2, size_y / 2, 0.0])
        return output
