# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
"""Procedural terrain grid generation.

The config surface mirrors mjlab's ``terrains.terrain_generator`` (which in turn
follows Isaac Lab's ``terrains``), so a ``TerrainGeneratorCfg`` written for
either framework transfers with little more than renamed sub-terrain classes.
The backend differs: mjlab emits MuJoCo geoms and heightfields per sub-terrain,
whereas gslab tiles sub-terrain heightfields into one array and hands it to
``gs.morphs.Terrain``, which Genesis turns into a single collision mesh.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field

import genesis as gs
import numpy as np

from gslab.terrains.utils import (
    add_border,
    cells_per_patch,
    grid_shape,
    paste_patch,
    patch_center_indices,
)


@dataclass
class BoxSpec:
    """One axis-aligned box of solid terrain, in patch-local meters."""

    pos: tuple[float, float, float]
    """Centre of the box, measured from the patch's minimum corner."""
    size: tuple[float, float, float]
    """Full extent of the box along x, y, z."""


@dataclass
class TerrainOutput:
    """What a sub-terrain hands back to the generator."""

    height_field_raw: np.ndarray
    """Patch heightfield, shape ``(patch_rows, patch_cols)``, in raw units of
  ``vertical_scale``."""
    boxes: list[BoxSpec] | None = None
    """Solid boxes to place on top of the heightfield, or None.

  A heightfield cannot represent a vertical face: neighbouring cells at
  different heights meet as a ramp one cell wide, so a 16 cm step at 10 cm
  resolution renders as a 58-degree slope rather than a stair. Sub-terrains
  that need true vertical risers emit boxes instead, which Genesis treats as
  analytic primitives."""
    origin: np.ndarray | None = None
    """Spawn origin ``(x, y, z)`` in patch-local meters, measured from the
  patch's minimum corner. ``None`` (the default) lets the generator use the
  centre of the patch at its own height, which is what every heightfield
  sub-terrain here wants: they all place a flat platform at the centre."""


@dataclass
class SubTerrainCfg(abc.ABC):
    """Base configuration for one sub-terrain patch."""

    proportion: float = 1.0
    """Robot spawning weight for this terrain type.

  In curriculum mode, controls how many robots spawn on this terrain's column
  relative to other terrain types; each type always gets exactly one column.
  In random mode, controls the sampling probability for each patch."""
    size: tuple[float, float] = (8.0, 8.0)
    """Width and length of the terrain patch, in meters. Overwritten by
  ``TerrainGeneratorCfg.size``."""
    horizontal_scale: float = 0.1
    """Heightfield cell size, in meters. Overwritten by
  ``TerrainGeneratorCfg.horizontal_scale`` so patches tile exactly."""
    vertical_scale: float = 0.005
    """Heightfield height quantum, in meters. Overwritten by
  ``TerrainGeneratorCfg.vertical_scale``."""

    @abc.abstractmethod
    def function(self, difficulty: float, rng: np.random.Generator) -> TerrainOutput:
        """Generate this patch's heightfield at the given difficulty."""
        raise NotImplementedError


@dataclass(kw_only=True)
class TerrainGeneratorCfg:
    """Configuration for a procedural terrain grid."""

    size: tuple[float, float] = (8.0, 8.0)
    """Width and length of each sub-terrain patch, in meters."""
    num_rows: int = 1
    """Number of sub-terrain rows (along +x). Difficulty levels in curriculum
  mode. Environments are randomly assigned to rows, so several can share a
  patch."""
    num_cols: int = 1
    """Number of sub-terrain columns (along +y).

  In curriculum mode this value is ignored and one column per terrain type is
  used (``len(sub_terrains)``). In random mode it is used as-is."""
    sub_terrains: dict[str, SubTerrainCfg] = field(default_factory=dict)
    """Named sub-terrain configurations to populate the grid."""
    curriculum: bool = False
    """Controls terrain allocation mode:

  - ``True``: each terrain type gets exactly ONE column, and difficulty rises
    along rows. ``proportion`` then controls how many robots spawn per column,
    not the column count.
  - ``False``: every patch samples a terrain type weighted by ``proportion``,
    at a random difficulty. Use this for variety without a difficulty axis."""
    difficulty_range: tuple[float, float] = (0.0, 1.0)
    """Min and max difficulty used when generating sub-terrains."""
    border_width: float = 0.0
    """Width of the flat border padded around the whole grid, in meters."""
    border_height: float = 0.0
    """Height of that flat border, in meters.

  Note this differs from mjlab, where ``border_height`` is the thickness of a
  ring of wall boxes. gslab's border is flat ground at this height (see
  ``terrains.utils.add_border``)."""
    horizontal_scale: float = 0.1
    """Heightfield cell size, in meters. Drives both terrain fidelity and mesh
  size: halving it quadruples the vertex count and the scene build time."""
    vertical_scale: float = 0.005
    """Heightfield height quantum, in meters."""
    seed: int | None = None
    """Random seed for terrain generation. ``None`` draws one at random."""


class TerrainGenerator:
    """Tile sub-terrain heightfields into one grid.

    Creates a ``num_rows x num_cols`` grid of patches, each generated by a
    :class:`SubTerrainCfg` at some difficulty, and records the spawn origin of
    every patch in ``terrain_origins``. Supports the same two modes as mjlab:

    - **Random mode** (``curriculum=False``): every patch independently samples
      a terrain type weighted by proportions, at a random difficulty.
    - **Curriculum mode** (``curriculum=True``): each terrain type gets one
      column and difficulty rises along rows.

    The grid is centred on the world origin. ``height_field`` and
    ``origin_offset`` together are what the terrain entity needs to place the
    Genesis morph; ``terrain_origins`` are already in world coordinates.
    """

    def __init__(self, cfg: TerrainGeneratorCfg) -> None:
        if len(cfg.sub_terrains) == 0:
            raise ValueError("At least one sub_terrain must be specified.")

        self.cfg = cfg

        # In curriculum mode, one column per terrain type.
        if cfg.curriculum:
            self._num_cols = len(cfg.sub_terrains)
        else:
            self._num_cols = cfg.num_cols
        if self._num_cols < 1 or cfg.num_rows < 1:
            raise ValueError(
                f"Terrain grid must be at least 1x1, got "
                f"{cfg.num_rows}x{self._num_cols}."
            )

        # The grid is one array, so every patch must share the same cell size
        # and height quantum. Propagate the generator's values, matching how
        # mjlab overwrites each sub-terrain's `size`.
        for sub_cfg in cfg.sub_terrains.values():
            sub_cfg.size = cfg.size
            sub_cfg.horizontal_scale = cfg.horizontal_scale
            sub_cfg.vertical_scale = cfg.vertical_scale

        seed = cfg.seed if cfg.seed is not None else np.random.randint(0, 10000)
        self.np_rng = np.random.default_rng(seed)

        self._patch_rows = cells_per_patch(cfg.size[0], cfg.horizontal_scale)
        self._patch_cols = cells_per_patch(cfg.size[1], cfg.horizontal_scale)
        self._border_cells = int(round(cfg.border_width / cfg.horizontal_scale))

        self.terrain_origins = np.zeros((cfg.num_rows, self._num_cols, 3))
        self.difficulties = np.zeros((cfg.num_rows, self._num_cols))
        self.boxes: list[BoxSpec] = []
        self.height_field = self._generate()

    @property
    def num_rows(self) -> int:
        return self.cfg.num_rows

    @property
    def num_cols(self) -> int:
        """Number of columns actually generated (``len(sub_terrains)`` in
        curriculum mode)."""
        return self._num_cols

    @property
    def proportions(self) -> np.ndarray:
        """Normalized per-column spawning weights."""
        weights = np.array(
            [sub.proportion for sub in self.cfg.sub_terrains.values()], dtype=float
        )
        total = weights.sum()
        if total <= 0.0:
            raise ValueError("Sub-terrain proportions must sum to a positive value.")
        return weights / total

    @property
    def size(self) -> tuple[float, float]:
        """Extent of the generated heightfield, borders included, in meters."""
        rows, cols = self.height_field.shape
        return (
            (rows - 1) * self.cfg.horizontal_scale,
            (cols - 1) * self.cfg.horizontal_scale,
        )

    @property
    def origin_offset(self) -> tuple[float, float, float]:
        """Position of the heightfield's minimum corner, centring it on the
        world origin.

        ``gs.morphs.Terrain`` anchors ``height_field[0, 0]`` at ``pos`` and grows
        along +x/+y, so this is what belongs in the morph's ``pos``.
        """
        size_x, size_y = self.size
        return (-0.5 * size_x, -0.5 * size_y, 0.0)

    def _generate(self) -> np.ndarray:
        shape = grid_shape(
            self.cfg.num_rows, self._num_cols, self._patch_rows, self._patch_cols
        )
        # Filled with -inf, not zeros: patches meet at shared cells resolved by
        # `np.maximum`, and a zero-initialised grid would clamp away everything
        # below ground level (stairs down, pits, stepping-stone gaps).
        grid = np.full(shape, -np.inf, dtype=np.float32)

        if self.cfg.curriculum:
            self._generate_curriculum_terrains(grid)
        else:
            self._generate_random_terrains(grid)

        if not np.isfinite(grid).all():
            raise RuntimeError(
                "Terrain grid has cells no sub-terrain wrote to; this is a bug "
                "in the patch tiling."
            )

        border_raw = self.cfg.border_height / self.cfg.vertical_scale
        grid = add_border(grid, self._border_cells, border_raw)

        # `origin_offset` is derived from the final array shape, so publish the
        # heightfield before resolving patch origins into world coordinates.
        self.height_field = grid
        self._resolve_world_origins()
        # Boxes are separate collision primitives, so the mesh heightfield stays
        # flat underneath them. Queries must still see them, or a height scan
        # would report open floor where a staircase stands.
        self.query_field = self._rasterize_boxes(grid)

        gs.logger.info(
            f"Generated terrain: {self.cfg.num_rows}x{self._num_cols} patches of "
            f"{self.cfg.size[0]}x{self.cfg.size[1]} m, heightfield "
            f"{grid.shape[0]}x{grid.shape[1]} cells "
            f"({grid.shape[0] * grid.shape[1] / 1000:.0f}k vertices)."
        )
        return grid

    def _generate_random_terrains(self, grid: np.ndarray) -> None:
        proportions = self.proportions
        sub_terrain_cfgs = list(self.cfg.sub_terrains.values())

        for row in range(self.cfg.num_rows):
            for col in range(self._num_cols):
                index = self.np_rng.choice(len(proportions), p=proportions)
                difficulty = self.np_rng.uniform(*self.cfg.difficulty_range)
                self._create_patch(grid, row, col, sub_terrain_cfgs[index], difficulty)

    def _generate_curriculum_terrains(self, grid: np.ndarray) -> None:
        sub_terrain_cfgs = list(self.cfg.sub_terrains.values())
        lower, upper = self.cfg.difficulty_range

        for col in range(self._num_cols):
            for row in range(self.cfg.num_rows):
                fraction = row / max(self.cfg.num_rows - 1, 1)
                difficulty = lower + (upper - lower) * fraction
                self._create_patch(grid, row, col, sub_terrain_cfgs[col], difficulty)

    def _create_patch(
        self,
        grid: np.ndarray,
        row: int,
        col: int,
        sub_cfg: SubTerrainCfg,
        difficulty: float,
    ) -> None:
        output = sub_cfg.function(difficulty, self.np_rng)
        patch = np.asarray(output.height_field_raw, dtype=np.float32)
        if patch.shape != (self._patch_rows, self._patch_cols):
            raise ValueError(
                f"Sub-terrain {type(sub_cfg).__name__} returned a heightfield of "
                f"shape {patch.shape}, expected "
                f"{(self._patch_rows, self._patch_cols)}."
            )
        paste_patch(grid, patch, row, col)
        self.difficulties[row, col] = difficulty

        if output.boxes:
            # Patch-local -> grid-local; the border shift happens later, with
            # the origins, once the padded array size is known.
            patch_x = row * (self._patch_rows - 1) * self.cfg.horizontal_scale
            patch_y = col * (self._patch_cols - 1) * self.cfg.horizontal_scale
            for box in output.boxes:
                self.boxes.append(
                    BoxSpec(
                        pos=(
                            box.pos[0] + patch_x,
                            box.pos[1] + patch_y,
                            box.pos[2],
                        ),
                        size=box.size,
                    )
                )

        if output.origin is not None:
            origin = np.asarray(output.origin, dtype=float)
        else:
            center_row, center_col = patch_center_indices(
                self._patch_rows, self._patch_cols
            )
            origin = np.array(
                [
                    center_row * self.cfg.horizontal_scale,
                    center_col * self.cfg.horizontal_scale,
                    patch[center_row, center_col] * self.cfg.vertical_scale,
                ]
            )
        # Patch-local for now; _resolve_world_origins shifts these once the
        # border padding and centring offset are known.
        self.terrain_origins[row, col] = origin

    def _resolve_world_origins(self) -> None:
        offset_x, offset_y, _ = self.origin_offset
        border = self._border_cells * self.cfg.horizontal_scale
        patch_x = (self._patch_rows - 1) * self.cfg.horizontal_scale
        patch_y = (self._patch_cols - 1) * self.cfg.horizontal_scale

        for row in range(self.cfg.num_rows):
            for col in range(self._num_cols):
                self.terrain_origins[row, col, 0] += offset_x + border + row * patch_x
                self.terrain_origins[row, col, 1] += offset_y + border + col * patch_y

        shift_x, shift_y = offset_x + border, offset_y + border
        self.boxes = [
            BoxSpec(
                pos=(box.pos[0] + shift_x, box.pos[1] + shift_y, box.pos[2]),
                size=box.size,
            )
            for box in self.boxes
        ]

    def _rasterize_boxes(self, grid: np.ndarray) -> np.ndarray:
        """Grid with box tops stamped in, for height queries.

        Returns ``grid`` itself when there are no boxes, so the common case
        costs nothing and the two views stay the same object.
        """
        if not self.boxes:
            return grid
        query = grid.copy()
        offset_x, offset_y, _ = self.origin_offset
        scale = self.cfg.horizontal_scale
        rows, cols = query.shape
        for box in self.boxes:
            top_raw = (box.pos[2] + box.size[2] / 2.0) / self.cfg.vertical_scale
            lo_r = int(np.floor((box.pos[0] - box.size[0] / 2 - offset_x) / scale))
            hi_r = int(np.ceil((box.pos[0] + box.size[0] / 2 - offset_x) / scale))
            lo_c = int(np.floor((box.pos[1] - box.size[1] / 2 - offset_y) / scale))
            hi_c = int(np.ceil((box.pos[1] + box.size[1] / 2 - offset_y) / scale))
            rs = slice(max(lo_r, 0), min(hi_r + 1, rows))
            cs = slice(max(lo_c, 0), min(hi_c + 1, cols))
            np.maximum(query[rs, cs], top_raw, out=query[rs, cs])
        return query

    def height_at(self, positions: np.ndarray) -> np.ndarray:
        """Nearest-cell terrain height, in meters, at world ``(x, y)`` points.

        Args:
          positions: ``(N, 2)`` or ``(N, 3)`` array of world coordinates; only
            the first two columns are read.

        Returns:
          ``(N,)`` array of heights. Points outside the heightfield are clamped
          to the nearest edge cell.
        """
        positions = np.atleast_2d(np.asarray(positions, dtype=float))
        offset_x, offset_y, _ = self.origin_offset
        # query_field, not height_field: box staircases sit on top of a flat
        # patch, so the mesh field reports open floor where they stand.
        field = self.query_field
        rows, cols = field.shape
        row_idx = np.clip(
            np.rint((positions[:, 0] - offset_x) / self.cfg.horizontal_scale).astype(
                int
            ),
            0,
            rows - 1,
        )
        col_idx = np.clip(
            np.rint((positions[:, 1] - offset_y) / self.cfg.horizontal_scale).astype(
                int
            ),
            0,
            cols - 1,
        )
        return field[row_idx, col_idx] * self.cfg.vertical_scale
