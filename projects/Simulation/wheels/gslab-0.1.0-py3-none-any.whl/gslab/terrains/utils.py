# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Heightfield helpers shared by the terrain generator and sub-terrains.

Heightfields follow the Genesis / Isaac Gym convention: a 2D array indexed
``[x, y]`` holding *raw* heights in integer multiples of ``vertical_scale``,
with cells spaced ``horizontal_scale`` apart. Adjacent sub-terrains share their
boundary row/column, so a grid of ``n`` patches of ``k`` cells each is
``n * (k - 1) + 1`` cells wide.
"""

from __future__ import annotations

import numpy as np


def cells_per_patch(size: float, horizontal_scale: float) -> int:
    """Number of heightfield cells spanning ``size`` meters, endpoints included."""
    if size <= 0.0:
        raise ValueError(f"Sub-terrain size must be positive, got {size}.")
    cells = int(round(size / horizontal_scale)) + 1
    if cells < 2:
        raise ValueError(
            f"Sub-terrain size {size} m is smaller than one cell of "
            f"{horizontal_scale} m; increase the size or the resolution."
        )
    return cells


def grid_shape(
    num_rows: int, num_cols: int, patch_rows: int, patch_cols: int
) -> tuple[int, int]:
    """Shape of a ``num_rows x num_cols`` grid of patches with shared borders."""
    return (
        num_rows * (patch_rows - 1) + 1,
        num_cols * (patch_cols - 1) + 1,
    )


def paste_patch(
    grid: np.ndarray,
    patch: np.ndarray,
    row: int,
    col: int,
) -> None:
    """Write ``patch`` into the ``(row, col)`` slot of a shared-border ``grid``.

    Shared boundary cells take the maximum of the two neighbours, so patches at
    different heights meet at a step rather than a discontinuity in the mesh.
    """
    patch_rows, patch_cols = patch.shape
    row_slice = slice(row * (patch_rows - 1), (row + 1) * (patch_rows - 1) + 1)
    col_slice = slice(col * (patch_cols - 1), (col + 1) * (patch_cols - 1) + 1)
    target = grid[row_slice, col_slice]
    target[:] = np.maximum(target, patch)


def add_border(
    grid: np.ndarray,
    border_cells: int,
    border_raw_height: float,
) -> np.ndarray:
    """Pad ``grid`` with a flat border of ``border_cells`` cells.

    gslab's border is flat ground at ``border_raw_height`` rather than mjlab's
    ring of wall boxes: with a single heightfield mesh there is nothing outside
    the grid to stand on, and flat padding gives a robot that walks off the edge
    somewhere to land instead of falling out of the world.
    """
    if border_cells <= 0:
        return grid
    return np.pad(
        grid,
        pad_width=border_cells,
        mode="constant",
        constant_values=border_raw_height,
    )


def patch_center_indices(patch_rows: int, patch_cols: int) -> tuple[int, int]:
    """Indices of the centre cell of a patch."""
    return patch_rows // 2, patch_cols // 2


def make_sub_terrain(
    patch_rows: int,
    patch_cols: int,
    horizontal_scale: float,
    vertical_scale: float,
):
    """Build an Isaac Gym ``SubTerrain`` scratch buffer of the given size.

    Genesis vendors the Isaac Gym terrain primitives, so sub-terrains can hand
    this buffer straight to ``pyramid_stairs_terrain`` and friends.

    Requires ``gs.init()`` to have run: the vendored helpers allocate with
    ``gs.np_float``, which only exists once the backend is chosen.
    """
    import genesis as gs
    from genesis.ext.isaacgym import terrain_utils

    if not hasattr(gs, "np_float"):
        raise RuntimeError(
            "Terrain generation requires Genesis to be initialized first; "
            "call gs.init(...) before building the terrain."
        )

    return terrain_utils.SubTerrain(
        width=patch_rows,
        length=patch_cols,
        horizontal_scale=horizontal_scale,
        vertical_scale=vertical_scale,
    )


def lerp(value_range: tuple[float, float], difficulty: float) -> float:
    """Interpolate ``value_range`` at ``difficulty`` in ``[0, 1]``."""
    low, high = value_range
    return low + (high - low) * float(np.clip(difficulty, 0.0, 1.0))
