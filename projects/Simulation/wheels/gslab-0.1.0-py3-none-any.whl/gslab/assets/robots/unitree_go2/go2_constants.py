# Robot model derived from MuJoCo Menagerie (unitree_go2), BSD-3-Clause.
# See docs/license/mujoco_menagerie-go2-license.
"""Unitree Go2 quadruped constants.

Mirrors the structure of ``unitree_g1/g1_constants.py`` so both robots plug into
the same manager-based velocity task.
"""

from pathlib import Path

from gslab import SRC_PATH
from gslab.actuator import BuiltinPositionActuatorCfg
from gslab.entity import EntityArticulationInfoCfg, EntityCfg

##
# MJCF and assets.
##

GO2_XML: Path = SRC_PATH / "assets" / "robots" / "unitree_go2" / "xmls" / "go2.xml"
assert GO2_XML.exists()


##
# Actuator config.
##

# PD gains and effort limits for the Unitree Go2 joint actuators.
#
# Gains are derived the same way as the G1 (see g1_constants.py): treat each
# joint as a second-order system tuned to a target natural frequency, so
# ``Kp = armature * wn**2`` and ``Kd = 2 * zeta * armature * wn``. The Go2 MJCF
# specifies a reflected joint inertia (armature) of 0.01 kg*m^2, and we reuse the
# G1's 10 Hz / zeta=2.0 tuning. This yields ~Kp=40, ~Kd=2.5, which comfortably
# supports the standing pose (a flat Kp=20 sags the stance noticeably).
#
# Effort limits are the per-joint motor torque limits from the Menagerie MJCF:
# 23.7 Nm for the hip/thigh joints and 45.43 Nm for the knee (calf) joint, which
# is geared for higher torque.
ARMATURE = 0.01
NATURAL_FREQ = 10 * 2.0 * 3.1415926535  # 10 Hz
DAMPING_RATIO = 2.0

STIFFNESS = ARMATURE * NATURAL_FREQ**2
DAMPING = 2.0 * DAMPING_RATIO * ARMATURE * NATURAL_FREQ

EFFORT_LIMIT_HIP = 23.7
EFFORT_LIMIT_KNEE = 45.43

# Hip abduction + thigh (front/back) joints.
GO2_ACTUATOR_HIP = BuiltinPositionActuatorCfg(
    target_names_expr=(".*_hip_joint", ".*_thigh_joint"),
    stiffness=STIFFNESS,
    damping=DAMPING,
    effort_limit=EFFORT_LIMIT_HIP,
)
# Knee (calf) joints.
GO2_ACTUATOR_KNEE = BuiltinPositionActuatorCfg(
    target_names_expr=(".*_calf_joint",),
    stiffness=STIFFNESS,
    damping=DAMPING,
    effort_limit=EFFORT_LIMIT_KNEE,
)

##
# Keyframe config.
##

# Nominal standing pose. The base spawn height is set in the MJCF (0.30 m); the
# per-joint targets are the Go2 "home" crouch (hips level, thighs forward, knees
# folded) shared by the Menagerie keyframe and the Unitree SDK defaults.
HOME_KEYFRAME = EntityCfg.InitialStateCfg(
    pos=(0.0, 0.0, 0.0),
    joint_pos={
        ".*_hip_joint": 0.0,
        ".*_thigh_joint": 0.9,
        ".*_calf_joint": -1.8,
    },
)

##
# Final config.
##

GO2_ARTICULATION = EntityArticulationInfoCfg(
    actuators=(
        GO2_ACTUATOR_HIP,
        GO2_ACTUATOR_KNEE,
    ),
)


def get_go2_robot_cfg() -> EntityCfg:
    """Get a fresh Go2 robot configuration instance.

    Returns a new EntityCfg instance each time to avoid mutation issues when the
    config is shared across multiple places.
    """
    return EntityCfg(
        init_state=HOME_KEYFRAME,
        articulation=GO2_ARTICULATION,
    )


# Position action scale (radians of target offset per unit action), applied to
# every actuated joint. 0.25 is the standard Go2 locomotion action scale.
GO2_ACTION_SCALE: dict[str, float] = {".*": 0.25}
