# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from .unitree_g1.g1_constants import (
    G1_ACTION_SCALE as G1_ACTION_SCALE,
)
from .unitree_g1.g1_constants import (
    get_g1_robot_cfg as get_g1_robot_cfg,
)
from .unitree_go2.go2_constants import (
    GO2_ACTION_SCALE as GO2_ACTION_SCALE,
)
from .unitree_go2.go2_constants import (
    get_go2_robot_cfg as get_go2_robot_cfg,
)
