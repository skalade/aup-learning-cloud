# Unitree G1 model

The MJCF model (`g1.xml`, `scene_g1.xml`) and STL meshes in this directory
were taken from
[unitreerobotics/unitree_rl_mjlab](https://github.com/unitreerobotics/unitree_rl_mjlab)
(Apache-2.0) and originate from Unitree Robotics' G1 robot description
(`g1_29dof_rev_1_0`), which is licensed under the BSD 3-Clause License:

Copyright (c) 2016-2022 HangZhou YuShu TECHNOLOGY CO.,LTD. ("Unitree Robotics")

See `docs/license/unitree_g1-license` for the full license text.
