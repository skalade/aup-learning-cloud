# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from unitree_rl_mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2024 The Isaac Lab Project Developers.
# See docs/license/unitree_rl_mjlab-license.
"""Unitree G1 constants."""

from pathlib import Path

from gslab import SRC_PATH
from gslab.actuator import BuiltinPositionActuatorCfg
from gslab.entity import EntityArticulationInfoCfg, EntityCfg
from gslab.rl.utils.actuator import (
    ElectricActuator,
    reflected_inertia_from_two_stage_planetary,
)

##
# MJCF and assets.
##

G1_XML: Path = SRC_PATH / "assets" / "robots" / "unitree_g1" / "xmls" / "g1.xml"
assert G1_XML.exists()


##
# Actuator config.
##

# Motor specs (from Unitree).
ROTOR_INERTIAS_5020 = (
    0.139e-4,
    0.017e-4,
    0.169e-4,
)
GEARS_5020 = (
    1,
    1 + (46 / 18),
    1 + (56 / 16),
)
ARMATURE_5020 = reflected_inertia_from_two_stage_planetary(
    ROTOR_INERTIAS_5020, GEARS_5020
)

ROTOR_INERTIAS_7520_14 = (
    0.489e-4,
    0.098e-4,
    0.533e-4,
)
GEARS_7520_14 = (
    1,
    4.5,
    1 + (48 / 22),
)
ARMATURE_7520_14 = reflected_inertia_from_two_stage_planetary(
    ROTOR_INERTIAS_7520_14, GEARS_7520_14
)

ROTOR_INERTIAS_7520_22 = (
    0.489e-4,
    0.109e-4,
    0.738e-4,
)
GEARS_7520_22 = (
    1,
    4.5,
    5,
)
ARMATURE_7520_22 = reflected_inertia_from_two_stage_planetary(
    ROTOR_INERTIAS_7520_22, GEARS_7520_22
)

ROTOR_INERTIAS_4010 = (
    0.068e-4,
    0.0,
    0.0,
)
GEARS_4010 = (
    1,
    5,
    5,
)
ARMATURE_4010 = reflected_inertia_from_two_stage_planetary(
    ROTOR_INERTIAS_4010, GEARS_4010
)

ACTUATOR_5020 = ElectricActuator(
    reflected_inertia=ARMATURE_5020,
    velocity_limit=37.0,
    effort_limit=25.0,
)
ACTUATOR_7520_14 = ElectricActuator(
    reflected_inertia=ARMATURE_7520_14,
    velocity_limit=32.0,
    effort_limit=88.0,
)
ACTUATOR_7520_22 = ElectricActuator(
    reflected_inertia=ARMATURE_7520_22,
    velocity_limit=20.0,
    effort_limit=139.0,
)
ACTUATOR_4010 = ElectricActuator(
    reflected_inertia=ARMATURE_4010,
    velocity_limit=22.0,
    effort_limit=5.0,
)

NATURAL_FREQ = 10 * 2.0 * 3.1415926535  # 10Hz
DAMPING_RATIO = 2.0

STIFFNESS_5020 = ARMATURE_5020 * NATURAL_FREQ**2
STIFFNESS_7520_14 = ARMATURE_7520_14 * NATURAL_FREQ**2
STIFFNESS_7520_22 = ARMATURE_7520_22 * NATURAL_FREQ**2
STIFFNESS_4010 = ARMATURE_4010 * NATURAL_FREQ**2

DAMPING_5020 = 2.0 * DAMPING_RATIO * ARMATURE_5020 * NATURAL_FREQ
DAMPING_7520_14 = 2.0 * DAMPING_RATIO * ARMATURE_7520_14 * NATURAL_FREQ
DAMPING_7520_22 = 2.0 * DAMPING_RATIO * ARMATURE_7520_22 * NATURAL_FREQ
DAMPING_4010 = 2.0 * DAMPING_RATIO * ARMATURE_4010 * NATURAL_FREQ

G1_ACTUATOR_5020 = BuiltinPositionActuatorCfg(
    target_names_expr=(
        ".*_elbow_joint",
        ".*_shoulder_pitch_joint",
        ".*_shoulder_roll_joint",
        ".*_shoulder_yaw_joint",
        ".*_wrist_roll_joint",
    ),
    stiffness=STIFFNESS_5020,
    damping=DAMPING_5020,
    effort_limit=ACTUATOR_5020.effort_limit,
)
G1_ACTUATOR_7520_14 = BuiltinPositionActuatorCfg(
    target_names_expr=(".*_hip_pitch_joint", ".*_hip_yaw_joint", "waist_yaw_joint"),
    stiffness=STIFFNESS_7520_14,
    damping=DAMPING_7520_14,
    effort_limit=ACTUATOR_7520_14.effort_limit,
)
G1_ACTUATOR_7520_22 = BuiltinPositionActuatorCfg(
    target_names_expr=(".*_hip_roll_joint", ".*_knee_joint"),
    stiffness=STIFFNESS_7520_22,
    damping=DAMPING_7520_22,
    effort_limit=ACTUATOR_7520_22.effort_limit,
)
G1_ACTUATOR_4010 = BuiltinPositionActuatorCfg(
    target_names_expr=(".*_wrist_pitch_joint", ".*_wrist_yaw_joint"),
    stiffness=STIFFNESS_4010,
    damping=DAMPING_4010,
    effort_limit=ACTUATOR_4010.effort_limit,
)

# Waist pitch/roll and ankles are 4-bar linkages with 2 5020 actuators.
# Due to the parallel linkage, the effective inertia at the ankle and waist joints
# is configuration dependent. Since the exact geometry of the linkage is unknown, we
# assume a nominal 1:1 gear ratio. Under this assumption, the joint gains and effort
# limits in the nominal configuration are approximated as the sum of the 2 actuators'.
G1_ACTUATOR_WAIST = BuiltinPositionActuatorCfg(
    target_names_expr=("waist_pitch_joint", "waist_roll_joint"),
    stiffness=STIFFNESS_5020 * 2,
    damping=DAMPING_5020 * 2,
    effort_limit=ACTUATOR_5020.effort_limit * 2,
)
G1_ACTUATOR_ANKLE = BuiltinPositionActuatorCfg(
    target_names_expr=(".*_ankle_pitch_joint", ".*_ankle_roll_joint"),
    stiffness=STIFFNESS_5020 * 2,
    damping=DAMPING_5020 * 2,
    effort_limit=ACTUATOR_5020.effort_limit * 2,
)

##
# Keyframe config.
##

HOME_KEYFRAME = EntityCfg.InitialStateCfg(
    pos=(0, 0, 0.1),
    joint_pos={
        ".*_hip_pitch_joint": -0.1,
        ".*_knee_joint": 0.3,
        ".*_ankle_pitch_joint": -0.2,
        ".*_shoulder_pitch_joint": 0.35,
        ".*_elbow_joint": 0.87,
        "left_shoulder_roll_joint": 0.18,
        "right_shoulder_roll_joint": -0.18,
    },
)

# KNEES_BENT_KEYFRAME = EntityCfg.InitialStateCfg(
#     pos=(0, 0, 0.78),
#     joint_pos={
#         ".*_hip_pitch_joint": -0.312,
#         ".*_knee_joint": 0.669,
#         ".*_ankle_pitch_joint": -0.363,
#         ".*_elbow_joint": 0.6,
#         "left_shoulder_roll_joint": 0.2,
#         "left_shoulder_pitch_joint": 0.2,
#         "right_shoulder_roll_joint": -0.2,
#         "right_shoulder_pitch_joint": 0.2,
#     },
# )

##
# Collision config.
##

# This enables all collisions, including self collisions.
# Self-collisions are given condim=1 while foot collisions
# are given condim=3.
# FULL_COLLISION = CollisionCfg(
#     geom_names_expr=(".*_collision",),
#     condim={r"^(left|right)_foot[1-7]_collision$": 3, ".*_collision": 1},
#     priority={r"^(left|right)_foot[1-7]_collision$": 1},
#     friction={r"^(left|right)_foot[1-7]_collision$": (0.6,)},
# )

# FULL_COLLISION_WITHOUT_SELF = CollisionCfg(
#     geom_names_expr=(".*_collision",),
#     contype=0,
#     conaffinity=1,
#     condim={r"^(left|right)_foot[1-7]_collision$": 3, ".*_collision": 1},
#     priority={r"^(left|right)_foot[1-7]_collision$": 1},
#     friction={r"^(left|right)_foot[1-7]_collision$": (0.6,)},
# )

# This disables all collisions except the feet.
# Feet get condim=3, all other geoms are disabled.
# FEET_ONLY_COLLISION = CollisionCfg(
#     geom_names_expr=(r"^(left|right)_foot[1-7]_collision$",),
#     contype=0,
#     conaffinity=1,
#     condim=3,
#     priority=1,
#     friction=(0.6,),
# )

##
# Final config.
##

G1_ARTICULATION = EntityArticulationInfoCfg(
    actuators=(
        G1_ACTUATOR_5020,
        G1_ACTUATOR_7520_14,
        G1_ACTUATOR_7520_22,
        G1_ACTUATOR_4010,
        G1_ACTUATOR_WAIST,
        G1_ACTUATOR_ANKLE,
    ),
)


def get_g1_robot_cfg() -> EntityCfg:
    """Get a fresh G1 robot configuration instance.

    Returns a new EntityCfg instance each time to avoid mutation issues when
    the config is shared across multiple places.
    """
    return EntityCfg(
        init_state=HOME_KEYFRAME,
        articulation=G1_ARTICULATION,
    )


G1_ACTION_SCALE: dict[str, float] = {}
for a in G1_ARTICULATION.actuators:
    assert isinstance(a, BuiltinPositionActuatorCfg)
    e = a.effort_limit
    s = a.stiffness
    names = a.target_names_expr
    assert e is not None
    for n in names:
        G1_ACTION_SCALE[n] = 0.25 * e / s
