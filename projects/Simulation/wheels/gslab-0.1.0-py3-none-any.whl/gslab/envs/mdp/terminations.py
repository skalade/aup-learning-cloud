# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

import math

import torch

from .observations import projected_gravity


def time_out(env, **_kwargs) -> torch.Tensor:
    if env.max_episode_length > 0:
        return env.episode_length_buf >= env.max_episode_length
    return torch.zeros(env.num_envs, device=env.device, dtype=torch.bool)


def fell_over(env, limit_angle: float = math.radians(70.0), **_kwargs) -> torch.Tensor:
    projected_gravity_vec = projected_gravity(env)
    return projected_gravity_vec[:, 2] > -math.cos(limit_angle)
