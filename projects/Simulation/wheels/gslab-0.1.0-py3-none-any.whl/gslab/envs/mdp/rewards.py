# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

import torch

from gslab.entity import resolve_site_names

from .observations import (
    base_ang_vel,
    base_lin_vel,
    foot_contact_forces,
    projected_gravity,
)


def _command_active(
    env, command_name: str | None, command_threshold: float
) -> torch.Tensor | None:
    """Mask of environments whose velocity command exceeds the threshold.

    ``None`` when no command term was requested, so callers can skip gating.
    Foot-shaping terms use this so a robot asked to stand still is not punished
    for keeping both feet planted.
    """
    if command_name is None:
        return None
    command = env.command_manager.get_command(command_name)
    if command is None:
        return None
    magnitude = torch.norm(command[:, :2], dim=1) + torch.abs(command[:, 2])
    return (magnitude > command_threshold).float()


def track_linear_velocity(
    env, command_name: str = "twist", std: float = 0.5, **_kwargs
) -> torch.Tensor:
    command = env.command_manager.get_command(command_name)
    lin_vel_b = base_lin_vel(env)
    error = torch.sum(torch.square(command[:, :2] - lin_vel_b[:, :2]), dim=1)
    return torch.exp(-error / (std * std))


def track_angular_velocity(
    env, command_name: str = "twist", std: float = 0.707, **_kwargs
) -> torch.Tensor:
    command = env.command_manager.get_command(command_name)
    ang_vel_b = base_ang_vel(env)
    error = torch.square(command[:, 2] - ang_vel_b[:, 2])
    return torch.exp(-error / (std * std))


def body_orientation_l2(env, **_kwargs) -> torch.Tensor:
    projected_gravity_vec = projected_gravity(env)
    return torch.sum(torch.square(projected_gravity_vec[:, :2]), dim=1)


def variable_posture(env, **_kwargs) -> torch.Tensor:
    dof_pos_err = env.robot.get_dofs_position(env.actuated_dofs) - env._init_dof_pos
    return torch.exp(-torch.mean(torch.square(dof_pos_err / 0.25), dim=1))


def body_ang_velocity_penalty(env, **_kwargs) -> torch.Tensor:
    ang_vel_b = base_ang_vel(env)
    return torch.sum(torch.square(ang_vel_b[:, :2]), dim=1)


def angular_momentum_penalty(env, **_kwargs) -> torch.Tensor:
    ang_vel_b = base_ang_vel(env)
    angmom_magnitude = torch.norm(ang_vel_b, dim=-1)
    env.extras["log"]["Metrics/angular_momentum_mean"] = torch.mean(angmom_magnitude)
    return torch.square(angmom_magnitude)


def is_terminated(env, **_kwargs) -> torch.Tensor:
    return env.terminated_buf.float()


def joint_acc_l2(env, **_kwargs) -> torch.Tensor:
    dof_vel = env.robot.get_dofs_velocity(env.actuated_dofs)
    return torch.sum(torch.square(dof_vel), dim=1)


def joint_pos_limits(env, **_kwargs) -> torch.Tensor:
    return torch.zeros(env.num_envs, device=env.device)


def action_rate_l2(env, **_kwargs) -> torch.Tensor:
    return torch.sum(torch.square(env.actions - env.last_actions), dim=1)


def foot_gait(
    env,
    period: float = 0.6,
    offset: tuple[float, ...] = (0.0, 0.5),
    threshold: float = 0.56,
    command_name: str | None = None,
    command_threshold: float = 0.1,
    sensor_name: str = "",
    **_kwargs,
) -> torch.Tensor:
    """Reward contact state matching a phase-scheduled gait.

    Each foot gets a phase offset (``(0.0, 0.5)`` for a two-legged alternating
    gait). Within its cycle a foot is scheduled to be in stance while its phase
    is below ``threshold`` and in swing above it; the reward is the fraction of
    feet whose measured contact matches that schedule.

    ``period`` and ``offset`` must line up with the ``phase`` observation, which
    is what the policy conditions on — otherwise the policy is asked to track a
    clock it cannot see.

    Only active while a velocity command is being given: standing robots should
    keep both feet down, and rewarding a swing phase there would fight
    ``stand_still``.
    """
    sensor = env.sensors.get(sensor_name)
    if sensor is None or period <= 0.0:
        return torch.zeros(env.num_envs, device=env.device)

    contact = sensor.data.found.float()
    num_feet = contact.shape[1]
    offsets = torch.as_tensor(offset, device=env.device, dtype=torch.float32)
    if offsets.numel() != num_feet:
        raise ValueError(
            f"foot_gait: {offsets.numel()} phase offsets for {num_feet} feet "
            f"from sensor '{sensor_name}'."
        )

    time_s = (env.episode_length_buf * env.step_dt).unsqueeze(-1)
    foot_phase = (time_s / period + offsets.unsqueeze(0)) % 1.0
    expect_stance = (foot_phase < threshold).float()
    reward = torch.mean(1.0 - torch.abs(contact - expect_stance), dim=1)

    active = _command_active(env, command_name, command_threshold)
    if active is not None:
        reward = reward * active
    return reward


def foot_clearance(
    env,
    target_height: float = 0.10,
    command_name: str | None = None,
    command_threshold: float = 0.1,
    sensor_name: str = "feet_ground_contact",
    asset_cfg=None,
    **_kwargs,
) -> torch.Tensor:
    """Penalize deviation from a target swing height, weighted by foot speed.

    Height is measured above the terrain under the foot, not above ``z=0``, so
    the target means the same thing on a staircase as on flat ground.

    Only feet that are off the ground are scored, and their height error is
    weighted by horizontal speed, so the cost concentrates on mid-swing where
    clearance actually matters rather than on touchdown and lift-off.
    """
    site_names = resolve_site_names(env.sites, asset_cfg)
    if not site_names:
        return torch.zeros(env.num_envs, device=env.device)

    positions = env.sites.pos(site_names)
    height = positions[..., 2] - env.terrain.height_at(positions)
    speed_xy = torch.norm(env.sites.lin_vel(site_names)[..., :2], dim=-1)

    # Swing feet only. Weighting height error by speed alone (as Isaac Lab and
    # mjlab do) leaves a degenerate minimum: a *stance* foot sits at h~0, so its
    # height error is the full target, and the cheapest way to shrink the
    # product is to stop moving the feet at all. Training confirms it — with the
    # ungated form, mean foot height fell from 3.0 cm to 1.4 cm over 350
    # iterations while the terrain curriculum slid backwards. Excluding loaded
    # feet leaves raising the swing foot as the only way to reduce the cost, and
    # hands stance-foot sliding to `foot_slip`, which is the term for it.
    in_air = _feet_in_air(env, sensor_name, len(site_names))
    cost = torch.sum(torch.abs(height - target_height) * speed_xy * in_air, dim=1)

    swing_count = torch.clamp(in_air.sum(), min=1.0)
    env.extras["log"]["Metrics/foot_clearance_mean"] = (
        torch.sum(height * in_air) / swing_count
    )

    active = _command_active(env, command_name, command_threshold)
    if active is not None:
        cost = cost * active
    return cost


def _feet_in_air(env, sensor_name: str, num_feet: int) -> torch.Tensor:
    """Float mask of feet not currently in contact, shape ``(num_envs, num_feet)``.

    All-ones when the sensor is missing, so a task without contact sensing
    degrades to the ungated behaviour rather than silently zeroing the term.
    """
    sensor = env.sensors.get(sensor_name)
    if sensor is None:
        return torch.ones(env.num_envs, num_feet, device=env.device)
    in_air = 1.0 - sensor.data.found.float()
    if in_air.shape[1] != num_feet:
        raise ValueError(
            f"foot_clearance: sensor '{sensor_name}' reports {in_air.shape[1]} "
            f"contacts but {num_feet} foot sites are configured."
        )
    return in_air


def foot_slip(
    env,
    sensor_name: str = "feet_ground_contact",
    command_name: str | None = None,
    command_threshold: float = 0.1,
    asset_cfg=None,
    **_kwargs,
) -> torch.Tensor:
    """Penalize horizontal foot motion while the foot is loaded.

    Contact comes from the force sensor and velocity from the foot site, so a
    foot pivoting about its ankle counts as slipping — which the link-origin
    velocity alone would miss.
    """
    site_names = resolve_site_names(env.sites, asset_cfg)
    contact_forces_tensor = foot_contact_forces(env, sensor_name=sensor_name).reshape(
        env.num_envs, -1, 3
    )
    if not site_names or contact_forces_tensor.numel() == 0:
        return torch.zeros(env.num_envs, device=env.device)

    in_contact = torch.norm(contact_forces_tensor, dim=-1) > 1.0
    if in_contact.shape[1] != len(site_names):
        raise ValueError(
            f"foot_slip: sensor '{sensor_name}' reports {in_contact.shape[1]} "
            f"contacts but {len(site_names)} foot sites are configured."
        )
    foot_vel_xy = env.sites.lin_vel(site_names)[..., :2]
    slip_speed = torch.norm(foot_vel_xy, dim=-1) * in_contact.float()

    env.extras["log"]["Metrics/slip_velocity_mean"] = torch.mean(slip_speed)
    cost = torch.sum(torch.square(slip_speed), dim=1)

    active = _command_active(env, command_name, command_threshold)
    if active is not None:
        cost = cost * active
    return cost


def soft_landing(env, **_kwargs) -> torch.Tensor:
    env.extras["log"]["Metrics/landing_force_mean"] = torch.tensor(
        0.0, device=env.device
    )
    return torch.zeros(env.num_envs, device=env.device)


def stand_still(
    env, command_name: str = "twist", command_threshold: float = 0.1, **_kwargs
) -> torch.Tensor:
    command = env.command_manager.get_command(command_name)
    dof_pos_err = env.robot.get_dofs_position(env.actuated_dofs) - env._init_dof_pos
    command_norm = torch.norm(command[:, :2], dim=1) + torch.abs(command[:, 2])
    standing = command_norm <= command_threshold
    return torch.sum(torch.square(dof_pos_err), dim=1) * standing.float()
