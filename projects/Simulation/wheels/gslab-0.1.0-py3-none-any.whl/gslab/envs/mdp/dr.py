# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
"""Domain randomization event functions for the Genesis-backed environment.

These are simplified, Genesis-native adaptations of the model-field domain
randomization helpers in mjlab. Where mjlab writes directly to per-world MuJoCo
model fields, Genesis exposes a per-environment ``friction_ratio`` multiplier on
top of each geom's base friction, so we randomize through that mechanism instead.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Literal

import torch

from gslab.managers.scene_entity_config import SceneEntityCfg

if TYPE_CHECKING:
    from genesis.engine.entities.rigid_entity import RigidEntity

    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv

_DEFAULT_ASSET_CFG = SceneEntityCfg("robot")

Operation = Literal["abs", "scale"]
Distribution = Literal["uniform"]


def _as_name_tuple(names: str | tuple[str, ...] | None) -> tuple[str, ...]:
    if names is None:
        return ()
    if isinstance(names, str):
        return (names,)
    return tuple(names)


def _resolve_geom_indices(
    entity: RigidEntity, link_names: tuple[str, ...], geom_type: str | None
) -> list[int]:
    """Resolve link names (or regex patterns) to global collision-geom indices.

    Geoms are selected by the link that carries them rather than by geom name:
    Genesis deduplicates identically-shaped collision meshes through a cache that
    also copies the cached mesh's metadata, so ``geom.metadata["name"]`` can report
    another geom's MJCF name (e.g. the four identical Go2 foot spheres all report
    the name of whichever foot was processed first). Link names are not affected.

    ``geom_type`` optionally restricts the selection to one ``gs.GEOM_TYPE`` member
    (by lowercase name, e.g. ``"sphere"``) for links that carry more collision
    geoms than the ones of interest. Matching follows the convention used elsewhere
    in gslab (``re.fullmatch``), so exact names and regex patterns both work.
    """
    import genesis as gs

    gs_type = getattr(gs.GEOM_TYPE, geom_type.upper()) if geom_type else None

    indices: list[int] = []
    for pattern in link_names:
        matched = [
            geom.idx
            for geom in entity.geoms
            if re.fullmatch(pattern, geom.link.name)
            and (gs_type is None or geom.type == gs_type)
        ]
        if not matched:
            available = sorted({geom.link.name for geom in entity.geoms})
            raise ValueError(
                f"Link pattern '{pattern}' matched no collision geoms on entity "
                f"'{entity.name}' (geom_type={geom_type!r}). Links with collision "
                f"geoms: {available}"
            )
        indices.extend(matched)
    # Preserve order while removing duplicates from overlapping patterns.
    return list(dict.fromkeys(indices))


def geom_friction(
    env: GenesisManagerBasedRlEnv,
    env_ids: torch.Tensor | None,
    ranges: tuple[float, float],
    asset_cfg: SceneEntityCfg = _DEFAULT_ASSET_CFG,
    geom_type: str | None = None,
    operation: Operation | str = "abs",
    distribution: Distribution | str = "uniform",
    shared_random: bool = False,
) -> None:
    """Randomize the friction of the selected collision geoms.

    Genesis represents per-environment friction as ``base_friction * friction_ratio``
    where ``base_friction`` is shared across environments. We therefore sample a
    target friction and write it through the per-environment ``friction_ratio``:

    - ``operation="abs"``: ``friction_ratio = sampled / base_friction`` so the
      effective friction equals the sampled value.
    - ``operation="scale"``: ``friction_ratio = sampled`` so the effective friction
      is the base scaled by the sampled multiplier.

    Args:
      env: The environment instance.
      env_ids: Environments to randomize. ``None`` means all (e.g. startup mode).
      ranges: ``(min, max)`` uniform sampling range.
      asset_cfg: Entity and geom selection: all collision geoms on the links named
        by ``body_names`` (see ``_resolve_geom_indices`` for why selection is
        link-based rather than geom-name-based).
      geom_type: Optional ``gs.GEOM_TYPE`` member name (lowercase, e.g.
        ``"sphere"``) further restricting the selection.
      operation: ``"abs"`` to set absolute friction, ``"scale"`` to multiply.
      distribution: Sampling distribution (only ``"uniform"`` is supported).
      shared_random: If ``True``, all selected geoms share the same sampled value
        per environment (e.g. so both feet get identical friction).
    """
    if distribution != "uniform":
        raise ValueError(
            f"geom_friction only supports the 'uniform' distribution, got "
            f"'{distribution}'."
        )

    link_names = _as_name_tuple(asset_cfg.body_names)
    if not link_names:
        return

    entity: RigidEntity = env.robot
    geoms_idx = _resolve_geom_indices(entity, link_names, geom_type)
    solver = env.scene._sim.rigid_solver

    if env_ids is None:
        envs_idx = None
        num_envs = env.num_envs
    else:
        envs_idx = env_ids
        num_envs = len(env_ids)
    num_geoms = len(geoms_idx)

    lower, upper = ranges
    sample_shape = (num_envs, 1) if shared_random else (num_envs, num_geoms)
    sampled = torch.empty(sample_shape, device=env.device).uniform_(lower, upper)
    if shared_random:
        sampled = sampled.expand(num_envs, num_geoms)

    if operation == "abs":
        base = solver.get_geoms_friction(geoms_idx).to(env.device)  # (num_geoms,)
        base = base.clamp_min(1e-6).unsqueeze(0)  # avoid division by zero
        friction_ratio = sampled / base
    elif operation == "scale":
        friction_ratio = sampled
    else:
        raise ValueError(f"Unknown operation '{operation}'.")

    solver.set_geoms_friction_ratio(friction_ratio.contiguous(), geoms_idx, envs_idx)
