# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

from typing import TYPE_CHECKING

import genesis.utils.geom as gu
import torch

from gslab.entity import resolve_site_names
from gslab.sensor.height_scan import HeightScanCfg, scan_heights

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv
    from gslab.managers.observation_manager import ObservationTermCfg


def _sensor_cfg(env: GenesisManagerBasedRlEnv, sensor_name: str):
    for sensor_cfg in env.cfg.scene.sensors:
        if sensor_cfg.name == sensor_name:
            return sensor_cfg
    return None


def ray_count(env: GenesisManagerBasedRlEnv, sensor_name: str) -> int:
    """Number of sample points a scanning sensor produces, or 0 if absent."""
    sensor_cfg = _sensor_cfg(env, sensor_name)
    if sensor_cfg is None or not hasattr(sensor_cfg, "pattern"):
        return 0
    return sensor_cfg.pattern.num_points


def contact_sensor_dim(env: GenesisManagerBasedRlEnv, sensor_name: str) -> int:
    sensor = env.sensors.get(sensor_name)
    if sensor is None:
        return 0
    return sensor.num_primaries * sensor.cfg.num_slots


def base_ang_vel(env: GenesisManagerBasedRlEnv, **_kwargs) -> torch.Tensor:
    return gu.transform_by_quat(env.robot.get_ang(), gu.inv_quat(env.robot.get_quat()))


def base_lin_vel(env: GenesisManagerBasedRlEnv, **_kwargs) -> torch.Tensor:
    return gu.transform_by_quat(env.robot.get_vel(), gu.inv_quat(env.robot.get_quat()))


def projected_gravity(env: GenesisManagerBasedRlEnv, **_kwargs) -> torch.Tensor:
    gravity = env._gravity_vec.expand(env.num_envs, -1)
    return gu.transform_by_quat(gravity, gu.inv_quat(env.robot.get_quat()))


def command(
    env: GenesisManagerBasedRlEnv, command_name: str = "twist", **_kwargs
) -> torch.Tensor:
    cmd = env.command_manager.get_command(command_name)
    if cmd is None:
        raise ValueError(f"Command term '{command_name}' not found.")
    return cmd


def phase(
    env: GenesisManagerBasedRlEnv, period: float = 0.0, **_kwargs
) -> torch.Tensor:
    if period <= 0.0:
        return torch.zeros(env.num_envs, 2, device=env.device)
    phase_value = (env.episode_length_buf * env.step_dt) % period / period
    return torch.stack(
        (
            torch.sin(phase_value * torch.pi * 2.0),
            torch.cos(phase_value * torch.pi * 2.0),
        ),
        dim=-1,
    )


def joint_pos(env: GenesisManagerBasedRlEnv, **_kwargs) -> torch.Tensor:
    return env.robot.get_dofs_position(env.actuated_dofs) - env._init_dof_pos


def joint_vel(env: GenesisManagerBasedRlEnv, **_kwargs) -> torch.Tensor:
    return env.robot.get_dofs_velocity(env.actuated_dofs)


def actions(env: GenesisManagerBasedRlEnv, **_kwargs) -> torch.Tensor:
    return env.actions


def height_scan(
    env: GenesisManagerBasedRlEnv, sensor_name: str = "", **_kwargs
) -> torch.Tensor:
    """Terrain height around the base, as configured by a ``HeightScanCfg``.

    Zeros when no such sensor is configured, so a task can carry the term
    without exteroception and keep a fixed observation width.
    """
    sensor_cfg = _sensor_cfg(env, sensor_name)
    if not isinstance(sensor_cfg, HeightScanCfg):
        return torch.zeros(env.num_envs, ray_count(env, sensor_name), device=env.device)
    return scan_heights(env, sensor_cfg)


def foot_height(
    env: GenesisManagerBasedRlEnv, asset_cfg=None, **_kwargs
) -> torch.Tensor:
    """Height of each foot above the ground beneath it, in meters.

    Measured against the terrain rather than against ``z=0``: on generated
    terrain the ground under a foot can be metres away from the world origin,
    and an absolute height would mostly encode which sub-terrain the robot
    happens to be standing on. On plane terrain the terrain height is zero, so
    this is the absolute height as before.
    """
    site_names = resolve_site_names(env.sites, asset_cfg)
    if not site_names:
        return torch.empty(env.num_envs, 0, device=env.device)
    positions = env.sites.pos(site_names)
    return positions[..., 2] - env.terrain.height_at(positions)


def foot_air_time(
    env: GenesisManagerBasedRlEnv, sensor_name: str = "", **_kwargs
) -> torch.Tensor:
    """Per-foot air time from the contact sensor (zeros unless tracked)."""
    sensor = env.sensors.get(sensor_name)
    if sensor is None or sensor.data.current_air_time is None:
        return torch.zeros(
            env.num_envs, contact_sensor_dim(env, sensor_name), device=env.device
        )
    return sensor.data.current_air_time


def foot_contact(
    env: GenesisManagerBasedRlEnv, sensor_name: str = "", **_kwargs
) -> torch.Tensor:
    """Per-foot in-contact flags from the contact sensor."""
    sensor = env.sensors.get(sensor_name)
    if sensor is None:
        return torch.zeros(env.num_envs, 0, device=env.device)
    return sensor.data.found.float()


def foot_contact_forces(
    env: GenesisManagerBasedRlEnv, sensor_name: str = "", **_kwargs
) -> torch.Tensor:
    """Per-foot net contact forces from the contact sensor, flattened."""
    sensor = env.sensors.get(sensor_name)
    if sensor is None:
        return torch.empty(env.num_envs, 0, device=env.device)
    return sensor.data.force.reshape(env.num_envs, -1)


def term_shape(
    env: GenesisManagerBasedRlEnv, term_cfg: ObservationTermCfg
) -> tuple[int, ...]:
    value = torch.as_tensor(term_cfg.func(env, **term_cfg.params), device=env.device)
    return tuple(value.shape[1:])
