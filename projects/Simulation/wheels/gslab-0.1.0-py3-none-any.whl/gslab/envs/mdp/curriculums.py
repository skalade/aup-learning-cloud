# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
"""Generic curriculum term functions.

Staged curricula keyed on ``env.common_step_counter``: each stage has a ``step``
threshold and the fields/params to apply once that many environment steps have
elapsed. Later reached stages take precedence. These mutate the target manager's
*live* term cfg, so the change takes effect on the next compute.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Sequence

import torch

if TYPE_CHECKING:
    from gslab.envs.manager_based_rl_env import GenesisManagerBasedRlEnv

_RESERVED_KEYS = {"step", "params"}


def _validate_stages(term_cfg: Any, term_name: str, stages: Sequence[dict]) -> None:
    """Validate stage ordering, field existence, and param keys."""
    for i in range(1, len(stages)):
        if stages[i]["step"] < stages[i - 1]["step"]:
            raise ValueError(
                f"Curriculum stages must be in nondecreasing step order, but stage"
                f" {i} has step {stages[i]['step']} < {stages[i - 1]['step']}."
            )
    for stage in stages:
        for key in stage:
            if key not in _RESERVED_KEYS and not hasattr(term_cfg, key):
                raise AttributeError(
                    f"Field '{key}' does not exist on the resolved term config"
                    f" for '{term_name}'."
                )
        unknown = stage.get("params", {}).keys() - term_cfg.params.keys()
        if unknown:
            raise KeyError(
                f"Stage at step {stage['step']} sets unknown param(s) {unknown}"
                f" on term '{term_name}'. Check for typos."
            )


def _apply_stages(
    term_cfg: Any, step_counter: int, stages: Sequence[dict]
) -> dict[str, torch.Tensor]:
    """Apply staged updates to ``term_cfg`` and return a snapshot for logging.

    Any stage key other than ``step``/``params`` is set as a top-level attribute on
    the term cfg (e.g. ``weight``); ``params`` entries are merged into
    ``term_cfg.params``.
    """
    for stage in stages:
        if step_counter >= stage["step"]:
            for key, value in stage.items():
                if key not in _RESERVED_KEYS:
                    setattr(term_cfg, key, value)
            for key, value in stage.get("params", {}).items():
                term_cfg.params[key] = value

    # Log only the fields/params that stages actually reference.
    logged_fields = {k for s in stages for k in s if k not in _RESERVED_KEYS}
    logged_params = {k for s in stages for k in s.get("params", {})}
    result: dict[str, torch.Tensor] = {}
    for key in logged_fields:
        value = getattr(term_cfg, key)
        if isinstance(value, (int, float, bool)):
            result[key] = torch.tensor(float(value))
    for key in logged_params:
        value = term_cfg.params[key]
        if isinstance(value, (int, float, bool)):
            result[key] = torch.tensor(float(value))
    return result


def reward_curriculum(
    env: GenesisManagerBasedRlEnv,
    env_ids: torch.Tensor | None,
    reward_name: str,
    stages: list[dict],
) -> dict[str, torch.Tensor]:
    """Update a reward term's weight and/or params across training stages.

    Example::

        CurriculumTermCfg(
            func=mdp.reward_curriculum,
            params={
                "reward_name": "action_rate_l2",
                "stages": [
                    {"step": 0, "weight": -0.01},
                    {"step": 24000, "weight": -0.05},
                ],
            },
        )
    """
    del env_ids
    term_cfg = env.reward_manager.get_term_cfg(reward_name)
    _validate_stages(term_cfg, reward_name, stages)
    return _apply_stages(term_cfg, env.common_step_counter, stages)


def termination_curriculum(
    env: GenesisManagerBasedRlEnv,
    env_ids: torch.Tensor | None,
    termination_name: str,
    stages: list[dict],
) -> dict[str, torch.Tensor]:
    """Update a termination term's params across training stages."""
    del env_ids
    term_cfg = env.termination_manager.get_term_cfg(termination_name)
    _validate_stages(term_cfg, termination_name, stages)
    return _apply_stages(term_cfg, env.common_step_counter, stages)
