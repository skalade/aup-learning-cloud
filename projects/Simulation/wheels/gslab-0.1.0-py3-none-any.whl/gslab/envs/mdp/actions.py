# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
"""Actions that control actuator transmissions (e.g., joints, tendons, sites)."""

from __future__ import annotations

from dataclasses import dataclass

from gslab.actuator.actuator import TransmissionType
from gslab.managers.action_manager import ActionTermCfg


@dataclass(kw_only=True)
class BaseActionCfg(ActionTermCfg):
    """Configuration for actions that control actuator transmissions."""

    transmission_type: TransmissionType = TransmissionType.JOINT
    """Type of transmission to control."""

    actuator_names: tuple[str, ...] | list[str]
    """Actuator names to control."""

    scale: float | dict[str, float] = 1.0
    """Action scale. Float or dict mapping actuator names to scales."""

    offset: float | dict[str, float] = 0.0
    """Action offset. Float or dict mapping actuator names to offsets."""

    preserve_order: bool = False
    """Whether to preserve the order of actuator names."""


@dataclass(kw_only=True)
class JointPositionActionCfg(BaseActionCfg):
    """Configuration for joint position control."""

    use_default_offset: bool = True

    def __post_init__(self):
        self.transmission_type = TransmissionType.JOINT
