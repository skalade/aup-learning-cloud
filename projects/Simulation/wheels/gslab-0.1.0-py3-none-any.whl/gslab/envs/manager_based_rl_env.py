# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

import math
from pathlib import Path
from typing import TYPE_CHECKING, Callable

import genesis as gs
import quadrants as qd
import torch
from tensordict import TensorDict

from gslab.entity import (
    EntityCfg,
    SiteResolver,
    initialize_robot_joints,
    setup_robot_pd_gains,
)
from gslab.envs.mujoco_mapping import map_integrator, map_jacobian, map_solver
from gslab.managers import (
    GenesisActionManager,
    GenesisCommandManager,
    GenesisCurriculumManager,
    GenesisEventManager,
    GenesisMetricsManager,
    GenesisObservationManager,
    GenesisRewardManager,
    GenesisTerminationManager,
)
from gslab.scene.scene import SceneCfg
from gslab.sensor import ContactSensor, ContactSensorCfg, HeightScanCfg
from gslab.sensor.sensor import SensorCfg
from gslab.terrains.terrain_entity import TerrainEntity, TerrainEntityCfg
from gslab.utils.seed import generate_seed, set_seed
from gslab.utils.spaces import Box
from gslab.utils.spaces import Dict as DictSpace

if TYPE_CHECKING:
    from genesis.engine.entities.rigid_entity import RigidEntity

    from gslab.envs import ManagerBasedRlEnvCfg


class GenesisBox(Box):
    """Box space that can sample batched torch tensors on the Genesis device."""

    def __init__(
        self,
        shape: tuple[int, ...],
        low: float = -math.inf,
        high: float = math.inf,
        device: torch.device | str | None = None,
    ) -> None:
        super().__init__(shape=shape, low=low, high=high)
        self.device = device or gs.device

    def sample(self) -> torch.Tensor:
        low = self.low if isinstance(self.low, (float, int)) else -math.inf
        high = self.high if isinstance(self.high, (float, int)) else math.inf
        if math.isfinite(float(low)) and math.isfinite(float(high)):
            return torch.empty(self.shape, device=self.device).uniform_(
                float(low), float(high)
            )
        return torch.empty(self.shape, device=self.device).uniform_(-1.0, 1.0)


class GenesisDictSpace(DictSpace):
    """Dict space variant that preserves sampling for nested Genesis spaces."""

    def sample(self) -> dict[str, torch.Tensor | dict]:
        return {
            name: space.sample()
            if hasattr(space, "sample")
            else torch.empty(space.shape)
            for name, space in self.spaces.items()
        }


def batch_genesis_space(space: Box | DictSpace, batch_size: int) -> Box | DictSpace:
    if isinstance(space, DictSpace):
        return GenesisDictSpace(
            spaces={
                key: batch_genesis_space(subspace, batch_size)
                for key, subspace in space.spaces.items()
            },
            shape=(batch_size,),
            dtype=space.dtype,
        )
    if isinstance(space, GenesisBox):
        return GenesisBox(
            shape=(batch_size,) + space.shape,
            low=space.low,
            high=space.high,
            device=space.device,
        )
    return GenesisBox(shape=(batch_size,) + space.shape)


class GenesisManagerBasedRlEnv:
    metadata = {
        "render_modes": [None, "rgb_array"],
        "genesis_version": gs.__version__,
        "quadrants_version": qd.__version__,
        "render_fps": 0.0,
    }
    cfg: ManagerBasedRlEnvCfg

    def __init__(
        self,
        cfg: ManagerBasedRlEnvCfg,
        show_viewer: bool = False,
        enable_gui: bool = False,
        pre_build_hooks: list[Callable] | None = None,
        viewer_res: tuple[int, int] | None = None,
    ) -> None:
        self.cfg = cfg
        # Seed before the scene is built so startup domain-randomization
        # events and initial resets draw from a seeded RNG. seed() stores
        # the effective value back into cfg.seed.
        self.seed(cfg.seed if cfg.seed is not None else generate_seed())
        robot_mjcf = Path(cfg.robot_mjcf).expanduser().resolve()
        if not robot_mjcf.is_file():
            raise FileNotFoundError(f"Robot MJCF not found: {robot_mjcf}")
        self.device = gs.device
        self.num_envs = cfg.scene.num_envs
        self.env_spacing = cfg.scene.env_spacing
        self.show_viewer = show_viewer
        self.enable_gui = enable_gui
        self.viewer_res = viewer_res
        self.render_mode = "human" if show_viewer else None
        self._is_initialized = False
        self._observation_space = None
        self._action_space = None

        self.scene = self._initialize_scene(cfg, robot_mjcf)
        self.terrain = self._add_terrain(cfg.scene)
        self.robot_cfg: EntityCfg = cfg.scene.entities["robot"]
        self.robot = self._add_robot(self.robot_cfg, robot_mjcf)
        # Genesis resolves MJCF sites away at import, so foot sites are read
        # back out of the MJCF and re-derived from their parent links.
        self.sites = SiteResolver(self.robot, robot_mjcf, self.device)

        self.num_actions = 0

        self.sensors = self._add_sensors(cfg.scene.sensors)

        self._initialize_managers()
        self._configure_solver()
        self.pre_build_hooks = pre_build_hooks
        self._apply_pre_build_hooks()
        self._build_scene()
        self._setup_robot_entity()
        # Startup events run once now that the scene is built (e.g. foot friction
        # domain randomization writes per-environment friction ratios).
        self.event_manager.apply("startup")
        self._init_runtime_buffers()
        self._configure_gym_env_spaces()
        self.obs_buf = self.observation_manager.compute()
        self.metadata["render_fps"] = int(round(1.0 / self.step_dt))

    @property
    def unwrapped(self) -> "GenesisManagerBasedRlEnv":
        return self

    @property
    def observation_space(self):
        if self._observation_space is None:
            raise RuntimeError("Observation space is not initialized.")
        return self._observation_space

    @property
    def action_space(self):
        if self._action_space is None:
            raise RuntimeError("Action space is not initialized.")
        return self._action_space

    def _initialize_managers(self):
        self.action_manager = GenesisActionManager(self.cfg.actions, self)
        self.command_manager = GenesisCommandManager(self.cfg.commands, self)
        self.observation_manager = GenesisObservationManager(
            self.cfg.observations, self
        )
        self.reward_manager = GenesisRewardManager(self.cfg.rewards, self)
        self.metrics_manager = GenesisMetricsManager(self.cfg.metrics, self)
        self.termination_manager = GenesisTerminationManager(
            self.cfg.terminations, self
        )
        self.event_manager = GenesisEventManager(self.cfg.events, self)
        self.curriculum_manager = (
            GenesisCurriculumManager(self.cfg.curriculum, self)
            if self.cfg.curriculum
            else None
        )

    def _initialize_scene(
        self, cfg: ManagerBasedRlEnvCfg, robot_mjcf: Path
    ) -> gs.Scene:
        rigid_options = self._resolve_rigid_options(cfg, robot_mjcf)
        scene = gs.Scene(
            sim_options=gs.options.SimOptions(
                dt=cfg.sim.mujoco.timestep, substeps=1, gravity=cfg.sim.mujoco.gravity
            ),
            show_viewer=self.show_viewer,
            viewer_options=gs.options.ViewerOptions(
                enable_gui=self.enable_gui, res=self.viewer_res
            ),
            rigid_options=rigid_options,
            profiling_options=gs.options.ProfilingOptions(show_FPS=False),
        )
        return scene

    def _configure_solver(self):
        sparse_solve = map_jacobian(
            self.cfg.sim.mujoco.jacobian,
            self.robot.n_dofs,
            num_envs=self.num_envs,
        )
        self.scene._sim.rigid_solver._options.sparse_solve = sparse_solve
        gs.logger.info(
            f"Genesis constraint jacobian: "
            f"{'sparse' if sparse_solve else 'dense'} "
            f"(requested={self.cfg.sim.mujoco.jacobian}, "
            f"n_dofs={self.robot.n_dofs}, num_envs={self.num_envs})."
        )

    def _apply_pre_build_hooks(self):
        if self.pre_build_hooks is None:
            return
        for hook in self.pre_build_hooks:
            hook(self)

    def _build_scene(self):
        # Genesis' env_spacing offsets environments for rendering only; physics
        # states are unaffected. With generator terrain the environments share
        # one terrain mesh and are already spread over it by their spawn
        # origins, so any extra visual offset would draw each robot away from
        # the ground it is actually standing on.
        if self.terrain.cfg.terrain_type == "generator":
            env_spacing = (0.0, 0.0)
        else:
            env_spacing = (self.env_spacing, self.env_spacing)
        self.scene.build(n_envs=self.num_envs, env_spacing=env_spacing)
        self.terrain.draw_debug_vis(self.scene)

    def _add_robot(self, robot_cfg: EntityCfg, robot_mjcf: Path) -> RigidEntity:
        return self.scene.add_entity(
            gs.morphs.MJCF(
                file=robot_mjcf,
                pos=robot_cfg.init_state.pos,
                quat=robot_cfg.init_state.rot,
            ),
            name="robot",
        )

    def _add_terrain(self, scene_cfg: SceneCfg) -> TerrainEntity:
        """Build the terrain and add it to the scene.

        Returns the gslab :class:`TerrainEntity`, which owns the per-environment
        spawn origins; the underlying Genesis entity is kept as
        ``self.terrain_geom``.
        """
        terrain_cfg: TerrainEntityCfg | None = scene_cfg.terrain
        if terrain_cfg is None:
            gs.logger.info(
                "No terrain configuration provided, defaulting to plane at "
                "(0.0, 0.0, 0.0)."
            )
            terrain_cfg = TerrainEntityCfg(terrain_type="plane")
        # The scene owns the environment count; the terrain needs it to lay out
        # spawn origins.
        terrain_cfg.num_envs = scene_cfg.num_envs
        if terrain_cfg.env_spacing is None:
            terrain_cfg.env_spacing = scene_cfg.env_spacing

        terrain = TerrainEntity(terrain_cfg, device=self.device)
        self.terrain_geom = self.scene.add_entity(terrain.morph(), name="terrain")
        # Sub-terrains that need vertical faces (real staircases) contribute
        # solid boxes on top of the heightfield.
        self.terrain_boxes = [
            self.scene.add_entity(morph, name=f"terrain_box_{index}")
            for index, morph in enumerate(terrain.box_morphs())
        ]
        if self.terrain_boxes:
            gs.logger.info(f"Added {len(self.terrain_boxes)} terrain step boxes.")
        return terrain

    def _add_sensors(
        self, sensors_cfg: tuple[SensorCfg, ...]
    ) -> dict[str, ContactSensor]:
        """Build gslab contact sensors over robot links.

        Each sensor registers Genesis ``ContactForce`` sensors on the scene, so
        this must run before ``_build_scene``. Two configs are not runtime
        sensors and are skipped: ``self_collision`` only toggles the solver's
        self-collision handling (see ``_resolve_rigid_options``), and a
        ``HeightScanCfg`` is read directly by its observation term, which
        samples the terrain heightfield rather than owning any state.
        """
        sensors: dict[str, ContactSensor] = {}
        for sensor_cfg in sensors_cfg:
            if sensor_cfg.name == "self_collision":
                continue
            if isinstance(sensor_cfg, HeightScanCfg):
                gs.logger.info(
                    f"Height scan '{sensor_cfg.name}': "
                    f"{sensor_cfg.pattern.num_points} sample points."
                )
                continue
            assert isinstance(sensor_cfg, ContactSensorCfg)
            sensor = ContactSensor(
                sensor_cfg, self.scene, self.robot, self.num_envs, self.device
            )
            gs.logger.info(
                f"Added contact sensor '{sensor_cfg.name}' over links: "
                f"{sensor.link_names}"
            )
            sensors[sensor_cfg.name] = sensor
        return sensors

    def _update_sensors(self) -> None:
        for sensor in self.sensors.values():
            sensor.update(self.step_dt)

    def _reset_sensors(self, env_ids: torch.Tensor | None = None) -> None:
        for sensor in self.sensors.values():
            sensor.reset(env_ids)

    def _resolve_rigid_options(
        self, cfg: ManagerBasedRlEnvCfg, robot_mjcf: Path
    ) -> gs.options.RigidOptions:
        found_self_collision_sensor = any(
            s.name == "self_collision" for s in cfg.scene.sensors
        )

        kwargs: dict = dict(
            enable_self_collision=found_self_collision_sensor,
            enable_mujoco_compatibility=True,
            enable_joint_limit=True,
            integrator=map_integrator(cfg.sim.mujoco.integrator),
            constraint_solver=map_solver(cfg.sim.mujoco.solver),
            iterations=cfg.sim.mujoco.iterations,
            tolerance=cfg.sim.mujoco.tolerance,
            ls_iterations=cfg.sim.mujoco.ls_iterations,
            ls_tolerance=cfg.sim.mujoco.ls_tolerance,
            sparse_solve=False,  # is be updated after robot entity creation based on n_dofs
            use_gjk_collision=cfg.sim.mujoco.multiccd,
        )
        if cfg.sim.nconmax is not None:
            kwargs["max_collision_pairs"] = cfg.sim.nconmax
        return gs.options.RigidOptions(**kwargs)

    def _configure_gym_env_spaces(self) -> None:
        if self.observation_manager is None:
            raise RuntimeError("Observation manager must be initialized first.")
        self.single_observation_space = GenesisDictSpace()
        for group_name, group_cfg in self.cfg.observations.items():
            term_dims = {
                term_name: self.observation_manager.term_shape(
                    group_name, term_name, term_cfg
                )
                for term_name, term_cfg in group_cfg.terms.items()
            }
            if group_cfg.concatenate_terms:
                group_dim = sum(math.prod(shape) for shape in term_dims.values())
                self.single_observation_space.spaces[group_name] = GenesisBox(
                    shape=(group_dim,), device=self.device
                )
                continue

            group_space = GenesisDictSpace()
            for term_name, term_dim in term_dims.items():
                group_space.spaces[term_name] = GenesisBox(
                    shape=term_dim, device=self.device
                )
            self.single_observation_space.spaces[group_name] = group_space

        self.single_action_space = GenesisBox(
            shape=(self.num_actions,), low=-1.0, high=1.0, device=self.device
        )

        self._observation_space = batch_genesis_space(
            self.single_observation_space, self.num_envs
        )
        self._action_space = batch_genesis_space(
            self.single_action_space, self.num_envs
        )

    def _setup_robot_entity(self):
        self._initialize_robot()
        self._setup_pd_gains()

    def _initialize_robot(self):
        init_joint_pos = self.robot_cfg.init_state.joint_pos
        dof_targets, dof_indices = initialize_robot_joints(self.robot, init_joint_pos)
        self._dof_indices = torch.tensor(dof_indices, dtype=torch.long)
        self._dof_targets = torch.tensor(dof_targets, dtype=torch.float32)

    def _setup_pd_gains(self):
        self.actuated_dofs, actuated_names = setup_robot_pd_gains(
            self.robot, self.robot_cfg, self.device
        )
        self.actuated_joint_names = actuated_names
        self.num_actions = len(actuated_names)
        self.action_manager.configure_actuated_joints(actuated_names)

        # Snapshot initial positions after _initialize_robot has set them.
        self._init_dof_pos = self.robot.get_dofs_position(
            dofs_idx_local=self.actuated_dofs
        )
        self._init_qpos = self.robot.get_qpos()
        # Spawn pose relative to a terrain origin. Kept so spawn positions can
        # be recomputed whenever the terrain curriculum moves an environment.
        self._spawn_qpos = self._init_qpos.clone()
        self.refresh_terrain_spawn()

    @property
    def places_envs_on_terrain(self) -> bool:
        """Whether spawn poses are offset onto sub-terrain patches.

        Only generator terrain is placed this way. On a plane every environment
        keeps spawning at the configured pose and is spread out visually by
        Genesis' ``env_spacing``, which is the pre-existing behaviour.
        """
        return self.terrain.cfg.terrain_type == "generator"

    def refresh_terrain_spawn(self, env_ids: torch.Tensor | None = None) -> None:
        """Recompute spawn poses from the terrain's environment origins.

        ``_init_qpos`` is what ``reset`` and ``_reset_idx`` write back, so
        shifting the free root joint's translation here is enough to place every
        robot on its patch — the reset paths need no changes. The configured
        ``init_state.pos`` is kept as an offset from the patch origin, which is
        where the robot's standing height comes from.

        Call this after the terrain curriculum reassigns patches, and before the
        affected environments are reset.
        """
        if not self.places_envs_on_terrain:
            return
        origins = self.terrain.env_origins
        # A free root joint occupies qpos[0:3] as translation and qpos[3:7] as
        # quaternion. Skip entities without one; there is nothing to place.
        if origins is None or self._init_qpos.shape[-1] < 3:
            return
        origins = origins.to(device=self._init_qpos.device, dtype=self._init_qpos.dtype)
        if env_ids is None:
            self._init_qpos[:, :3] = self._spawn_qpos[:, :3] + origins
            # Forward kinematics must run here: startup events and the first
            # observation are computed right after this, and would otherwise
            # read link poses from before the robots were moved onto the
            # terrain. Per-environment refreshes skip it, because the reset that
            # follows writes the state anyway.
            self.robot.set_qpos(self._init_qpos, zero_velocity=True, skip_forward=False)
            self.sites.invalidate()
        else:
            self._init_qpos[env_ids, :3] = (
                self._spawn_qpos[env_ids, :3] + origins[env_ids]
            )

    @property
    def step_dt(self) -> float:
        return self.cfg.sim.mujoco.timestep * self.cfg.decimation

    @property
    def max_episode_length_s(self) -> float:
        return self.cfg.episode_length_s

    @property
    def max_episode_length(self) -> int:
        if self.cfg.episode_length_s <= 0.0:
            return 0
        return math.ceil(self.cfg.episode_length_s / self.step_dt)

    def _init_runtime_buffers(self) -> None:
        self.common_step_counter = 0
        self._sim_step_counter = 0
        self.episode_length_buf = torch.zeros(
            self.num_envs, device=self.device, dtype=torch.long
        )
        self.last_actions = torch.zeros(
            self.num_envs, self.num_actions, device=self.device
        )
        self.prev_prev_actions = torch.zeros_like(self.last_actions)
        self.actions = torch.zeros_like(self.last_actions)
        self.command_manager.initialize_buffers()
        # Back-compat alias: the twist command buffer (zeros for command-free
        # tasks, so command-agnostic code can still read it).
        twist = self.command_manager.get_command("twist")
        self.commands = (
            twist
            if twist is not None
            else torch.zeros(self.num_envs, 3, device=self.device)
        )
        self.reward_buf = torch.zeros(self.num_envs, device=self.device)
        self.terminated_buf = torch.zeros(
            self.num_envs, device=self.device, dtype=torch.bool
        )
        self.truncated_buf = torch.zeros_like(self.terminated_buf)
        self.extras: dict = {}
        self._gravity_vec = torch.tensor(
            [0.0, 0.0, -1.0], device=self.device, dtype=torch.float32
        )
        self.observation_manager.reset()
        self.reward_manager.reset()
        self.metrics_manager.reset()
        self.termination_manager.reset()
        self.command_manager.reset()
        self.command_manager.resample(torch.arange(self.num_envs, device=self.device))

    def reset(
        self, *, seed: int | None = None, options: dict | None = None
    ) -> tuple[dict[str, torch.Tensor], dict]:
        del options
        if seed is not None:
            self.seed(seed)
        self.robot.set_qpos(self._init_qpos, zero_velocity=True, skip_forward=True)
        self.sites.invalidate()
        self.episode_length_buf.zero_()
        self.actions.zero_()
        self.last_actions.zero_()
        self.prev_prev_actions.zero_()
        self.reward_buf.zero_()
        self.terminated_buf.zero_()
        self.truncated_buf.zero_()
        self.observation_manager.reset()
        self.reward_manager.reset()
        self.metrics_manager.reset()
        self.termination_manager.reset()
        self.command_manager.reset()
        self._reset_sensors()
        self.event_manager.reset()
        self.event_manager.apply(
            "reset", env_ids=torch.arange(self.num_envs, device=self.device)
        )
        self.extras = {}
        # Apply the curriculum (e.g. stage-0 command ranges) before the first
        # resample so the initial episodes already reflect it.
        if self.curriculum_manager is not None:
            self.curriculum_manager.compute(
                torch.arange(self.num_envs, device=self.device)
            )
        self.command_manager.resample(torch.arange(self.num_envs, device=self.device))
        self.obs_buf = self.observation_manager.compute()
        return self.obs_buf, self.extras

    def _reset_idx(self, env_ids: torch.Tensor) -> None:
        if env_ids.numel() == 0:
            return
        self.robot.set_qpos(
            self._init_qpos[env_ids],
            envs_idx=env_ids,
            zero_velocity=True,
            skip_forward=True,
        )
        self.sites.invalidate()
        self.episode_length_buf[env_ids] = 0
        self.actions[env_ids] = 0.0
        self.last_actions[env_ids] = 0.0
        self.prev_prev_actions[env_ids] = 0.0
        if self.observation_manager is not None:
            self.observation_manager.reset(env_ids)
        if self.reward_manager is not None:
            self.reward_manager.reset(env_ids)
        if self.metrics_manager is not None:
            self.metrics_manager.reset(env_ids)
        if self.termination_manager is not None:
            self.termination_manager.reset(env_ids)
        if self.command_manager is not None:
            self.command_manager.reset(env_ids)
            self.command_manager.resample(env_ids)
        self._reset_sensors(env_ids)
        self.event_manager.reset(env_ids)
        self.event_manager.apply("reset", env_ids=env_ids)

    def seed(self, seed: int = -1) -> int | None:
        """Seed Python/NumPy/torch RNGs and record the seed in ``cfg.seed``.

        Genesis kernel-side randomness is seeded at ``gs.init(seed=...)``
        time and is not affected here. Passing a negative seed leaves the
        RNGs untouched and only returns the current seed.
        """
        if seed >= 0:
            set_seed(seed)
            self.cfg.seed = seed
        return self.cfg.seed

    def get_observations(self) -> TensorDict:
        """Return the observations for the current step.

        Deliberately returns the buffer computed by the last ``step`` or
        ``reset`` rather than recomputing. Observation terms with a history
        window push a frame every time they are evaluated, so recomputing here
        would advance the history once per *read* instead of once per step, and
        a caller that inspects observations before stepping would silently
        double the history rate.

        Code that mutates state behind the managers' backs — injecting a
        velocity command, for instance — must call ``_compute_observations``
        itself to refresh the buffer.
        """
        if self.observation_manager is None:
            raise RuntimeError("Observation manager is not initialized.")
        return TensorDict(self.obs_buf, batch_size=[self.num_envs])

    def render(self):
        viewer = getattr(self.scene, "viewer", None)
        if viewer is not None and hasattr(viewer, "render"):
            return viewer.render()
        return None

    def close(self) -> None:
        viewer = getattr(self.scene, "viewer", None)
        if viewer is not None and hasattr(viewer, "stop"):
            viewer.stop()

    def _compute_observations(self) -> dict[str, torch.Tensor]:
        if self.observation_manager is None:
            raise RuntimeError("Observation manager is not initialized.")
        return self.observation_manager.compute()

    def _reset_log_extras(self, env_ids: torch.Tensor) -> dict[str, torch.Tensor | int]:
        extras: dict[str, torch.Tensor | int] = {}
        if env_ids.numel() == 0:
            return extras

        if self.reward_manager is not None:
            extras.update(self.reward_manager.pop_episode_logs(env_ids))
        if self.metrics_manager is not None:
            extras.update(self.metrics_manager.pop_episode_logs(env_ids))
        if self.command_manager is not None:
            extras.update(self.command_manager.pop_episode_logs(env_ids))
        if self.termination_manager is not None:
            extras.update(self.termination_manager.pop_episode_logs(env_ids))
        if self.curriculum_manager is not None:
            self.curriculum_manager.compute(env_ids)
            extras.update(self.curriculum_manager.pop_episode_logs())

        return extras

    def step(
        self, actions: torch.Tensor
    ) -> tuple[dict[str, torch.Tensor], torch.Tensor, torch.Tensor, torch.Tensor, dict]:
        actions = actions.to(device=self.device, dtype=torch.float32)
        if actions.shape != (self.num_envs, self.num_actions):
            raise ValueError(
                f"Invalid action shape {tuple(actions.shape)}; expected "
                f"{(self.num_envs, self.num_actions)}."
            )

        self.prev_prev_actions.copy_(self.last_actions)
        self.last_actions.copy_(self.actions)
        self.actions.copy_(actions)
        target_dof_pos = self.action_manager.target_dof_positions(
            self.actions, self._init_dof_pos
        )
        for _ in range(self.cfg.decimation):
            self.robot.control_dofs_position(
                target_dof_pos,
                dofs_idx_local=self.actuated_dofs,
            )
            self.scene.step()
            self._sim_step_counter += 1

        # Physics advanced; cached site poses are stale for every term that
        # runs below.
        self.sites.invalidate()
        self.common_step_counter += 1
        self.episode_length_buf += 1
        self._update_sensors()
        self.command_manager.update()
        self.event_manager.apply("step")
        self.event_manager.apply("interval", dt=self.step_dt)
        self.extras = {"time_outs": self.truncated_buf.clone(), "log": {}}
        self.truncated_buf.zero_()
        if (
            self.reward_manager is None
            or self.metrics_manager is None
            or self.termination_manager is None
        ):
            raise RuntimeError(
                "Reward, metrics and termination managers must be initialized."
            )
        self.terminated_buf, self.truncated_buf = self.termination_manager.compute()
        self.reward_buf = self.reward_manager.compute()
        self.metrics_manager.compute()
        reset_buf = self.terminated_buf | self.truncated_buf
        reset_ids = torch.nonzero(reset_buf, as_tuple=False).flatten()
        self.extras["log"].update(self._reset_log_extras(reset_ids))
        self.extras["time_outs"] = self.truncated_buf.clone()
        self._reset_idx(reset_ids)

        self.obs_buf = self._compute_observations()
        return (
            self.obs_buf,
            self.reward_buf,
            self.terminated_buf,
            self.truncated_buf,
            self.extras,
        )
