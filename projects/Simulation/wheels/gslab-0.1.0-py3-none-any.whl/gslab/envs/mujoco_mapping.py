# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from typing import Literal

import genesis as gs


def map_integrator(integrator: Literal["euler", "implicitfast"]) -> gs.integrator:
    """Map name of MuJoCo integrator to Genesis."""
    mapping = {
        "euler": "Euler",
    }
    return gs.integrator[mapping.get(integrator, integrator)]


def map_solver(solver: Literal["newton", "cg", "pgs"]) -> gs.constraint_solver:
    """Map name of MuJoCo solver to Genesis.

    Args:
        solver: `mjlab.sim.sim.MujocoCfg.solver`
    """
    mapping = {
        "cg": "CG",
        "newton": "Newton",
    }
    if solver == "pgs":
        raise NotImplementedError(
            f"Genesis doesn't support pgs solver. Choose one from: {list(mapping.keys())}"
        )
    return gs.constraint_solver[mapping.get(solver, solver)]


_MUJOCO_JACOBIAN_AUTO_NV_THRESHOLD = 60
"""MuJoCo switches jacobian=auto to sparse when nv >= this value.

Source: https://github.com/google-deepmind/mujoco/blob/2c4f710c/mjx/mujoco/mjx/_src/support.py
"""

_GENESIS_DENSE_BATCH_ENV_THRESHOLD = 8192
"""Genesis' dense, transposed constraint layout is only used up to this batch size."""


def map_jacobian(
    jacobian: Literal["auto", "dense", "sparse"],
    nv: int,
    *,
    num_envs: int = 1,
) -> bool:
    """Map MuJoCo jacobian type to Genesis sparse_solve flag.

    MuJoCo 'sparse' exploits sparsity in the constraint system - equivalent to
    Genesis sparse_solve=True. 'dense' maps to False.

    MuJoCo's own 'auto' heuristic only considers the single-model DOF count
    (sparse when nv >= 60). Genesis vectorizes environments in one solver, so
    dense Jacobian storage and dense constraint kernels also scale with
    num_envs. For large batches, use sparse even when one robot has fewer than
    60 DOFs; this keeps environments independent in the per-env solve while
    avoiding dense work over every DOF for every contact row.

    Args:
        jacobian: `mjlab.sim.sim.MujocoCfg.jacobian`
        nv: total number of DOFs in the model (mujoco.MjModel.nv)
        num_envs: number of Genesis batch environments in the scene
    """
    if jacobian == "sparse":
        return True
    if jacobian == "dense":
        return False
    return (
        nv >= _MUJOCO_JACOBIAN_AUTO_NV_THRESHOLD
        or num_envs > _GENESIS_DENSE_BATCH_ENV_THRESHOLD
    )
