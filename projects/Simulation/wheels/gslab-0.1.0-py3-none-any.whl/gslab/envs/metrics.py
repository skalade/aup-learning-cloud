# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Evaluation/logging metric term functions for ``GenesisMetricsManager``.

These are diagnostics, not MDP terms — nothing in the transition or reward
computation consumes them, so they live outside ``envs/mdp``.
"""

from __future__ import annotations

import torch


def mean_action_acc(env, **_kwargs) -> torch.Tensor:
    action_acc = env.actions - 2 * env.last_actions + env.prev_prev_actions
    return torch.mean(torch.abs(action_acc), dim=-1)
