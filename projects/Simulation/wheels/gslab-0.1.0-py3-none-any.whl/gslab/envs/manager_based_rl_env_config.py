# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
from dataclasses import dataclass, field
from pathlib import Path

from gslab.managers.action_manager import ActionTermCfg
from gslab.managers.command_manager import (
    CommandTermCfg,
)
from gslab.managers.curriculum_manager import (
    CurriculumTermCfg,
)
from gslab.managers.event_manager import EventTermCfg
from gslab.managers.metrics_manager import (
    MetricsTermCfg,
)
from gslab.managers.observation_manager import ObservationGroupCfg
from gslab.managers.reward_manager import RewardTermCfg
from gslab.managers.termination_manager import TerminationTermCfg
from gslab.scene.scene import SceneCfg
from gslab.sim.sim import SimulationCfg
from gslab.viewer.viewer_config import ViewerConfig


@dataclass(kw_only=True)
class ManagerBasedRlEnvCfg:
    """Configuration for a manager-based RL environment.

    This config defines all aspects of an RL environment: the physical scene,
    observations, actions, rewards, terminations, and optional features like
    commands and curriculum learning.

    The environment step size is ``sim.mujoco.timestep * decimation``. For example,
    with a 2ms physics timestep and decimation=10, the environment runs at 50Hz.
    """

    # Base environment configuration.

    robot_mjcf: Path
    """Path to the robot MJCF used to construct the environment."""

    decimation: int
    """Number of physics simulation steps per environment step. Higher values mean
  coarser control frequency. Environment step duration = physics_dt * decimation."""

    scene: SceneCfg
    """Scene configuration defining terrain, entities, and sensors. The scene
  specifies ``num_envs``, the number of parallel environments."""

    observations: dict[str, ObservationGroupCfg] = field(default_factory=dict)
    """Observation groups configuration. Each group (e.g., "actor", "critic") contains
  observation terms that are concatenated. Groups can have different settings for
  noise, history, and delay."""

    actions: dict[str, ActionTermCfg] = field(default_factory=dict)
    """Action terms configuration. Each term controls a specific entity/aspect
  (e.g., joint positions). Action dimensions are concatenated across terms."""

    events: dict[str, EventTermCfg] = field(default_factory=dict)
    """Event terms for domain randomization and state resets. Each term is bound to
  a mode (``startup``/``reset``/``interval``/``step``) and fired by the event
  manager at the corresponding simulation event. Empty by default."""

    seed: int | None = None
    """Random seed for reproducibility, applied to Python/NumPy/torch RNGs when
  the environment is constructed. If None, a seed is drawn from OS entropy; the
  effective seed is stored back into this field. Genesis kernel-side randomness
  is seeded separately via ``gs.init(seed=...)`` (handled by ``train_g1``)."""

    sim: SimulationCfg = field(default_factory=SimulationCfg)
    """Simulation configuration including physics timestep, solver iterations,
  contact parameters, and NaN guarding."""

    viewer: ViewerConfig = field(default_factory=ViewerConfig)
    """Viewer configuration for rendering (camera position, resolution, etc.)."""

    # RL-specific configuration.

    episode_length_s: float = 0.0
    """Duration of an episode (in seconds).

  Episode length in steps is computed as:
    ceil(episode_length_s / (sim.mujoco.timestep * decimation))
  """

    rewards: dict[str, RewardTermCfg] = field(default_factory=dict)
    """Reward terms configuration."""

    terminations: dict[str, TerminationTermCfg] = field(default_factory=dict)
    """Termination terms configuration. If empty, episodes never reset. Use
  ``mdp.time_out`` with ``time_out=True`` for episode time limits."""

    commands: dict[str, CommandTermCfg] = field(default_factory=dict)
    """Command generator terms (e.g., velocity targets)."""

    curriculum: dict[str, CurriculumTermCfg] = field(default_factory=dict)
    """Curriculum terms that adjust environment parameters during training
  (e.g. widening command ranges or increasing difficulty). Empty by default."""

    metrics: dict[str, MetricsTermCfg] = field(default_factory=dict)
    """Custom metric terms for logging per-step values as episode averages."""

    scale_rewards_by_dt: bool = True
    """Whether to multiply rewards by the environment step duration (dt).

  When True (default), reward values are scaled by step_dt to normalize cumulative
  episodic rewards across different simulation frequencies. Set to False for
  algorithms that expect unscaled reward signals (e.g., HER, static reward scaling).
  """
