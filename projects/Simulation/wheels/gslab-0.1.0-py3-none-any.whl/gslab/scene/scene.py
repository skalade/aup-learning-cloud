# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
from __future__ import annotations

from dataclasses import dataclass, field

from gslab.entity import EntityCfg
from gslab.sensor import SensorCfg
from gslab.terrains.terrain_entity import TerrainEntityCfg


@dataclass(kw_only=True)
class SceneCfg:
    """Configuration for a simulation scene."""

    num_envs: int = 1
    """Number of parallel environments."""

    env_spacing: float = 2.0
    """Spacing between environment origins in meters."""

    terrain: TerrainEntityCfg | None = None
    """Terrain configuration. If ``None``, no terrain is added."""

    entities: dict[str, EntityCfg] = field(default_factory=dict)
    """Mapping of entity names to their configurations."""

    sensors: tuple[SensorCfg, ...] = field(default_factory=tuple)
    """Sensor configurations to attach to the scene."""
