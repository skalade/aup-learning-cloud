# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass
class MujocoCfg:
    """Configuration for MuJoCo simulation parameters."""

    # Integrator settings.
    timestep: float = 0.002
    integrator: Literal["euler", "implicitfast"] = "implicitfast"

    # Solver settings.
    jacobian: Literal["auto", "dense", "sparse"] = "auto"
    solver: Literal["newton", "cg", "pgs"] = "newton"
    iterations: int = 100
    tolerance: float = 1e-8
    ls_iterations: int = 50
    ls_tolerance: float = 0.01

    # Other.
    gravity: tuple[float, float, float] = (0.0, 0.0, -9.81)
    multiccd: bool = False


@dataclass(kw_only=True)
class SimulationCfg:
    nconmax: int | None = None
    """Number of contacts to allocate per world.

  Contacts exist in large heterogenous arrays: one world may have more than nconmax
  contacts. If None, a heuristic value is used."""
    mujoco: MujocoCfg = field(default_factory=MujocoCfg)
