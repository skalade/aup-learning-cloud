# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Stream a running simulation into a Jupyter notebook.

Genesis' native viewer (``show_viewer=True``) opens its own OS window, which is
no use in a notebook — and unavailable at all over SSH or in a container. An
off-screen camera renders to an RGB array instead, and this pushes those frames
into an ``ipywidgets.Image`` so the simulation appears inline.

Same pre-build-hook shape as :class:`gslab.vis.recorder.VideoRecorder`: the
camera has to exist before ``scene.build()``, so the viewer object is handed to
the environment constructor and then used to drive playback.

    viewer = NotebookViewer(NotebookViewCfg(width=720, height=480))
    env = GenesisManagerBasedRlEnv(cfg=env_cfg, pre_build_hooks=[viewer])
    viewer.show()
    viewer.play(policy, steps=600)
"""

from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    import torch

    from gslab.envs import GenesisManagerBasedRlEnv

# Behind and to the side of the robot, looking along its direction of travel.
# Placing the camera ahead of it (the obvious choice) points it back down the
# path already walked, which on a staircase means filming the approach instead
# of the steps.
#
# Far enough back to hold the robot and the flight of stairs it is heading for
# in the same frame; a tight shot follows the feet but loses the context that
# makes the behaviour readable.
DEFAULT_CAMERA_POS = (-7.5, 5.0, 3.4)
DEFAULT_CAMERA_LOOKAT = (2.5, 0.0, 0.6)


@dataclass
class NotebookViewCfg:
    """Settings for the inline notebook viewer."""

    width: int = 720
    height: int = 480
    fov: int = 40
    pos: tuple[float, float, float] = DEFAULT_CAMERA_POS
    lookat: tuple[float, float, float] = DEFAULT_CAMERA_LOOKAT
    follow: bool = True
    """Track the robot rather than holding a fixed viewpoint."""
    every: int = 4
    """Render one frame every N environment steps.

  Rendering costs far more than stepping, so drawing every step throttles the
  simulation to the render rate for no visible benefit."""
    jpeg_quality: int = 80
    """JPEG quality for the streamed frames. Lower is faster over a remote
  kernel connection."""
    far: float = 150.0
    """Far clipping distance, in meters.

  Genesis defaults this to 20 m, which is closer than it sounds: generated
  terrain is tens of meters across, and anything beyond the plane is simply
  not drawn, leaving an empty-looking frame."""
    follow_column: str | None = "real_stairs"
    """Name of the sub-terrain column to watch a robot on.

  Environments are handed out to columns in order, so environment 0 always
  lands on the first column — which in the stairs terrain is flat ground. A
  camera following it shows an empty floor and none of the terrain worth
  looking at. Naming a column picks an environment standing on that one
  instead. ``None`` keeps environment 0."""
    follow_env: int | None = None
    """Explicit environment index to follow, overriding ``follow_column``."""


class NotebookViewer:
    """Off-screen camera streamed to an ``ipywidgets.Image``.

    Pass the instance as a ``pre_build_hooks`` entry so the camera is created
    while the scene is still open, then call :meth:`show` once and
    :meth:`play` (or :meth:`update`) to drive it.
    """

    def __init__(self, cfg: NotebookViewCfg | None = None) -> None:
        self.cfg = cfg or NotebookViewCfg()
        self._env: GenesisManagerBasedRlEnv | None = None
        self.cam = None
        self.widget = None

    def __call__(self, env: GenesisManagerBasedRlEnv) -> None:
        """Pre-build hook: create the off-screen camera."""
        self._env = env
        self.env_idx = self._resolve_env_idx(env)
        self.cam = env.scene.add_camera(
            res=(self.cfg.width, self.cfg.height),
            pos=self.cfg.pos,
            lookat=self.cfg.lookat,
            fov=self.cfg.fov,
            far=self.cfg.far,
            env_idx=self.env_idx,
            GUI=False,
        )
        if self.cfg.follow:
            self.cam.follow_entity(env.robot)

    def _resolve_env_idx(self, env: GenesisManagerBasedRlEnv) -> int:
        """Pick the environment to watch, preferring one on the named column."""
        if self.cfg.follow_env is not None:
            return self.cfg.follow_env
        if self.cfg.follow_column is None:
            return 0
        generator_cfg = getattr(env.cfg.scene.terrain, "terrain_generator", None)
        types = getattr(env.terrain, "terrain_types", None)
        if generator_cfg is None or types is None:
            return 0
        names = list(generator_cfg.sub_terrains)
        if self.cfg.follow_column not in names:
            return 0
        column = names.index(self.cfg.follow_column)
        matches = (types == column).nonzero().flatten()
        if matches.numel() == 0:
            return 0
        return int(matches[0].item())

    def show(self):
        """Create the image widget and display it. Call once, before playing."""
        import ipywidgets as widgets
        from IPython.display import display

        if self.cam is None:
            raise RuntimeError(
                "No camera. Pass this viewer to the environment as "
                "pre_build_hooks=[viewer] so it can add one before the scene "
                "is built."
            )
        self.widget = widgets.Image(
            format="jpeg", width=self.cfg.width, height=self.cfg.height
        )
        display(self.widget)
        self.update()
        return self.widget

    def update(self) -> None:
        """Render one frame and push it to the widget."""
        from PIL import Image

        if self.widget is None:
            raise RuntimeError("Call show() before update().")
        # Following is normally applied during physics steps; refresh it here
        # so a paused or kinematically-driven scene still tracks the robot.
        if self.cfg.follow:
            self.cam.update_following()
        rgb = self.cam.render(rgb=True)[0]

        buffer = BytesIO()
        Image.fromarray(rgb).save(buffer, format="JPEG", quality=self.cfg.jpeg_quality)
        self.widget.value = buffer.getvalue()

    def play(
        self,
        policy: Callable[[object], "torch.Tensor"],
        steps: int = 600,
        command: tuple[float, float, float] | None = None,
    ) -> None:
        """Roll the policy out, streaming to the widget as it goes.

        Args:
          policy: Maps an observation dict to actions, e.g. the return value of
            ``runner.get_inference_policy()``.
          steps: Environment steps to run.
          command: Velocity command ``(vx, vy, wz)`` to hold for the whole
            rollout. ``None`` leaves the environment's own command sampling
            alone, so the robot wanders.
        """
        import torch

        env = self._env
        if env is None or self.widget is None:
            raise RuntimeError("Call show() before play().")

        if command is not None:
            self._hold_command(command)
        obs = env.get_observations()
        for step in range(steps):
            with torch.no_grad():
                actions = policy(obs)
            env.step(actions)
            if command is not None:
                # step() resamples commands for any environment that reset, so
                # reassert the held one and refresh the observation that
                # carries it.
                self._hold_command(command)
                env.obs_buf = env._compute_observations()
            obs = env.get_observations()
            if step % self.cfg.every == 0:
                self.update()

    def _hold_command(self, command: tuple[float, float, float]) -> None:
        import torch

        env = self._env
        tensor = torch.tensor(command, device=env.device, dtype=torch.float32)
        tensor = tensor.expand(env.num_envs, -1)
        env.commands[:] = tensor
        for name in env.command_manager.active_terms:
            term = env.command_manager.get_term(name)
            if term is not None:
                term.hold()
                term.command[:] = tensor


def render_terrain(
    terrain_cfg,
    views: dict[str, tuple[tuple[float, float, float], tuple[float, float, float]]]
    | None = None,
    width: int = 720,
    height: int = 480,
    fov: int = 45,
    far: float | None = None,
    display_inline: bool = True,
) -> dict:
    """Render a terrain config through Genesis, without a robot or a viewer.

    Builds a throwaway scene containing just the terrain — heightfield mesh
    plus any solid step boxes — and photographs it from each named viewpoint.
    This is the terrain as the simulator actually sees it, rather than a plot
    of the underlying array, so what you are looking at is the collision
    geometry the robot will walk on.

    Args:
      terrain_cfg: A ``TerrainEntityCfg``, or a ``TerrainGeneratorCfg`` which
        is wrapped in one.
      views: Named ``(camera_position, look_at)`` pairs. Defaults to an
        overview of the whole grid plus a close-up of the steepest stairs.
      width, height, fov: Camera settings.
      far: Far clipping distance, in meters. Defaults to four times the
        terrain's longest side. Genesis' own default is 20 m, which clips
        away most of a terrain this size and renders an empty frame.
      display_inline: Show the images in the notebook as well as returning
        them.

    Returns:
      Name -> RGB array, so callers can save or post-process the frames.
    """
    import genesis as gs

    from gslab.terrains import TerrainEntity, TerrainEntityCfg
    from gslab.terrains.terrain_generator import TerrainGeneratorCfg

    if isinstance(terrain_cfg, TerrainGeneratorCfg):
        terrain_cfg = TerrainEntityCfg(
            terrain_type="generator", terrain_generator=terrain_cfg, num_envs=1
        )

    terrain = TerrainEntity(terrain_cfg, device="cpu")
    generator = terrain.terrain_generator
    assert generator is not None, "render_terrain needs generator terrain"

    if views is None:
        views = _default_terrain_views(generator)

    scene = gs.Scene(
        show_viewer=False,
        profiling_options=gs.options.ProfilingOptions(show_FPS=False),
    )
    scene.add_entity(terrain.morph(), name="terrain")
    for index, morph in enumerate(terrain.box_morphs()):
        scene.add_entity(morph, name=f"terrain_box_{index}")

    if far is None:
        far = 4.0 * max(generator.size)
    cameras = {
        name: scene.add_camera(
            res=(width, height), pos=pos, lookat=lookat, fov=fov, far=far, GUI=False
        )
        for name, (pos, lookat) in views.items()
    }
    scene.build(n_envs=1, env_spacing=(0.0, 0.0))
    terrain.draw_debug_vis(scene)

    frames = {name: cam.render(rgb=True)[0] for name, cam in cameras.items()}

    if display_inline:
        _display_frames(frames)
    return frames


def _default_terrain_views(generator) -> dict:
    """An overview of the grid, and a close-up of the hardest stairs column."""
    size_x, size_y = generator.size
    span = max(size_x, size_y)
    overview = (
        (size_x * 0.55, -size_y * 0.75, span * 0.62),
        (0.0, 0.0, 0.0),
    )

    # Prefer a column that emitted boxes, since those are the real staircases.
    origins = generator.terrain_origins
    hardest = origins[generator.num_rows - 1]
    target = hardest[-1]
    if generator.boxes:
        # Point at whichever patch centre is closest to the tallest box.
        tallest = max(generator.boxes, key=lambda b: b.pos[2] + b.size[2] / 2)
        distances = [
            (o[0] - tallest.pos[0]) ** 2 + (o[1] - tallest.pos[1]) ** 2
            for o in origins.reshape(-1, 3)
        ]
        target = origins.reshape(-1, 3)[
            int(min(range(len(distances)), key=distances.__getitem__))
        ]
    closeup = (
        (target[0] - 6.0, target[1] - 4.5, target[2] + 3.0),
        (target[0] + 2.0, target[1], target[2] + 0.6),
    )
    return {"the whole grid": overview, "steepest stairs, close up": closeup}


def _display_frames(frames: dict) -> None:
    """Show rendered frames inline, one per row, with captions."""
    import base64
    from io import BytesIO

    from IPython.display import HTML, display
    from PIL import Image

    blocks = []
    for name, rgb in frames.items():
        buffer = BytesIO()
        Image.fromarray(rgb).save(buffer, format="JPEG", quality=88)
        encoded = base64.b64encode(buffer.getvalue()).decode()
        blocks.append(
            f'<figure style="margin:0 0 14px 0">'
            f'<img src="data:image/jpeg;base64,{encoded}" '
            f'style="max-width:100%;border-radius:6px"/>'
            f'<figcaption style="font:12px sans-serif;opacity:.7;padding-top:4px">'
            f"{name}</figcaption></figure>"
        )
    display(HTML("".join(blocks)))
