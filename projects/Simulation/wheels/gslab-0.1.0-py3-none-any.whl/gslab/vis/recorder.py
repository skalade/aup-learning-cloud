# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""Unified video recording for Genesis G1 scenes.

A single follow-camera recorder shared by ``scripts/play.py``,
``scripts/gait_playback.py`` and the validation scripts so the capture
lifecycle and camera framing live in one place instead of being re-implemented
at every call site.

Genesis records through a dedicated camera entity (``scene.add_camera`` +
``cam.start_recording``/``render``/``stop_recording``) rather than through
``env.render()``, so the recorder doubles as a pre-build hook that creates the
camera before the scene is built:

    recorder = VideoRecorder(VideoConfig())
    env = build_g1_env(..., pre_build_hooks=[recorder], viewer_res=recorder.viewer_res)
    recorder.start()
    while ...:
        ...                      # step / set state
        recorder.capture()
    recorder.save()              # writes the video file
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from genesis.engine.entities.rigid_entity import RigidEntity

    from gslab.envs import GenesisManagerBasedRlEnv

# Default framing matches gs.options.ViewerOptions defaults so recordings look
# like the interactive viewer rather than a far, wide shot.
DEFAULT_CAMERA_POS = (3.5, 0.5, 2.5)
DEFAULT_CAMERA_LOOKAT = (0.0, 0.0, 0.5)


@dataclass
class VideoConfig:
    """Settings for recording a follow-camera video of a scene."""

    width: int = 1920
    height: int = 1080
    fov: int = 40
    fps: int | None = None
    """Output frame rate; ``None`` uses the env's render fps."""
    length: int | None = None
    """Max frames to record; ``None`` records until the caller stops."""
    output: str = "video.mp4"
    """Output video path; the extension selects the container."""
    pos: tuple[float, float, float] = DEFAULT_CAMERA_POS
    lookat: tuple[float, float, float] = DEFAULT_CAMERA_LOOKAT
    follow: bool = True
    """Track the robot entity with the camera."""
    far: float = 150.0
    """Far clipping distance, in meters. Genesis defaults to 20 m, which clips
  the background out of any generated-terrain scene."""


class VideoRecorder:
    """Adds a follow camera as a pre-build hook and drives recording.

    The same object is passed to the env builder (as a ``pre_build_hooks``
    entry, which creates the camera) and then used to start, capture and save
    the recording.
    """

    def __init__(self, cfg: VideoConfig):
        self.cfg = cfg
        self._env: GenesisManagerBasedRlEnv | None = None
        self.cam = None

    def __call__(self, env: GenesisManagerBasedRlEnv) -> None:
        """Pre-build hook: create the camera and follow the robot."""
        self._env = env
        self.cam = env.scene.add_camera(
            res=(self.cfg.width, self.cfg.height),
            pos=self.cfg.pos,
            lookat=self.cfg.lookat,
            fov=self.cfg.fov,
            far=self.cfg.far,
        )
        # Keep the legacy ``env.cam`` handle for any code that still reaches for
        # it directly.
        env.cam = self.cam
        if self.cfg.follow:
            robot: RigidEntity = env.robot
            self.cam.follow_entity(robot)

    @property
    def viewer_res(self) -> tuple[int, int]:
        """Viewer-window resolution that matches the recording aspect ratio.

        With the viewer open, Genesis captures the camera at the viewer
        window's resolution rather than the camera's own, so the window must
        match to keep the requested aspect ratio.
        """
        return (self.cfg.width, self.cfg.height)

    def start(self) -> None:
        self.cam.start_recording()

    def capture(self) -> None:
        """Render one frame into the recording buffer."""
        # Camera following is applied on physics steps only, so refresh it
        # explicitly; this also covers kinematic playback that never steps.
        if self.cfg.follow:
            self.cam.update_following()
        self.cam.render()

    def save(self, output: str | None = None, fps: int | None = None) -> None:
        """Stop recording and write the buffered frames to disk."""
        path = output or self.cfg.output
        fps = fps or self.cfg.fps or self._env.metadata["render_fps"]
        Path(path).expanduser().parent.mkdir(parents=True, exist_ok=True)
        self.cam.stop_recording(save_to_filename=path, fps=fps)
        print(f"[INFO]: Saved video to {path}")
