# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

"""MJCF site lookup for Genesis entities.

Genesis has no site abstraction — its MJCF importer resolves sites away into
relative link positions and keeps nothing queryable. Robot configs written
against mjlab / Isaac Lab still address feet by *site* name (the G1 MJCF puts
``left_foot`` / ``right_foot`` on the sole, offset from the ankle-roll link
origin), so this module reads the site table straight out of the MJCF with
MuJoCo and re-derives site poses from the parent link's state at runtime.

Without this, ``SceneEntityCfg(site_names=...)`` silently resolves to nothing:
the site names are matched against link names, never match, and every term
that depends on them returns zeros.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import genesis.utils.geom as gu
import mujoco
import torch


@dataclass(frozen=True)
class SiteInfo:
    """One MJCF site, expressed relative to the link that carries it."""

    name: str
    link_name: str
    """Name of the MJCF body the site is attached to."""
    local_pos: tuple[float, float, float]
    """Site position in the parent body's frame, in meters."""


def parse_mjcf_sites(mjcf_path: Path | str) -> dict[str, SiteInfo]:
    """Read every named site out of an MJCF, keyed by site name.

    Uses MuJoCo rather than an XML walk so that defaults, frames, and includes
    are resolved the same way Genesis resolves them when it imports the model.
    """
    model = mujoco.MjModel.from_xml_path(str(mjcf_path))
    sites: dict[str, SiteInfo] = {}
    for site_id in range(model.nsite):
        name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_SITE, site_id)
        if not name:
            continue
        body_id = int(model.site_bodyid[site_id])
        body_name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, body_id)
        sites[name] = SiteInfo(
            name=name,
            link_name=body_name or "",
            local_pos=tuple(float(v) for v in model.site_pos[site_id]),
        )
    return sites


class SiteResolver:
    """Resolve MJCF site names to world poses and velocities at runtime.

    Site state is reconstructed from the parent link:
    ``p_site = p_link + R_link @ p_local`` and
    ``v_site = v_link + omega_link x (R_link @ p_local)``.

    Queries are batched over sites, so a term asking for both feet does one
    Genesis call rather than one per foot.
    """

    def __init__(self, robot, mjcf_path: Path | str, device: torch.device | str):
        self._robot = robot
        self._device = device
        self._sites = parse_mjcf_sites(mjcf_path)
        link_index = {link.name: link.idx_local for link in robot.links}
        # Sites on bodies Genesis merged away (fixed-joint welding) have no link
        # to hang off; drop them rather than failing the whole model.
        self._link_idx: dict[str, int] = {}
        self._local_pos: dict[str, torch.Tensor] = {}
        for name, info in self._sites.items():
            if info.link_name not in link_index:
                continue
            self._link_idx[name] = link_index[info.link_name]
            self._local_pos[name] = torch.tensor(
                info.local_pos, device=device, dtype=torch.float32
            )
        self._pos_cache: dict[tuple[str, ...], torch.Tensor] = {}
        self._vel_cache: dict[tuple[str, ...], torch.Tensor] = {}

    @property
    def names(self) -> tuple[str, ...]:
        """Names of every site that resolved to a live link."""
        return tuple(self._link_idx.keys())

    def has(self, name: str) -> bool:
        return name in self._link_idx

    def require(self, names: tuple[str, ...]) -> None:
        """Raise if any of ``names`` is not a resolvable site."""
        missing = [name for name in names if name not in self._link_idx]
        if missing:
            raise ValueError(
                f"Unknown site(s) {missing}. Available sites: {list(self.names)}"
            )

    def invalidate(self) -> None:
        """Drop cached site state. Call whenever the physics state advances.

        Several observation and reward terms ask for the same foot sites within
        one environment step; without this cache each of them would issue its
        own round of Genesis link queries, which measurably slows training.
        """
        self._pos_cache.clear()
        self._vel_cache.clear()

    def pos(self, names: tuple[str, ...]) -> torch.Tensor:
        """World positions of ``names``, shape ``(num_envs, len(names), 3)``.

        Cached until :meth:`invalidate`.
        """
        cached = self._pos_cache.get(names)
        if cached is not None:
            return cached
        self.require(names)
        link_idx = [self._link_idx[name] for name in names]
        link_pos = self._robot.get_links_pos(link_idx)
        link_quat = self._robot.get_links_quat(link_idx)
        value = link_pos + self._rotated_offsets(names, link_quat)
        self._pos_cache[names] = value
        return value

    def lin_vel(self, names: tuple[str, ...]) -> torch.Tensor:
        """World linear velocities of ``names``, shape ``(num_envs, len(names), 3)``.

        Includes the ``omega x r`` term, which is what distinguishes a foot
        pivoting about the ankle from one translating: without it a foot rolling
        over its toe reads as stationary. Cached until :meth:`invalidate`.
        """
        cached = self._vel_cache.get(names)
        if cached is not None:
            return cached
        self.require(names)
        link_idx = [self._link_idx[name] for name in names]
        link_vel = self._robot.get_links_vel(link_idx)
        link_ang = self._robot.get_links_ang(link_idx)
        link_quat = self._robot.get_links_quat(link_idx)
        offsets = self._rotated_offsets(names, link_quat)
        value = link_vel + torch.cross(link_ang, offsets, dim=-1)
        self._vel_cache[names] = value
        return value

    def _rotated_offsets(
        self, names: tuple[str, ...], link_quat: torch.Tensor
    ) -> torch.Tensor:
        """Per-site local offsets rotated into the world frame."""
        offsets = torch.stack([self._local_pos[name] for name in names], dim=0)
        offsets = offsets.unsqueeze(0).expand(link_quat.shape[0], -1, -1)
        return gu.transform_by_quat(offsets, link_quat)


def resolve_site_names(resolver: SiteResolver | None, asset_cfg) -> tuple[str, ...]:
    """Site names from a ``SceneEntityCfg``, filtered to what actually resolves.

    Returns an empty tuple when the term was never configured with sites, so
    callers can keep their "nothing to measure" path.
    """
    names = tuple(getattr(asset_cfg, "site_names", ()) or ())
    if not names or resolver is None:
        return ()
    resolver.require(names)
    return names
