# Copyright (C) 2026 Advanced Micro Devices, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Developed by Robotec.ai sp. z o.o.

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import genesis as gs
import torch

from gslab.actuator import ActuatorCfg

if TYPE_CHECKING:
    from genesis.engine.entities import RigidEntity
    from genesis.engine.entities.rigid_entity import RigidJoint

    from gslab.actuator import BuiltinPositionActuatorCfg


# Derived from mjlab (Apache-2.0); adapted for gslab.
# Original Copyright 2025 The mjlab Developers.
# See docs/license/mjlab-license.
@dataclass
class EntityCfg:
    @dataclass
    class InitialStateCfg:
        # Root position and orientation.
        pos: tuple[float, float, float] = (0.0, 0.0, 0.0)
        rot: tuple[float, float, float, float] = (1.0, 0.0, 0.0, 0.0)
        # Articulation (only for articulated entities).
        # Set to None to use the model's existing keyframe (errors if none exists).
        joint_pos: dict[str, float] | None = field(default_factory=lambda: {".*": 0.0})

    init_state: InitialStateCfg = field(default_factory=InitialStateCfg)
    articulation: EntityArticulationInfoCfg | None = None


@dataclass
class EntityArticulationInfoCfg:
    actuators: tuple[ActuatorCfg, ...] = field(default_factory=tuple)


def _find_joints(entity: RigidEntity, pattern: str) -> list[RigidJoint]:
    return [joint for joint in entity.joints if re.fullmatch(pattern, joint.name)]


def _is_single_dof_joint(joint: RigidJoint) -> bool:
    return len(joint.dofs_idx_local) == 1 and joint.type != gs.JOINT_TYPE.FREE


def initialize_robot_joints(
    robot: RigidEntity, init_joint_pos: dict[str, float] | None
) -> tuple[list[float], list[int]]:
    if init_joint_pos is None:
        return [], []

    dof_targets: list[float] = []
    dof_indices: list[int] = []
    for pattern, value in init_joint_pos.items():
        matched = _find_joints(robot, pattern)
        for joint in matched:
            dof_idx = joint.dofs_idx_local[0]
            robot.set_dofs_position([value], dofs_idx_local=dof_idx)
            dof_targets.append(value)
            dof_indices.append(dof_idx)

    return dof_targets, dof_indices


def setup_robot_pd_gains(
    robot: RigidEntity, robot_cfg: EntityCfg, device: torch.device | str | None
) -> tuple[torch.Tensor, list[str]]:
    if robot_cfg.articulation is None:
        raise ValueError("Robot articulation config is required for PD gain setup.")

    dofs_kp: list[float] = []
    dofs_kv: list[float] = []
    actuated: list[int] = []
    actuated_names: list[str] = []

    for actuator_cfg in robot_cfg.articulation.actuators:
        actuator_cfg: BuiltinPositionActuatorCfg
        kp = actuator_cfg.stiffness
        kv = actuator_cfg.damping
        for pattern in actuator_cfg.target_names_expr:
            for joint in _find_joints(robot, pattern):
                if not _is_single_dof_joint(joint):
                    continue
                dofs_kp.append(kp)
                dofs_kv.append(kv)
                actuated.append(joint.dofs_idx_local[0])
                actuated_names.append(joint.name)

    device = gs.device if device is None else device
    kp_tensor = torch.tensor(dofs_kp, dtype=torch.float32, device=device)
    kv_tensor = torch.tensor(dofs_kv, dtype=torch.float32, device=device)

    robot.set_dofs_kp(kp_tensor, dofs_idx_local=actuated)
    robot.set_dofs_kv(kv_tensor, dofs_idx_local=actuated)
    actuated_dofs = torch.tensor(actuated, device=device, dtype=torch.int32)
    return actuated_dofs, actuated_names
